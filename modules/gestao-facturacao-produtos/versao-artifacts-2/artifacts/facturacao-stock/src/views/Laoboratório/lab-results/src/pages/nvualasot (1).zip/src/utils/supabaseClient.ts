import { createClient } from '@supabase/supabase-js';

// Clean the Supabase URL in case it has /rest/v1/ appended
const rawUrl = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://xyowxmsrceaviuxyxqda.supabase.co';
const cleanUrl = rawUrl.replace(/\/rest\/v1\/?$/, '');

const anonKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_secret_3NzHQGpFKEjOvhSbXAJ3mA_ZiIRbQK0';

export const supabase = createClient(cleanUrl, anonKey);

// Log to help identify if Supabase is properly configured
console.log('Supabase client initialized with URL:', cleanUrl);

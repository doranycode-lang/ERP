export interface Session {
  funcionarioNome?: string;
  username?: string;
  cargo?: string;
}

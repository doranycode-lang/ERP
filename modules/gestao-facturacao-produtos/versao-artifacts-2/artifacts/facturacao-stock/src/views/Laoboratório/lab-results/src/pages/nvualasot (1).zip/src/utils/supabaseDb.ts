import { supabase } from './supabaseClient';
import { Product, Client, Supplier, Warehouse, Transfer, Order, CashFlowEntry, User, Activity, AppConfig, Backup, Sale, Bill, CashRegisterClosure, Company } from '../types';

// Fallback LocalStorage partitioned keys
const getPartitionKey = (companyId: string, key: string) => {
  return `tenant_${companyId}_${key}`;
};

function safeParse<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (!saved || saved === 'undefined' || saved === 'null') {
      return fallback;
    }
    return JSON.parse(saved) as T;
  } catch (e) {
    console.warn(`Error parsing localStorage key "${key}":`, e);
    return fallback;
  }
}

/**
 * Handles Company registration and authentication.
 */
export const CompanyService = {
  // Save/Get Companies
  async getCompanies(): Promise<Company[]> {
    try {
      const { data, error } = await supabase.from('fg_companies').select('*');
      if (error) throw error;
      return data || [];
    } catch (err) {
      console.warn('Using LocalStorage fallback for fg_companies:', err);
      return safeParse('tenant_global_companies', []);
    }
  },

  async saveCompanies(companies: Company[]): Promise<void> {
    try {
      const { error } = await supabase.from('fg_companies').upsert(companies);
      if (error) throw error;
    } catch (err) {
      console.warn('Saving fg_companies to LocalStorage fallback:', err);
    }
    localStorage.setItem('tenant_global_companies', JSON.stringify(companies));
  },

  async createCompany(nome: string, adminEmail: string, passwordInput: string): Promise<Company> {
    const companies = await this.getCompanies();
    
    // Check if company name already exists
    const slug = nome.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
    const exists = companies.some(c => c.id === slug);
    if (exists) {
      throw new Error('Já existe uma empresa registada com este nome ou slug semelhante.');
    }

    const newCompany: Company = {
      id: slug,
      nome,
      adminEmail,
      password: passwordInput,
      pin: '1234', // default pin
      nif: '5401123456',
      moeda: 'Kz',
      telefone: '+244 941 70 70 61',
      endereco: 'Luanda, Angola',
      created_at: new Date().toISOString()
    };

    const updated = [...companies, newCompany];
    await this.saveCompanies(updated);

    // Create the default Admin user for this company as well
    const defaultAdmin: User = {
      id: Date.now(),
      companyId: slug,
      nome: 'Administrador',
      email: adminEmail,
      cargo: 'Administrador',
      status: 'Ativo',
      ultimoAcesso: new Date().toLocaleDateString('pt-PT'),
      pin: '1234',
      password: passwordInput
    };
    
    await EmployeeService.saveEmployee(slug, defaultAdmin);

    // Seed default products & config for this company so they have immediate interactive data
    await seedDefaultDataForCompany(slug, nome, adminEmail);

    return newCompany;
  },

  async loginCompany(companyNameOrId: string, adminEmail: string, passwordInput: string): Promise<Company | null> {
    const companies = await this.getCompanies();
    const cleanSearch = companyNameOrId.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
    
    const company = companies.find(c => 
      (c.id === cleanSearch || c.nome.toLowerCase() === companyNameOrId.toLowerCase()) && 
      c.adminEmail.toLowerCase() === adminEmail.toLowerCase()
    );

    if (!company) {
      return null;
    }

    if (company.password === passwordInput) {
      return company;
    }

    return null;
  }
};

/**
 * Handles Employees / Users under a specific company.
 */
export const EmployeeService = {
  async getEmployees(companyId: string): Promise<User[]> {
    try {
      const { data, error } = await supabase.from('fg_users').select('*').eq('companyId', companyId);
      if (error) throw error;
      return data || [];
    } catch (err) {
      console.warn(`Using LocalStorage fallback for fg_users of ${companyId}:`, err);
      const partitionKey = getPartitionKey(companyId, 'fg_users');
      const saved = localStorage.getItem(partitionKey);
      if (saved && saved !== 'undefined' && saved !== 'null') {
        try {
          return JSON.parse(saved);
        } catch (e) {
          console.warn(`Failed to parse users for ${companyId}:`, e);
        }
      }
      
      // Seed default users if empty
      const defaultUsers: User[] = [
        { id: 1, companyId, nome: 'Administrador', email: 'admin@' + companyId + '.com', cargo: 'Administrador', status: 'Ativo', ultimoAcesso: '-', pin: '1234', password: 'admin' },
        { id: 2, companyId, nome: 'João Operador', email: 'joao@' + companyId + '.com', cargo: 'Operador', status: 'Ativo', ultimoAcesso: '-', pin: '2026', password: '1234' }
      ];
      localStorage.setItem(partitionKey, JSON.stringify(defaultUsers));
      return defaultUsers;
    }
  },

  async saveEmployee(companyId: string, employee: User): Promise<void> {
    const employees = await this.getEmployees(companyId);
    const index = employees.findIndex(e => e.id === employee.id || e.email.toLowerCase() === employee.email.toLowerCase());
    
    if (index >= 0) {
      employees[index] = { ...employees[index], ...employee };
    } else {
      employees.push(employee);
    }

    try {
      const { error } = await supabase.from('fg_users').upsert(employees);
      if (error) throw error;
    } catch (err) {
      console.warn('Saving fg_users to LocalStorage fallback:', err);
    }
    localStorage.setItem(getPartitionKey(companyId, 'fg_users'), JSON.stringify(employees));
  },

  async deleteEmployee(companyId: string, employeeId: number): Promise<void> {
    const employees = await this.getEmployees(companyId);
    const filtered = employees.filter(e => e.id !== employeeId);
    try {
      const { error } = await supabase.from('fg_users').delete().eq('id', employeeId);
      if (error) throw error;
    } catch (err) {
      console.warn('Deleting fg_users LocalStorage fallback:', err);
    }
    localStorage.setItem(getPartitionKey(companyId, 'fg_users'), JSON.stringify(filtered));
  }
};

/**
 * Handles Tenant Data separation for all resource types.
 */
export const TenantDataService = {
  async loadCollection<T>(companyId: string, key: string, defaultCollection: T[]): Promise<T[]> {
    try {
      const tableName = `fg_${key.replace('fg_', '')}`;
      const { data, error } = await supabase.from(tableName).select('*').eq('companyId', companyId);
      if (error) throw error;
      return (data as T[]) || [];
    } catch (err) {
      // LocalStorage partitioned separation
      const partitionKey = getPartitionKey(companyId, key);
      return safeParse(partitionKey, defaultCollection);
    }
  },

  async saveCollection<T>(companyId: string, key: string, data: T[]): Promise<void> {
    // 1. Save to LocalStorage Partition instantly (for speedy UI and robust offline backup)
    const partitionKey = getPartitionKey(companyId, key);
    localStorage.setItem(partitionKey, JSON.stringify(data));

    // 2. Try to sync to Supabase table
    try {
      const tableName = `fg_${key.replace('fg_', '')}`;
      // Map data and append companyId
      const mapped = data.map((item: any) => ({
        ...item,
        companyId
      }));

      const { error } = await supabase.from(tableName).upsert(mapped);
      if (error) throw error;
    } catch (err) {
      // Slitly log or handle sync queue
    }
  }
};

/**
 * Seed initial mock data for a newly created company to avoid a completely empty dashboard.
 */
async function seedDefaultDataForCompany(companyId: string, companyName: string, adminEmail: string) {
  // Config
  const defaultConfig: AppConfig = {
    empresa: companyName,
    nif: '5401123456',
    iva: 14,
    moeda: 'Kz',
    endereco: 'Rua Principal, Luanda, Angola',
    telefone: '+244 941 70 70 61',
    email: adminEmail
  };
  localStorage.setItem(getPartitionKey(companyId, 'fg_config'), JSON.stringify(defaultConfig));

  // Products
  const INITIAL_PRODUCTS: Product[] = [
    { id: 1, codigo: 'PAR500', nome: 'Paracetamol 500mg', categoria: 'Medicamentos', preco: 1500, stock: 120, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1d12ae3eb-57d9-405e-9dcf-e246747a74bd.png', lote: 'L-1102A', validade: '2027-12-31', stockMinimo: 30 },
    { id: 2, codigo: 'AMO500', nome: 'Amoxicilina 500mg', categoria: 'Medicamentos', preco: 3800, stock: 65, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/181db250a-aeb3-47ce-9804-3f9bd83a5b07.png', lote: 'L-8822B', validade: '2026-08-15', stockMinimo: 20 },
    { id: 3, codigo: 'VIT1000', nome: 'Vitamina C 1000mg', categoria: 'Suplementos', preco: 5000, stock: 150, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1d096c38a-61a8-4b7b-9683-7df38a2116dc.png', lote: 'L-9901C', validade: '2028-03-20', stockMinimo: 15 }
  ];
  localStorage.setItem(getPartitionKey(companyId, 'fg_products'), JSON.stringify(INITIAL_PRODUCTS));

  // Warehouses
  const INITIAL_WAREHOUSES: Warehouse[] = [
    { id: 1, nome: 'Armazém Principal', localizacao: 'Luanda, Angola', capacidade: 10000, produtos: 185, responsavel: 'Carlos Mendes' }
  ];
  localStorage.setItem(getPartitionKey(companyId, 'fg_warehouses'), JSON.stringify(INITIAL_WAREHOUSES));

  // Suppliers
  const INITIAL_SUPPLIERS: Supplier[] = [
    { id: 1, nome: 'Distribuidora Luanda Farma', contacto: '923456789', email: 'comercial@luanfarma.ao', nif: '540998877', produtos: 45 }
  ];
  localStorage.setItem(getPartitionKey(companyId, 'fg_suppliers'), JSON.stringify(INITIAL_SUPPLIERS));

  // Clients
  const INITIAL_CLIENTS: Client[] = [
    { id: 1, nome: 'Francisco Domingos', email: 'francisco@email.ao', telefone: '931223344', nif: '109283746', totalCompras: 0 }
  ];
  localStorage.setItem(getPartitionKey(companyId, 'fg_clients'), JSON.stringify(INITIAL_CLIENTS));
}

/**
 * Raw SQL script that users can run in Supabase SQL Editor to provision all tables.
 */
export const SUPABASE_SQL_SCRIPT = `-- SCRIPT DE CRIAÇÃO DE TABELAS PARA FARMEGEST PRO (TENANT ISOLATION)
-- Execute este script no SQL Editor do seu painel Supabase para ativar a persistência em Nuvem.

CREATE TABLE IF NOT EXISTS fg_companies (
  id TEXT PRIMARY KEY,
  nome TEXT NOT NULL,
  "adminEmail" TEXT NOT NULL,
  password TEXT,
  pin TEXT DEFAULT '1234',
  nif TEXT,
  moeda TEXT DEFAULT 'Kz',
  telefone TEXT,
  endereco TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fg_users (
  id BIGINT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  email TEXT NOT NULL,
  cargo TEXT NOT NULL,
  status TEXT DEFAULT 'Ativo',
  "ultimoAcesso" TEXT,
  pin TEXT,
  password TEXT
);

CREATE TABLE IF NOT EXISTS fg_products (
  id BIGINT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  codigo TEXT,
  nome TEXT NOT NULL,
  categoria TEXT,
  preco NUMERIC(12,2) NOT NULL,
  stock INT DEFAULT 0,
  armazem TEXT,
  imagem TEXT,
  lote TEXT,
  validade TEXT,
  "stockMinimo" INT
);

CREATE TABLE IF NOT EXISTS fg_clients (
  id BIGINT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  email TEXT,
  telefone TEXT,
  nif TEXT,
  "totalCompras" NUMERIC(12,2) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS fg_suppliers (
  id BIGINT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  contacto TEXT,
  email TEXT,
  nif TEXT,
  produtos INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS fg_warehouses (
  id BIGINT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  localizacao TEXT,
  capacidade INT,
  produtos INT DEFAULT 0,
  responsavel TEXT
);

CREATE TABLE IF NOT EXISTS fg_cashflow (
  id BIGINT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  data TEXT,
  tipo TEXT NOT NULL,
  descricao TEXT,
  valor NUMERIC(12,2) NOT NULL,
  responsavel TEXT
);

CREATE TABLE IF NOT EXISTS fg_sales (
  id TEXT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  data TEXT,
  items JSONB,
  subtotal NUMERIC(12,2),
  iva NUMERIC(12,2),
  total NUMERIC(12,2) NOT NULL,
  "metodoPagamento" TEXT,
  "clienteNome" TEXT,
  "clienteNif" TEXT,
  "valorPago" NUMERIC(12,2),
  troco NUMERIC(12,2),
  "pagamentoDetalhado" JSONB
);

CREATE TABLE IF NOT EXISTS fg_activities (
  id BIGINT PRIMARY KEY,
  "companyId" TEXT REFERENCES fg_companies(id) ON DELETE CASCADE,
  titulo TEXT NOT NULL,
  data TEXT,
  tipo TEXT,
  usuario TEXT
);
`;

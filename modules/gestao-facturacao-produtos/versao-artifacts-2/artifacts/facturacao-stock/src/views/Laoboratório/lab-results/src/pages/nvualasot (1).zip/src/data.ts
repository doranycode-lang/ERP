/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, Client, Supplier, Warehouse, Transfer, Order, CashFlowEntry, User, Activity, AppConfig, Backup, Sale, Bill, CashRegisterClosure } from './types';

export const BRAND_LOGO = 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1f87f5ab8-9c9f-445a-ac47-b23154966a8e.png';
export const HERO_BANNER = 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/14f45fffc-906a-4fb4-a083-2f186d469e64.png';

export const INITIAL_PRODUCTS: Product[] = [
  { id: 1, codigo: 'PAR500', nome: 'Paracetamol 500mg', categoria: 'Medicamentos', preco: 3.50, stock: 150, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1d12ae3eb-57d9-405e-9dcf-e246747a74bd.png', lote: 'L-1102A', validade: '2027-12-31', stockMinimo: 50 },
  { id: 2, codigo: 'AMO500', nome: 'Amoxicilina 500mg', categoria: 'Medicamentos', preco: 8.90, stock: 80, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/181db250a-aeb3-47ce-9804-3f9bd83a5b07.png', lote: 'L-8822B', validade: '2026-08-15', stockMinimo: 40 },
  { id: 3, codigo: 'VIT1000', nome: 'Vitamina C 1000mg', categoria: 'Suplementos', preco: 12.50, stock: 200, armazem: 'Armazém 2', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1d096c38a-61a8-4b7b-9683-7df38a2116dc.png', lote: 'L-9901C', validade: '2028-03-20', stockMinimo: 30 },
  { id: 4, codigo: 'IBU400', nome: 'Ibuprofeno 400mg', categoria: 'Medicamentos', preco: 4.20, stock: 120, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1528efb06-beb6-42a6-bb3d-88a380e5a845.png', lote: 'L-7744D', validade: '2026-07-25', stockMinimo: 100 },
  { id: 5, codigo: 'AZI500', nome: 'Azitromicina 500mg', categoria: 'Medicamentos', preco: 15.80, stock: 45, armazem: 'Armazém 3', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1f9994977-b4c9-441c-a79e-94239b3628c5.png', lote: 'L-3311E', validade: '2027-05-18', stockMinimo: 50 },
  { id: 6, codigo: 'LOR10', nome: 'Loratadina 10mg', categoria: 'Medicamentos', preco: 6.30, stock: 90, armazem: 'Armazém 2', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/17905a316-e480-4bd7-a244-b7ef92f5f50b.png', lote: 'L-5522F', validade: '2027-10-12', stockMinimo: 20 },
  { id: 7, codigo: 'OME20', nome: 'Omeprazol 20mg', categoria: 'Medicamentos', preco: 9.40, stock: 110, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1877d66d2-90b2-447f-84b1-1259dad9f6c3.png', lote: 'L-1212G', validade: '2026-11-30', stockMinimo: 45 },
  { id: 8, codigo: 'SAL100', nome: 'Salbutamol 100mcg', categoria: 'Medicamentos', preco: 18.90, stock: 35, armazem: 'Armazém 3', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/190f31487-f1d0-49e2-be3f-d4fd6560ca27.png', lote: 'L-4499H', validade: '2027-02-14', stockMinimo: 15 },
  { id: 9, codigo: 'DIP500', nome: 'Dipirona 500mg', categoria: 'Medicamentos', preco: 5.60, stock: 100, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1519f92c7-eb78-4807-956a-3f457ee9b390.png', lote: 'L-6611J', validade: '2027-08-19', stockMinimo: 30 },
  { id: 10, codigo: 'NYS1', nome: 'Nistatina Creme', categoria: 'Medicamentos', preco: 7.80, stock: 60, armazem: 'Armazém 2', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/10b64c474-70e8-4292-8026-f3b11417faf5.png', lote: 'L-2288K', validade: '2026-12-05', stockMinimo: 15 },
  { id: 11, codigo: 'GEL1', nome: 'Gel Antisséptico', categoria: 'Higiene', preco: 6.00, stock: 150, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1a40486a0-ae5a-4927-bf86-8ba9587c8154.png', lote: 'L-0012A', validade: '2028-06-30', stockMinimo: 20 },
  { id: 12, codigo: 'FRALM', nome: 'Fraldas M', categoria: 'Higiene', preco: 25.00, stock: 80, armazem: 'Armazém 2', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/12d46f412-724a-4c17-8580-1bb30bfa42a3.png', lote: 'L-4422B', validade: '2029-01-01', stockMinimo: 10 },
  { id: 13, codigo: 'SH200', nome: 'Shampoo 200ml', categoria: 'Cosméticos', preco: 12.00, stock: 100, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1024598b6-9c01-41b9-bb74-5369df005618.png', lote: 'L-9988C', validade: '2029-05-15', stockMinimo: 15 },
  { id: 14, codigo: 'SAB90', nome: 'Sabonete 90g', categoria: 'Higiene', preco: 3.50, stock: 200, armazem: 'Armazém Principal', imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1cdfd6e37-6c2b-44f2-a752-b17363d83027.png', lote: 'L-5544D', validade: '2029-10-20', stockMinimo: 25 }
];

export const INITIAL_CLIENTS: Client[] = [
  { id: 1, nome: 'João Silva', email: 'joao@email.com', telefone: '912345678', nif: '123456789', totalCompras: 1250.50 },
  { id: 2, nome: 'Maria Santos', email: 'maria@email.com', telefone: '923456789', nif: '987654321', totalCompras: 890.30 },
  { id: 3, nome: 'Pedro Costa', email: 'pedro@email.com', telefone: '934567890', nif: '456789123', totalCompras: 2100.00 }
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  { id: 1, nome: 'Pfizer', contacto: '210123456', email: 'pfizer@pfizer.pt', nif: '111222333', produtos: 45 },
  { id: 2, nome: 'Novartis', contacto: '210234567', email: 'novartis@novartis.pt', nif: '444555666', produtos: 38 },
  { id: 3, nome: 'Roche', contacto: '210345678', email: 'roche@roche.pt', nif: '777888999', produtos: 52 }
];

export const INITIAL_WAREHOUSES: Warehouse[] = [
  { id: 1, nome: 'Armazém Principal', localizacao: 'Luanda, Angola', capacidade: 10000, produtos: 250, responsavel: 'Carlos Mendes' },
  { id: 2, nome: 'Armazém 2', localizacao: 'Viana, Angola', capacidade: 8000, produtos: 180, responsavel: 'Ana Rodrigues' },
  { id: 3, nome: 'Armazém 3', localizacao: 'Talatona, Angola', capacidade: 6000, produtos: 120, responsavel: 'Rui Ferreira' }
];

export const INITIAL_TRANSFERS: Transfer[] = [
  { id: 1, data: '2026-07-10', origem: 'Armazém Principal', destino: 'Armazém 2', produto: 'Paracetamol 500mg', quantidade: 50, status: 'Concluída' },
  { id: 2, data: '2026-07-09', origem: 'Armazém 2', destino: 'Armazém 3', produto: 'Amoxicilina 500mg', quantidade: 30, status: 'Em Trânsito' }
];

export const INITIAL_ORDERS: Order[] = [
  { id: 1, data: '2026-07-11', fornecedor: 'Pfizer', produtos: 'Paracetamol, Amoxicilina', valor: 2500.00, status: 'Pendente' },
  { id: 2, data: '2026-07-10', fornecedor: 'Novartis', produtos: 'Ibuprofeno, Omeprazol', valor: 1800.00, status: 'Recebida' }
];

export const INITIAL_CASH_FLOW: CashFlowEntry[] = [
  { id: 1, data: '2026-07-11 09:30', tipo: 'Entrada', descricao: 'Venda #001', valor: 125.50, responsavel: 'Admin' },
  { id: 2, data: '2026-07-11 10:15', tipo: 'Entrada', descricao: 'Venda #002', valor: 89.90, responsavel: 'Admin' },
  { id: 3, data: '2026-07-11 11:00', tipo: 'Saída', descricao: 'Pagamento Fornecedor', valor: 500.00, responsavel: 'Admin' }
];

export const INITIAL_USERS: User[] = [
  { id: 1, nome: 'Administrador', email: 'admin@nvualasot.com', cargo: 'Administrador', status: 'Ativo', ultimoAcesso: '2026-07-11 08:00' },
  { id: 2, nome: 'João Operador', email: 'joao@nvualasot.com', cargo: 'Operador', status: 'Ativo', ultimoAcesso: '2026-07-10 14:30' }
];

export const INITIAL_ACTIVITIES: Activity[] = [
  { id: 1, titulo: 'Sistema iniciado por Admin', data: '2026-07-11 08:00', tipo: 'sistema', usuario: 'Admin' },
  { id: 2, titulo: 'Venda #001 registrada com sucesso - €125,50', data: '2026-07-11 09:30', tipo: 'venda', usuario: 'Admin' },
  { id: 3, titulo: 'Venda #002 registrada com sucesso - €89,90', data: '2026-07-11 10:15', tipo: 'venda', usuario: 'Admin' },
  { id: 4, titulo: 'Saída de caixa registrada - €500,00 (Pagamento Fornecedor)', data: '2026-07-11 11:00', tipo: 'financeiro', usuario: 'Admin' }
];

export const INITIAL_CONFIG: AppConfig = {
  empresa: 'NVUALASOT | KuatelaSoft',
  nif: '5401123456',
  iva: 23,
  moeda: '€',
  endereco: 'Rua Principal, 123, Luanda',
  telefone: '(+244) 941 70 70 61',
  email: 'suporte@nvualasot.com'
};

export const INITIAL_BACKUPS: Backup[] = [
  { id: 1, nome: 'Backup Automático Diário', data: '2026-07-11 03:00', tamanho: '2.4 MB' },
  { id: 2, nome: 'Backup Automático Diário', data: '2026-07-10 03:00', tamanho: '2.3 MB' },
  { id: 3, nome: 'Backup Manual de Segurança', data: '2026-07-09 15:30', tamanho: '2.2 MB' }
];

export const INITIAL_SALES: Sale[] = [
  {
    id: 'FAC-2026-001',
    data: '2026-07-11 09:30',
    items: [
      { id: 1, nome: 'Paracetamol 500mg', preco: 3.50, imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1d12ae3eb-57d9-405e-9dcf-e246747a74bd.png', quantidade: 2, stock: 148 },
      { id: 3, nome: 'Vitamina C 1000mg', preco: 12.50, imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1d096c38a-61a8-4b7b-9683-7df38a2116dc.png', quantidade: 1, stock: 199 }
    ],
    subtotal: 19.50,
    iva: 4.49,
    total: 23.99,
    clienteNome: 'João Silva',
    clienteNif: '123456789',
    metodoPagamento: 'Dinheiro',
    valorPago: 30.00,
    troco: 6.01
  },
  {
    id: 'FAC-2026-002',
    data: '2026-07-11 10:15',
    items: [
      { id: 2, nome: 'Amoxicilina 500mg', preco: 8.90, imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/181db250a-aeb3-47ce-9804-3f9bd83a5b07.png', quantidade: 1, stock: 79 },
      { id: 5, nome: 'Azitromicina 500mg', preco: 15.80, imagem: 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1f9994977-b4c9-441c-a79e-94239b3628c5.png', quantidade: 2, stock: 43 }
    ],
    subtotal: 40.50,
    iva: 9.32,
    total: 49.82,
    clienteNome: 'Maria Santos',
    clienteNif: '987654321',
    metodoPagamento: 'Multicaixa',
    valorPago: 49.82,
    troco: 0.00
  }
];

export const INITIAL_BILLS: Bill[] = [
  { id: 'BILL-1001', tipo: 'Receber', descricao: 'Fornecimento de Vacinas - Hospital Geral', valor: 3500.00, dataVencimento: '2026-07-20', status: 'Pendente' },
  { id: 'BILL-1002', tipo: 'Pagar', descricao: 'Fatura de Medicamentos Pfizer', valor: 1200.00, dataVencimento: '2026-07-15', status: 'Pendente' },
  { id: 'BILL-1003', tipo: 'Pagar', descricao: 'Aluguer das Instalações da Farmácia', valor: 850.00, dataVencimento: '2026-07-05', status: 'Pago' },
  { id: 'BILL-1004', tipo: 'Receber', descricao: 'Reembolso de Seguros ENSA', valor: 750.00, dataVencimento: '2026-07-30', status: 'Pendente' }
];

export const INITIAL_REGISTERS: CashRegisterClosure[] = [
  {
    id: 'FECH-1783429381920',
    dataFechamento: '2026-07-10 18:00:00',
    operador: 'Administrador (AD)',
    valorCalculado: 1920.00,
    valorInformado: 1920.00,
    observacoes: 'Fechamento perfeito sem divergências de caixa.',
    status: 'Fechado'
  }
];

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  X, 
  Pill, 
  Users, 
  Factory, 
  Warehouse as WarehouseIcon, 
  ArrowLeftRight, 
  Box, 
  Coins, 
  UserCog, 
  Database,
  CheckCircle,
  HelpCircle,
  CreditCard,
  Lock,
  Mail,
  Key,
  Eye,
  EyeOff,
  ShieldCheck,
  UserCheck
} from 'lucide-react';

import { 
  Product, 
  Client, 
  Supplier, 
  Warehouse, 
  Transfer, 
  Order, 
  CashFlowEntry, 
  User, 
  Activity, 
  Backup, 
  AppConfig, 
  CartItem,
  Sale,
  Bill,
  CashRegisterClosure
} from './types';

import { 
  INITIAL_PRODUCTS, 
  INITIAL_CLIENTS, 
  INITIAL_SUPPLIERS, 
  INITIAL_WAREHOUSES, 
  INITIAL_TRANSFERS, 
  INITIAL_ORDERS, 
  INITIAL_CASH_FLOW, 
  INITIAL_USERS, 
  INITIAL_ACTIVITIES, 
  INITIAL_CONFIG, 
  INITIAL_BACKUPS,
  INITIAL_SALES,
  INITIAL_BILLS,
  INITIAL_REGISTERS,
  BRAND_LOGO
} from './data';

import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { POSView } from './components/POSView';
import { ManagementView } from './components/ManagementView';
import Faturacao from './components/Faturacao';
import { AppProvider } from './store/AppContext';
import { compressImage, formatBytes } from './utils/imageCompressor';
import { CompanyService, EmployeeService, TenantDataService, SUPABASE_SQL_SCRIPT } from './utils/supabaseDb';
import { Company } from './types';
import { Building2, Plus, Download, LogOut } from 'lucide-react';


function safeParse<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (!saved || saved === 'undefined' || saved === 'null') {
      return fallback;
    }
    return JSON.parse(saved) as T;
  } catch (e) {
    console.warn(`Error parsing localStorage key "${key}":`, e);
    return fallback;
  }
}

export default function App() {
  // Navigation and toggles
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  // Notifications state
  const [notification, setNotification] = useState<string | null>(null);

  // Core Data States
  const [products, setProducts] = useState<Product[]>(() => safeParse('fg_products', INITIAL_PRODUCTS));
  const [clients, setClients] = useState<Client[]>(() => safeParse('fg_clients', INITIAL_CLIENTS));
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => safeParse('fg_suppliers', INITIAL_SUPPLIERS));
  const [warehouses, setWarehouses] = useState<Warehouse[]>(() => safeParse('fg_warehouses', INITIAL_WAREHOUSES));
  const [transfers, setTransfers] = useState<Transfer[]>(() => safeParse('fg_transfers', INITIAL_TRANSFERS));
  const [orders, setOrders] = useState<Order[]>(() => safeParse('fg_orders', INITIAL_ORDERS));
  const [cashFlow, setCashFlow] = useState<CashFlowEntry[]>(() => safeParse('fg_cashflow', INITIAL_CASH_FLOW));
  const [users, setUsers] = useState<User[]>(() => safeParse('fg_users', INITIAL_USERS));
  const [activities, setActivities] = useState<Activity[]>(() => safeParse('fg_activities', INITIAL_ACTIVITIES));
  const [backups, setBackups] = useState<Backup[]>(() => safeParse('fg_backups', INITIAL_BACKUPS));
  const [config, setConfig] = useState<AppConfig>(() => safeParse('fg_config', INITIAL_CONFIG));
  const [sales, setSales] = useState<Sale[]>(() => safeParse('fg_sales', INITIAL_SALES));
  const [bills, setBills] = useState<Bill[]>(() => safeParse('fg_bills', INITIAL_BILLS));
  const [closures, setClosures] = useState<CashRegisterClosure[]>(() => safeParse('fg_closures', INITIAL_REGISTERS));
  const [faturas, setFaturas] = useState<any[]>(() => safeParse('fg_faturas', []));
  const [currentCompany, setCurrentCompany] = useState<Company | null>(() => safeParse('fg_current_company', null));
  const [currentUser, setCurrentUser] = useState<User>(() => safeParse('fg_current_user', INITIAL_USERS[0]));
  const [isLocked, setIsLocked] = useState<boolean>(() => safeParse('fg_is_locked', true));

  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');
  const [loginTab, setLoginTab] = useState<'pin' | 'credentials'>('pin');
  const [emailInput, setEmailInput] = useState<string>('');
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  // Multi-Tenant Portal state
  const [companyPortalTab, setCompanyPortalTab] = useState<'login' | 'register'>('login');
  const [compNameInput, setCompNameInput] = useState<string>('');
  const [compEmailInput, setCompEmailInput] = useState<string>('');
  const [compPassInput, setCompPassInput] = useState<string>('');
  const [compError, setCompError] = useState<string>('');

  const [currentInvoice, setCurrentInvoice] = useState<Sale | null>(null);
  const [uploadedProdImage, setUploadedProdImage] = useState<string | null>(null);
  const [isCompressingImage, setIsCompressingImage] = useState<boolean>(false);
  const [imageCompressionInfo, setImageCompressionInfo] = useState<{ originalSize: string; compressedSize: string; percentage: string } | null>(null);

  // Save changes to localStorage / Supabase
  useEffect(() => {
    localStorage.setItem('fg_is_locked', JSON.stringify(isLocked));
  }, [isLocked]);

  useEffect(() => {
    localStorage.setItem('fg_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    if (currentCompany) {
      localStorage.setItem('fg_current_company', JSON.stringify(currentCompany));
    } else {
      localStorage.removeItem('fg_current_company');
    }
  }, [currentCompany]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_bills', bills);
    } else {
      localStorage.setItem('fg_bills', JSON.stringify(bills));
    }
  }, [bills, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_closures', closures);
    } else {
      localStorage.setItem('fg_closures', JSON.stringify(closures));
    }
  }, [closures, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_faturas', faturas);
    } else {
      localStorage.setItem('fg_faturas', JSON.stringify(faturas));
    }
  }, [faturas, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_products', products);
    } else {
      localStorage.setItem('fg_products', JSON.stringify(products));
    }
  }, [products, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_clients', clients);
    } else {
      localStorage.setItem('fg_clients', JSON.stringify(clients));
    }
  }, [clients, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_suppliers', suppliers);
    } else {
      localStorage.setItem('fg_suppliers', JSON.stringify(suppliers));
    }
  }, [suppliers, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_warehouses', warehouses);
    } else {
      localStorage.setItem('fg_warehouses', JSON.stringify(warehouses));
    }
  }, [warehouses, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_transfers', transfers);
    } else {
      localStorage.setItem('fg_transfers', JSON.stringify(transfers));
    }
  }, [transfers, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_orders', orders);
    } else {
      localStorage.setItem('fg_orders', JSON.stringify(orders));
    }
  }, [orders, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_cashflow', cashFlow);
    } else {
      localStorage.setItem('fg_cashflow', JSON.stringify(cashFlow));
    }
  }, [cashFlow, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_users', users);
    } else {
      localStorage.setItem('fg_users', JSON.stringify(users));
    }
  }, [users, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_activities', activities);
    } else {
      localStorage.setItem('fg_activities', JSON.stringify(activities));
    }
  }, [activities, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_backups', backups);
    } else {
      localStorage.setItem('fg_backups', JSON.stringify(backups));
    }
  }, [backups, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_config', [config]);
    } else {
      localStorage.setItem('fg_config', JSON.stringify(config));
    }
  }, [config, currentCompany?.id]);

  useEffect(() => {
    if (currentCompany) {
      TenantDataService.saveCollection(currentCompany.id, 'fg_sales', sales);
    } else {
      localStorage.setItem('fg_sales', JSON.stringify(sales));
    }
  }, [sales, currentCompany?.id]);

  // Load tenant specific data when currentCompany changes
  useEffect(() => {
    if (!currentCompany) return;
    
    const companyId = currentCompany.id;
    const loadTenantData = async () => {
      try {
        const prods = await TenantDataService.loadCollection<Product>(companyId, 'fg_products', INITIAL_PRODUCTS);
        setProducts(prods);

        const clis = await TenantDataService.loadCollection<Client>(companyId, 'fg_clients', INITIAL_CLIENTS);
        setClients(clis);

        const sups = await TenantDataService.loadCollection<Supplier>(companyId, 'fg_suppliers', INITIAL_SUPPLIERS);
        setSuppliers(sups);

        const whs = await TenantDataService.loadCollection<Warehouse>(companyId, 'fg_warehouses', INITIAL_WAREHOUSES);
        setWarehouses(whs);

        const trs = await TenantDataService.loadCollection<Transfer>(companyId, 'fg_transfers', []);
        setTransfers(trs);

        const ords = await TenantDataService.loadCollection<Order>(companyId, 'fg_orders', []);
        setOrders(ords);

        const cash = await TenantDataService.loadCollection<CashFlowEntry>(companyId, 'fg_cashflow', []);
        setCashFlow(cash);

        const emps = await EmployeeService.getEmployees(companyId);
        setUsers(emps);

        const acts = await TenantDataService.loadCollection<Activity>(companyId, 'fg_activities', []);
        setActivities(acts);

        const bks = await TenantDataService.loadCollection<Backup>(companyId, 'fg_backups', []);
        setBackups(bks);

        const cfgs = await TenantDataService.loadCollection<AppConfig>(companyId, 'fg_config', [INITIAL_CONFIG]);
        if (cfgs && cfgs.length > 0) {
          setConfig(cfgs[0]);
        } else {
          setConfig({
            empresa: currentCompany.nome,
            nif: currentCompany.nif || '5401123456',
            iva: 14,
            moeda: currentCompany.moeda || 'Kz',
            endereco: currentCompany.endereco || 'Luanda, Angola',
            telefone: currentCompany.telefone || '+244 941 70 70 61',
            email: currentCompany.adminEmail
          });
        }

        const sls = await TenantDataService.loadCollection<Sale>(companyId, 'fg_sales', []);
        setSales(sls);

        const bls = await TenantDataService.loadCollection<Bill>(companyId, 'fg_bills', []);
        setBills(bls);

        const cls = await TenantDataService.loadCollection<CashRegisterClosure>(companyId, 'fg_closures', []);
        setClosures(cls);

        const fts = await TenantDataService.loadCollection<any>(companyId, 'fg_faturas', []);
        setFaturas(fts);

        // Select the admin user or first employee as default logged-in user
        if (emps && emps.length > 0) {
          setCurrentUser(emps[0]);
        }
      } catch (e) {
        console.error('Error loading tenant data:', e);
      }
    };
    loadTenantData();
  }, [currentCompany?.id]);

  // Serviço de Sincronização Automática entre POS, Gestão de Stock e Facturação
  // Este listener escuta as mudanças em localStorage disparadas por outras abas/janelas do navegador,
  // garantindo consistência instantânea e sincronismo bidirecional em tempo real.
  useEffect(() => {
    const handleSyncStorage = (e: StorageEvent) => {
      if (e.key === 'fg_products' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          setProducts(parsed);
        } catch (err) {
          console.error('Erro de sincronização de produtos:', err);
        }
      }
      if (e.key === 'fg_clients' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          setClients(parsed);
        } catch (err) {
          console.error('Erro de sincronização de clientes:', err);
        }
      }
      if (e.key === 'fg_faturas' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          setFaturas(parsed);
        } catch (err) {
          console.error('Erro de sincronização de faturas:', err);
        }
      }
    };
    window.addEventListener('storage', handleSyncStorage);
    return () => window.removeEventListener('storage', handleSyncStorage);
  }, []);

  // Automatic print trigger for invoices
  useEffect(() => {
    if (currentInvoice) {
      const timer = setTimeout(() => {
        window.print();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [currentInvoice]);

  // Notifications display handler
  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 3500);
  };

  // Helper function to insert activity log
  const addActivity = (title: string, tipo: Activity['tipo']) => {
    const newAct: Activity = {
      id: Date.now(),
      titulo: title,
      data: new Date().toLocaleString('pt-PT', { hour12: false }),
      tipo,
      usuario: 'Admin',
    };
    setActivities(prev => [newAct, ...prev]);
  };

  // State mutation operations
  const handleDeleteProduct = (id: number) => {
    const p = products.find(x => x.id === id);
    if (p && confirm(`Tem a certeza que deseja eliminar o produto ${p.nome}?`)) {
      setProducts(prev => prev.filter(x => x.id !== id));
      addActivity(`Produto eliminado do stock: ${p.nome}`, 'sistema');
      showNotification(`O produto ${p.nome} foi removido com sucesso.`);
    }
  };

  const handleDeleteClient = (id: number) => {
    const c = clients.find(x => x.id === id);
    if (c && confirm(`Tem a certeza que deseja eliminar o cliente ${c.nome}?`)) {
      setClients(prev => prev.filter(x => x.id !== id));
      addActivity(`Cliente removido do CRM: ${c.nome}`, 'sistema');
      showNotification(`O cliente ${c.nome} foi removido.`);
    }
  };

  const handleDeleteSupplier = (id: number) => {
    const s = suppliers.find(x => x.id === id);
    if (s && confirm(`Tem a certeza que deseja eliminar o fornecedor ${s.nome}?`)) {
      setSuppliers(prev => prev.filter(x => x.id !== id));
      addActivity(`Fornecedor eliminado: ${s.nome}`, 'sistema');
      showNotification(`Fornecedor ${s.nome} removido.`);
    }
  };

  const handleDeleteWarehouse = (id: number) => {
    const w = warehouses.find(x => x.id === id);
    if (w && confirm(`Tem a certeza que deseja eliminar o armazém ${w.nome}?`)) {
      setWarehouses(prev => prev.filter(x => x.id !== id));
      addActivity(`Armazém removido das instalações: ${w.nome}`, 'logistica');
      showNotification(`Armazém ${w.nome} foi removido.`);
    }
  };

  const handleDeleteUser = async (id: number) => {
    const u = users.find(x => x.id === id);
    if (u && confirm(`Tem a certeza que deseja revogar o utilizador ${u.nome}?`)) {
      setUsers(prev => prev.filter(x => x.id !== id));
      if (currentCompany) {
        await EmployeeService.deleteEmployee(currentCompany.id, id);
      }
      addActivity(`Utilizador removido do sistema: ${u.nome}`, 'sistema');
      showNotification(`O utilizador ${u.nome} foi removido.`);
    }
  };

  const handleSaveConfig = (newCfg: AppConfig) => {
    setConfig(newCfg);
    addActivity('Configurações gerais da empresa alteradas', 'sistema');
    showNotification('Definições da empresa atualizadas.');
  };

  const handleCreateBackup = () => {
    const size = (2.0 + Math.random() * 0.9).toFixed(1);
    const newBk: Backup = {
      id: Date.now(),
      nome: `Backup Manual consolidado ${new Date().toISOString().split('T')[0]}`,
      data: new Date().toLocaleString('pt-PT', { hour12: false }),
      tamanho: `${size} MB`,
    };
    setBackups(prev => [newBk, ...prev]);
    addActivity('Backup manual da base de dados criado com sucesso', 'sistema');
    showNotification('Cópia de segurança criada com sucesso!');
  };

  // Finance and Cash closure Handlers
  const handleAddBill = (newBillData: Omit<Bill, 'id'>) => {
    const id = `BILL-${Math.floor(1000 + Math.random() * 9000)}`;
    const bill: Bill = { ...newBillData, id };
    setBills(prev => [bill, ...prev]);
    addActivity(`Novo lançamento financeiro agendado: ${bill.descricao} (${config.moeda}${bill.valor.toFixed(2)})`, 'financeiro');
  };

  const handlePayBill = (id: string) => {
    setBills(prev => prev.map(b => {
      if (b.id === id) {
        // Register in CashFlow
        const flowEntry: CashFlowEntry = {
          id: Date.now(),
          data: new Date().toLocaleString('pt-PT', { hour12: false }),
          tipo: b.tipo === 'Pagar' ? 'Saída' : 'Entrada',
          descricao: `Liquidação de conta: ${b.descricao}`,
          valor: b.valor,
          responsavel: 'Admin'
        };
        setCashFlow(prevCash => [flowEntry, ...prevCash]);
        addActivity(`Conta liquidada com sucesso: ${b.descricao} (${config.moeda}${b.valor.toFixed(2)})`, 'financeiro');
        showNotification(`Conta "${b.descricao}" marcada como Paga!`);
        return { ...b, status: 'Pago' as const };
      }
      return b;
    }));
  };

  const handleCloseRegister = (valorFinal: number, obs: string) => {
    const totalEntries = cashFlow.filter(entry => entry.tipo === 'Entrada').reduce((sum, entry) => sum + entry.valor, 0);
    const totalOutlays = cashFlow.filter(entry => entry.tipo === 'Saída').reduce((sum, entry) => sum + entry.valor, 0);
    const netCalculated = totalEntries - totalOutlays;

    const newClosure: CashRegisterClosure = {
      id: `FECH-${Date.now()}`,
      dataFechamento: new Date().toLocaleString('pt-PT', { hour12: false }),
      operador: 'Administrador (AD)',
      valorCalculado: netCalculated,
      valorInformado: valorFinal,
      observacoes: obs,
      status: 'Fechado'
    };

    setClosures(prev => [newClosure, ...prev]);
    addActivity(`Sessão de caixa encerrada e auditada pelo operador. Diferença: ${config.moeda}${(valorFinal - netCalculated).toFixed(2)}`, 'financeiro');
    showNotification('Sessão de caixa encerrada com sucesso!');
  };

  // Complete POS sale transaction
  const handleCompleteSale = (
    cartItems: CartItem[], 
    total: number, 
    clienteNome: string, 
    clienteNif: string, 
    pagamentos: { metodo: string; valor: number }[],
    valorPago: number,
    troco: number
  ) => {
    // Deduct stock in state
    setProducts(prevProducts => {
      return prevProducts.map(p => {
        const cartItem = cartItems.find(item => item.id === p.id);
        if (cartItem) {
          return { ...p, stock: Math.max(0, p.stock - cartItem.quantidade) };
        }
        return p;
      });
    });

    const saleIdNum = Math.floor(100000 + Math.random() * 900000);
    const saleId = `FT-${saleIdNum}`;
    const timeString = new Date().toLocaleString('pt-PT', { hour12: false });
    
    // Create Sale Document
    const subtotalValue = cartItems.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
    const ivaValue = subtotalValue * (config.iva / 100);

    const metodosStr = pagamentos.map(p => `${p.metodo} (${config.moeda}${p.valor.toFixed(2)})`).join(' + ');

    const newSale: Sale = {
      id: saleId,
      data: timeString,
      items: cartItems,
      subtotal: subtotalValue,
      iva: ivaValue,
      total,
      metodoPagamento: metodosStr || 'Dinheiro',
      clienteNome,
      clienteNif,
      valorPago,
      troco,
      pagamentoDetalhado: pagamentos
    };

    setSales(prev => [newSale, ...prev]);

    // Create CashFlow Entry
    const newEntry: CashFlowEntry = {
      id: Date.now(),
      data: timeString,
      tipo: 'Entrada',
      descricao: `Venda POS #${saleId} [${metodosStr || 'Dinheiro'}]`,
      valor: total,
      responsavel: 'Admin',
    };
    setCashFlow(prev => [newEntry, ...prev]);

    // Insert Log Activity
    addActivity(`Venda POS #${saleId} concluída — Total: ${config.moeda}${total.toFixed(2)} (${metodosStr || 'Dinheiro'})`, 'venda');
    showNotification(`Transação finalizada com sucesso! Factura ${saleId} gerada.`);
    
    // Open printable invoice view
    setCurrentInvoice(newSale);
    setActiveTab('facturas'); // Switch to Invoice Registry
  };

  // Modal Submission Forms Handlers
  const handleAddProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const codigo = fd.get('codigo') as string;
    const nome = fd.get('nome') as string;
    const categoria = fd.get('categoria') as string;
    const preco = parseFloat(fd.get('preco') as string);
    const stock = parseInt(fd.get('stock') as string);
    const armazem = fd.get('armazem') as string;
    const lote = fd.get('lote') as string || undefined;
    const validade = fd.get('validade') as string || undefined;
    const stockMinimoInput = fd.get('stockMinimo') as string;
    const stockMinimo = stockMinimoInput ? parseInt(stockMinimoInput) : undefined;

    const newProd: Product = {
      id: Date.now(),
      codigo,
      nome,
      categoria,
      preco,
      stock,
      armazem,
      lote,
      validade,
      stockMinimo,
      imagem: uploadedProdImage || 'https://image.qwenlm.ai/public_source/54ca21d2-3a9c-4834-b13d-5d0d25d78a73/1d12ae3eb-57d9-405e-9dcf-e246747a74bd.png',
    };

    setProducts(prev => [...prev, newProd]);
    addActivity(`Medicamento adicionado ao stock: ${nome}`, 'sistema');
    showNotification(`Produto ${nome} registado com sucesso!`);
    
    // Clear product image state and close modal
    setUploadedProdImage(null);
    setImageCompressionInfo(null);
    setActiveModal(null);
  };

  const handleAddClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const nome = fd.get('nome') as string;
    const email = fd.get('email') as string;
    const telefone = fd.get('telefone') as string;
    const nif = fd.get('nif') as string;

    const newClient: Client = {
      id: Date.now(),
      nome,
      email,
      telefone,
      nif,
      totalCompras: 0,
    };

    setClients(prev => [...prev, newClient]);
    addActivity(`Novo cliente registado no CRM: ${nome}`, 'sistema');
    showNotification(`Cliente ${nome} cadastrado!`);
    setActiveModal(null);
  };

  const handleAddSupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const nome = fd.get('nome') as string;
    const contacto = fd.get('contacto') as string;
    const email = fd.get('email') as string;
    const nif = fd.get('nif') as string;

    const newSupplier: Supplier = {
      id: Date.now(),
      nome,
      contacto,
      email,
      nif,
      produtos: 0,
    };

    setSuppliers(prev => [...prev, newSupplier]);
    addActivity(`Novo fornecedor cadastrado: ${nome}`, 'sistema');
    showNotification(`Fornecedor ${nome} adicionado com sucesso!`);
    setActiveModal(null);
  };

  const handleAddWarehouseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const nome = fd.get('nome') as string;
    const localizacao = fd.get('localizacao') as string;
    const capacidade = parseInt(fd.get('capacidade') as string);
    const responsavel = fd.get('responsavel') as string;

    const newWh: Warehouse = {
      id: Date.now(),
      nome,
      localizacao,
      capacidade,
      produtos: 0,
      responsavel,
    };

    setWarehouses(prev => [...prev, newWh]);
    addActivity(`Novo depósito logístico criado: ${nome}`, 'logistica');
    showNotification(`Armazém ${nome} cadastrado com sucesso!`);
    setActiveModal(null);
  };

  const handleAddTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const origem = fd.get('origem') as string;
    const destino = fd.get('destino') as string;
    const produto = fd.get('produto') as string;
    const quantidade = parseInt(fd.get('quantidade') as string);

    if (origem === destino) {
      alert('O armazém de origem e destino não podem ser idênticos!');
      return;
    }

    const newTr: Transfer = {
      id: Date.now(),
      data: new Date().toISOString().split('T')[0],
      origem,
      destino,
      produto,
      quantidade,
      status: 'Pendente',
    };

    setTransfers(prev => [newTr, ...prev]);
    addActivity(`Ordem de transferência criada: ${quantidade} un. de ${produto}`, 'logistica');
    showNotification('Ordem de transferência inter-armazém enviada!');
    setActiveModal(null);
  };

  const handleAddOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const fornecedor = fd.get('fornecedor') as string;
    const produtosStr = fd.get('produtos') as string;
    const valor = parseFloat(fd.get('valor') as string);

    const newOrder: Order = {
      id: Date.now(),
      data: new Date().toISOString().split('T')[0],
      fornecedor,
      produtos: produtosStr,
      valor,
      status: 'Pendente',
    };

    setOrders(prev => [newOrder, ...prev]);
    addActivity(`Ordem de compra criada para ${fornecedor}`, 'logistica');
    showNotification(`Pedido de compra para ${fornecedor} registado!`);
    setActiveModal(null);
  };

  const handleAddCashEntrySubmit = (e: React.FormEvent, tipo: 'Entrada' | 'Saída') => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const descricao = fd.get('descricao') as string;
    const valor = parseFloat(fd.get('valor') as string);

    const newFlow: CashFlowEntry = {
      id: Date.now(),
      data: new Date().toLocaleString('pt-PT', { hour12: false }),
      tipo,
      descricao,
      valor,
      responsavel: 'Admin',
    };

    setCashFlow(prev => [newFlow, ...prev]);
    addActivity(`${tipo} de caixa registada manualmente: ${descricao} (${config.moeda}${valor.toFixed(2)})`, 'financeiro');
    showNotification(`Movimento de ${tipo} de ${config.moeda}${valor.toFixed(2)} registado.`);
    setActiveModal(null);
  };

  const handleAddUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCompany) return;
    const fd = new FormData(e.currentTarget as HTMLFormElement);
    const nome = fd.get('nome') as string;
    const email = fd.get('email') as string;
    const cargo = fd.get('cargo') as User['cargo'];
    const pin = (fd.get('pin') as string) || '1234';
    const password = (fd.get('password') as string) || '1234';

    const newUser: User = {
      id: Date.now(),
      companyId: currentCompany.id,
      nome,
      email,
      cargo,
      status: 'Ativo',
      ultimoAcesso: '-',
      pin,
      password,
    };

    setUsers(prev => [...prev, newUser]);
    await EmployeeService.saveEmployee(currentCompany.id, newUser);
    addActivity(`Novo utilizador convidado: ${nome} (${cargo})`, 'sistema');
    showNotification(`O utilizador ${nome} foi registado com sucesso.`);
    setActiveModal(null);
  };

  const handleCompanyPortalLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCompError('');
    try {
      const company = await CompanyService.loginCompany(compNameInput, compEmailInput, compPassInput);
      if (company) {
        setCurrentCompany(company);
        setIsLocked(false);
        showNotification(`Sessão iniciada com sucesso na empresa: ${company.nome}`);
        setCompNameInput('');
        setCompEmailInput('');
        setCompPassInput('');
      } else {
        setCompError('Nome da empresa, e-mail do administrador ou palavra-passe incorretos.');
      }
    } catch (err: any) {
      setCompError(err.message || 'Erro ao aceder à empresa.');
    }
  };

  const handleCompanyPortalRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setCompError('');
    if (!compNameInput.trim() || !compEmailInput.trim() || !compPassInput.trim()) {
      setCompError('Por favor preencha todos os campos obrigatórios.');
      return;
    }
    try {
      const newComp = await CompanyService.createCompany(compNameInput, compEmailInput, compPassInput);
      setCurrentCompany(newComp);
      setIsLocked(false);
      showNotification(`Empresa ${newComp.nome} criada com sucesso! Dados iniciais semeados.`);
      setCompNameInput('');
      setCompEmailInput('');
      setCompPassInput('');
    } catch (err: any) {
      setCompError(err.message || 'Erro ao registar empresa.');
    }
  };

  return (
    <AppProvider
      products={products}
      setProducts={setProducts}
      clients={clients}
      setClients={setClients}
      config={config}
      setConfig={setConfig}
      cashFlow={cashFlow}
      setCashFlow={setCashFlow}
      faturas={faturas}
      setFaturas={setFaturas}
      addActivity={(title, tipo) => addActivity(title, tipo)}
      showNotification={showNotification}
    >
      <>
      {/* ======================================================== */}
      {/* MULTI-TENANT COMPANY SELECTOR GATE (NO ACTIVE COMPANY)   */}
      {/* ======================================================== */}
      {!currentCompany && (
        <div className="fixed inset-0 min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 z-[9999] selection:bg-indigo-500/30 selection:text-indigo-200 overflow-y-auto">
          {/* Soft glowing background elements */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-indigo-600/10 blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-cyan-500/5 blur-3xl pointer-events-none"></div>

          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6 z-10 my-8">
            <div className="flex flex-col items-center space-y-2 text-center">
              <div className="w-14 h-14 rounded-2xl overflow-hidden border border-white/10 shadow-lg mb-2 bg-indigo-950 flex items-center justify-center">
                <Building2 className="h-8 w-8 text-indigo-400 animate-pulse" />
              </div>
              <h1 className="text-xl font-extrabold text-white tracking-tight">FarmaGest Multi-Empresa</h1>
              <p className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">Isolamento Completo por Inquilino</p>
              <p className="text-[11px] text-slate-400 max-w-sm mt-1">
                Crie ou aceda à sua empresa de forma independente. Funcionários e inventários são 100% isolados.
              </p>
            </div>

            {/* Portal Tab Selector */}
            <div className="flex p-1 rounded-xl bg-slate-950/60 border border-slate-850/70">
              <button
                type="button"
                onClick={() => {
                  setCompanyPortalTab('login');
                  setCompError('');
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                  companyPortalTab === 'login'
                    ? 'bg-indigo-600 text-white shadow-sm font-extrabold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Aceder à Empresa
              </button>
              <button
                type="button"
                onClick={() => {
                  setCompanyPortalTab('register');
                  setCompError('');
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                  companyPortalTab === 'register'
                    ? 'bg-indigo-600 text-white shadow-sm font-extrabold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Registar Nova Empresa
              </button>
            </div>

            {/* ERROR NOTIFICATION */}
            {compError && (
              <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-medium text-center">
                {compError}
              </div>
            )}

            {/* COMP TAB: LOGIN */}
            {companyPortalTab === 'login' && (
              <form onSubmit={handleCompanyPortalLogin} className="space-y-4 text-left">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Identificador ou Nome da Empresa</label>
                  <div className="relative">
                    <Building2 className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      required
                      placeholder="Ex: Farmácia Benfica ou 'farmacia-benfica'"
                      value={compNameInput}
                      onChange={(e) => {
                        setCompError('');
                        setCompNameInput(e.target.value);
                      }}
                      className="w-full pl-10 pr-3 py-2 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">E-mail do Administrador</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="email"
                      required
                      placeholder="admin@benfica.com"
                      value={compEmailInput}
                      onChange={(e) => {
                        setCompError('');
                        setCompEmailInput(e.target.value);
                      }}
                      className="w-full pl-10 pr-3 py-2 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Palavra-passe de Segurança</label>
                  <div className="relative">
                    <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={compPassInput}
                      onChange={(e) => {
                        setCompError('');
                        setCompPassInput(e.target.value);
                      }}
                      className="w-full pl-10 pr-3 py-2 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="h-4 w-4" /> Entrar no Sistema Isolado
                </button>
              </form>
            )}

            {/* COMP TAB: REGISTER */}
            {companyPortalTab === 'register' && (
              <form onSubmit={handleCompanyPortalRegister} className="space-y-4 text-left">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Nome da Empresa (Sua Farmácia)</label>
                  <div className="relative">
                    <Building2 className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      required
                      placeholder="Ex: Farmácia Angola Lda"
                      value={compNameInput}
                      onChange={(e) => {
                        setCompError('');
                        setCompNameInput(e.target.value);
                      }}
                      className="w-full pl-10 pr-3 py-2 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">E-mail Corporativo Admin</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="email"
                      required
                      placeholder="Ex: admin@farmaciangola.ao"
                      value={compEmailInput}
                      onChange={(e) => {
                        setCompError('');
                        setCompEmailInput(e.target.value);
                      }}
                      className="w-full pl-10 pr-3 py-2 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Criar Palavra-passe de Acesso</label>
                  <div className="relative">
                    <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="password"
                      required
                      placeholder="No mínimo 6 caracteres"
                      value={compPassInput}
                      onChange={(e) => {
                        setCompError('');
                        setCompPassInput(e.target.value);
                      }}
                      className="w-full pl-10 pr-3 py-2 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
                >
                  <Plus className="h-4 w-4" /> Criar Empresa e Iniciar Sessão
                </button>
              </form>
            )}

            {/* Quick Helper */}
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-850 text-left text-[10px] text-slate-500 leading-relaxed">
              <p className="font-bold text-indigo-400 mb-1">💡 Como funciona?</p>
              Ao registar a sua empresa, semeamos automaticamente um estoque de paracetamol, vitamina C e armazém principal para que possa simular vendas imediatamente no ecrã PDV.
            </div>

            <div className="text-[9px] text-slate-600 text-center font-mono">
              FarmaGest Pro v2.6 Enterprise | KuatelaSoft Angola
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* COMPANY LOCK SCREEN (WITH ACTIVE COMPANY AND LOCKED SCREEN) */}
      {/* ======================================================== */}
      {currentCompany && isLocked && (
        <div className="fixed inset-0 min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 z-[9999] selection:bg-indigo-500/30 selection:text-indigo-200 overflow-y-auto">
          {/* Soft glowing background elements */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-indigo-600/10 blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-cyan-500/5 blur-3xl pointer-events-none"></div>

          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6 z-10 my-8">
            <div className="flex flex-col items-center space-y-2 text-center">
              <div className="w-14 h-14 rounded-2xl overflow-hidden border border-white/10 shadow-lg mb-2 bg-indigo-950 flex items-center justify-center">
                <Building2 className="h-7 w-7 text-indigo-400" />
              </div>
              <h1 className="text-xl font-extrabold text-white tracking-tight">{currentCompany.nome}</h1>
              <p className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">Portal de Acesso Seguro</p>
            </div>

            {/* User Profile Selection */}
            <div className="space-y-2">
              <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block text-center">Selecionar Utilizador</label>
              <div className="grid grid-cols-2 gap-3 max-h-48 overflow-y-auto p-1 border border-slate-800/40 rounded-xl bg-slate-950/20">
                {users.map(u => {
                  const isSelected = currentUser?.id === u.id;
                  const initials = (u?.nome || 'Utilizador').split(' ').map(n => n?.[0] || '').join('').substring(0, 2).toUpperCase();
                  return (
                    <button
                      key={u.id}
                      type="button"
                      onClick={() => {
                        setCurrentUser(u);
                        setPinInput('');
                        setPinError('');
                        setEmailInput(u.email);
                      }}
                      className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600/10 border-indigo-500/50 shadow-md shadow-indigo-500/5'
                          : 'bg-slate-950/40 border-slate-850 hover:bg-slate-800/40'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white text-[10px] font-black flex items-center justify-center shrink-0">
                          {initials}
                        </div>
                        <div className="truncate">
                          <p className="text-xs font-bold text-white truncate">{u.nome}</p>
                          <p className="text-[9px] text-slate-500 uppercase font-mono tracking-wide truncate">{u.cargo}</p>
                        </div>
                      </div>
                      {isSelected && (
                        <div className="absolute top-1 right-1">
                          <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping"></div>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Login Tab Selectors */}
            <div className="flex p-1 rounded-xl bg-slate-950/60 border border-slate-850/70">
              <button
                type="button"
                onClick={() => {
                  setLoginTab('pin');
                  setPinError('');
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  loginTab === 'pin'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Lock className="h-3.5 w-3.5" /> PIN Rápido
              </button>
              <button
                type="button"
                onClick={() => {
                  setLoginTab('credentials');
                  setPinError('');
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  loginTab === 'credentials'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Mail className="h-3.5 w-3.5" /> Credenciais
              </button>
            </div>

            {/* LOGIN TAB: PIN CODE */}
            {loginTab === 'pin' && (
              <div className="space-y-4">
                <div className="py-1">
                  <div className="h-12 text-2xl font-bold tracking-widest text-slate-100 font-mono flex items-center justify-center bg-slate-950/60 rounded-xl border border-slate-850">
                    {pinInput ? '*'.repeat(pinInput.length) : <span className="text-slate-600 text-xs font-sans font-normal">Insira o PIN de {currentUser?.nome || 'Utilizador'}</span>}
                  </div>
                  {pinError && <p className="text-xs text-rose-400 mt-1.5 font-semibold text-center">{pinError}</p>}
                </div>

                {/* Touch Numpad */}
                <div className="grid grid-cols-3 gap-2 max-w-[280px] mx-auto">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => {
                        setPinError('');
                        if (pinInput.length < 6) setPinInput(p => p + num);
                      }}
                      className="py-2.5 rounded-xl bg-slate-950/40 border border-slate-800 hover:bg-slate-800/80 text-white font-bold text-lg active:scale-95 transition-all cursor-pointer"
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      setPinError('');
                      setPinInput('');
                    }}
                    className="py-2.5 rounded-xl bg-rose-950/10 border border-rose-900/20 hover:bg-rose-950/20 text-rose-400 font-bold text-xs active:scale-95 transition-all cursor-pointer"
                  >
                    Limpar
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPinError('');
                      if (pinInput.length < 6) setPinInput(p => p + '0');
                    }}
                    className="py-2.5 rounded-xl bg-slate-950/40 border border-slate-800 hover:bg-slate-800/80 text-white font-bold text-lg active:scale-95 transition-all cursor-pointer"
                  >
                    0
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const expectedPin = currentUser?.pin || '1234';
                      if (pinInput === expectedPin) {
                        setIsLocked(false);
                        setPinInput('');
                        addActivity(`Sessão iniciada via PIN: ${currentUser.nome} (${currentUser.cargo})`, 'sistema');
                        showNotification(`Bem-vindo de volta! Sessão autorizada para ${currentUser.nome}.`);
                      } else {
                        setPinError(`Código PIN inválido para ${currentUser?.nome}.`);
                        setPinInput('');
                      }
                    }}
                    className="py-2.5 rounded-xl bg-indigo-600/20 border border-indigo-500/30 hover:bg-indigo-600/35 text-indigo-400 font-bold text-xs active:scale-95 transition-all cursor-pointer"
                  >
                    Entrar
                  </button>
                </div>
              </div>
            )}

            {/* LOGIN TAB: EMAIL & PASSWORD CREDENTIALS */}
            {loginTab === 'credentials' && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const expectedPassword = currentUser?.password || 'admin';
                  if (passwordInput === expectedPassword) {
                    setIsLocked(false);
                    setEmailInput('');
                    setPasswordInput('');
                    addActivity(`Sessão iniciada via Credenciais: ${currentUser.nome} (${currentUser.cargo})`, 'sistema');
                    showNotification(`Autenticado com sucesso! Bem-vindo, ${currentUser.nome}.`);
                  } else {
                    setPinError('Palavra-passe incorreta. Tente novamente.');
                  }
                }}
                className="space-y-4"
              >
                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">E-mail de {currentUser?.nome}</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="email"
                      readOnly
                      value={currentUser?.email || ''}
                      className="w-full pl-10 pr-3 py-2 rounded-lg bg-slate-950/40 border border-slate-850 text-slate-400 text-xs focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Palavra-passe</label>
                  <div className="relative">
                    <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="••••••••"
                      value={passwordInput}
                      onChange={(e) => {
                        setPinError('');
                        setPasswordInput(e.target.value);
                      }}
                      className="w-full pl-10 pr-10 py-2 rounded-lg bg-slate-950/60 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                {pinError && <p className="text-xs text-rose-400 font-semibold text-center">{pinError}</p>}

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="h-4 w-4" /> Autenticar Acesso
                </button>
              </form>
            )}

            {/* Back to company selection */}
            <button
              type="button"
              onClick={() => {
                setCurrentCompany(null);
                setIsLocked(true);
                showNotification('Sessão encerrada da empresa.');
              }}
              className="w-full py-2 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-850 text-slate-400 hover:text-slate-200 font-bold text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="h-3 w-3 text-rose-400" /> Mudar de Empresa / Sair
            </button>

            {/* Hint Box with Test Credentials */}
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-850 text-left space-y-1 text-[10px] text-slate-500">
              <p className="font-bold text-slate-300">💡 Dica de Acesso Rápido:</p>
              O utilizador selecionado pode usar o seu respectivo PIN (Padrão: <span className="text-indigo-400 font-mono font-bold">1234</span>) no PIN Rápido.
            </div>

            <div className="text-[10px] text-slate-500 text-center font-mono">
              FarmaGest Pro | KuatelaSoft Angola
            </div>
          </div>
        </div>
      )}

      <div className="min-h-screen bg-slate-950 font-sans text-slate-100 flex flex-col selection:bg-indigo-500/30 selection:text-indigo-200">
      
      {/* HEADER BAR */}
      <Header 
        config={config} 
        currentUser={currentUser}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} 
        onShowNotification={showNotification}
        onLockScreen={() => {
          setIsLocked(true);
          showNotification('Sessão bloqueada. Insira o código de segurança para reatar.');
        }}
        onLogout={() => {
          setIsLocked(true);
          showNotification('Sessão encerrada com sucesso.');
          addActivity(`Sessão encerrada: ${currentUser.nome}`, 'sistema');
        }}
      />

      <div className="flex flex-1 pt-[70px]">
        {/* SIDEBAR NAVIGATION */}
        <Sidebar 
          activeTab={activeTab} 
          onNavigate={setActiveTab} 
          isOpen={sidebarOpen} 
          onToggle={() => setSidebarOpen(!sidebarOpen)}
        />

        {/* MAIN BODY LAYOUT */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 lg:ml-64 overflow-x-hidden min-h-[calc(100vh-70px)] bg-slate-950/20">
          
          {/* Active component router */}
          {activeTab === 'dashboard' ? (
            <DashboardView
              products={products}
              clients={clients}
              cashFlow={cashFlow}
              config={config}
              onNavigate={setActiveTab}
              onOpenModal={setActiveModal}
            />
          ) : activeTab === 'pos' ? (
            <POSView
              products={products}
              clients={clients}
              config={config}
              onCompleteSale={handleCompleteSale}
              onShowNotification={showNotification}
            />
          ) : activeTab === 'faturacao' ? (
            <Faturacao
              session={{
                funcionarioNome: currentUser.nome,
                username: currentUser.email,
                cargo: currentUser.cargo,
              }}
            />
          ) : (
            <ManagementView
              activeTab={activeTab}
              products={products}
              clients={clients}
              suppliers={suppliers}
              warehouses={warehouses}
              transfers={transfers}
              orders={orders}
              cashFlow={cashFlow}
              users={users}
              activities={activities}
              backups={backups}
              config={config}
              sales={sales}
              bills={bills}
              closures={closures}
              onSelectInvoice={setCurrentInvoice}
              onDeleteProduct={handleDeleteProduct}
              onDeleteClient={handleDeleteClient}
              onDeleteSupplier={handleDeleteSupplier}
              onDeleteWarehouse={handleDeleteWarehouse}
              onDeleteUser={handleDeleteUser}
              onSaveConfig={handleSaveConfig}
              onCreateBackup={handleCreateBackup}
              onOpenModal={setActiveModal}
              onShowNotification={showNotification}
              onAddBill={handleAddBill}
              onPayBill={handlePayBill}
              onCloseRegister={handleCloseRegister}
            />
          )}

          {/* Footer branding details */}
          <footer className="mt-12 pt-8 border-t border-slate-900 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 text-xs text-slate-500">
            <div className="space-y-2">
              <h5 className="font-bold text-slate-400 flex items-center gap-1.5 uppercase tracking-wide">
                <Pill className="h-4 w-4 text-indigo-400" /> {config.empresa}
              </h5>
              <p>© {config.empresa} - Software de Gestão Certificado.</p>
              <p>Licenciado para uso corporativo.</p>
            </div>
            <div className="space-y-1.5">
              <h5 className="font-bold text-slate-400 uppercase tracking-wide">Contactos de Apoio</h5>
              <p>Luanda, Angola</p>
              <p>Telemóvel: (+244) 941 70 70 61</p>
              <p>Email: suporte@nvualasot.com</p>
            </div>
            <div className="space-y-1.5">
              <h5 className="font-bold text-slate-400 uppercase tracking-wide">Plataformas</h5>
              <p>Android App Store</p>
              <p>macOS Desktop clients</p>
              <p>Windows Standalone application</p>
            </div>
            <div className="space-y-1.5">
              <h5 className="font-bold text-slate-400 uppercase tracking-wide">Legislação e NIF</h5>
              <p>Faturação Eletrónica Homologada</p>
              <p>Regras AGT aplicáveis ao regime fiscal</p>
              <p className="font-semibold text-slate-400">NIF Geral: 5401123456</p>
            </div>
          </footer>
        </main>
      </div>

      {/* FLOAT ACTION BUTTON FOR QUICK SUPPORT */}
      <div className="fixed bottom-6 right-6 z-40 group">
        <button 
          onClick={() => showNotification('Suporte de plantão ativo: ligue para (+244) 941 70 70 61')}
          className="w-14 h-14 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-all hover:scale-105 active:scale-95 cursor-pointer"
          title="Fale Conosco"
        >
          <HelpCircle className="h-6 w-6" />
        </button>
      </div>

      {/* FIXED NOTIFICATION TOAST OVERLAY */}
      {notification && (
        <div className="fixed bottom-6 left-6 z-50 p-4 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 text-sm shadow-2xl flex items-center gap-3 animate-slide-in max-w-sm">
          <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL OVERLAYS FOR CREATION FORMS */}
      {/* ======================================================== */}

      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-zoom-in">
            
            {/* Modal header */}
            <div className="px-6 py-4 border-b border-slate-850 flex items-center justify-between bg-slate-950/50">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                {activeModal === 'modal-produto' && <><Pill className="h-4.5 w-4.5 text-indigo-400" /> Registar Novo Produto</>}
                {activeModal === 'modal-cliente' && <><Users className="h-4.5 w-4.5 text-indigo-400" /> Cadastrar Novo Cliente</>}
                {activeModal === 'modal-fornecedor' && <><Factory className="h-4.5 w-4.5 text-indigo-400" /> Registar Novo Fornecedor</>}
                {activeModal === 'modal-armazem' && <><WarehouseIcon className="h-4.5 w-4.5 text-indigo-400" /> Criar Novo Armazém</>}
                {activeModal === 'modal-transferencia' && <><ArrowLeftRight className="h-4.5 w-4.5 text-indigo-400" /> Ordem de Transferência de Stock</>}
                {activeModal === 'modal-encomenda' && <><Box className="h-4.5 w-4.5 text-indigo-400" /> Nova Ordem de Compra</>}
                {activeModal === 'modal-entrada' && <><Coins className="h-4.5 w-4.5 text-emerald-400" /> Registar Entrada Manual de Caixa</>}
                {activeModal === 'modal-saida' && <><Coins className="h-4.5 w-4.5 text-rose-400" /> Registar Saída Manual de Caixa</>}
                {activeModal === 'modal-usuario' && <><UserCog className="h-4.5 w-4.5 text-indigo-400" /> Criar Utilizador de Sistema</>}
                {activeModal === 'modal-subscription' && <><CreditCard className="h-4.5 w-4.5 text-indigo-400" /> Subscrever NVUALASOT</>}
              </h3>
              <button 
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-all cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Form routing based on active modal type */}
            <div className="p-6">
              {activeModal === 'modal-produto' && (
                <form onSubmit={handleAddProductSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Código de Barras</label>
                      <input name="codigo" required placeholder="Ex: PAR500" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Nome do Medicamento</label>
                      <input name="nome" required placeholder="Ex: Paracetamol Generis 500mg" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Categoria</label>
                      <select name="categoria" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500">
                        <option value="Medicamentos">Medicamentos</option>
                        <option value="Suplementos">Suplementos</option>
                        <option value="Higiene">Higiene</option>
                        <option value="Cosméticos">Cosméticos</option>
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Preço Unitário ({config.moeda})</label>
                      <input type="number" step="0.01" name="preco" required placeholder="3.50" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Stock Inicial</label>
                      <input type="number" name="stock" required placeholder="100" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Armazém Destino</label>
                      <select name="armazem" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500">
                        {warehouses.map(w => (
                          <option key={w.id} value={w.nome}>{w.nome}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Nº de Lote (Opcional)</label>
                      <input name="lote" placeholder="Ex: LT-3240" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Validade (Opcional)</label>
                      <input type="date" name="validade" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Stock Mínimo Alerta</label>
                      <input type="number" name="stockMinimo" placeholder="Ex: 50" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>

                  {/* Carregar Imagem do Produto */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-850/50">
                    <label className="text-xs text-slate-400 font-semibold block">Imagem do Produto (carregar arquivo - compressão auto. ativa)</label>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                        {uploadedProdImage ? (
                          <img src={uploadedProdImage} alt="Preview" className="w-full h-full object-cover" />
                        ) : (
                          <Pill className="h-5 w-5 text-slate-600" />
                        )}
                      </div>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            try {
                              setIsCompressingImage(true);
                              const originalSizeStr = formatBytes(file.size);
                              
                              // Compress image using client-side canvas
                              const compressedBase64 = await compressImage(file, 200, 200, 0.65);
                              
                              // Calculate base64 size (roughly 3/4 of the string length minus header)
                              const headLen = compressedBase64.indexOf(",") + 1;
                              const compressedSizeInBytes = Math.round((compressedBase64.length - headLen) * 3 / 4);
                              const compressedSizeStr = formatBytes(compressedSizeInBytes);
                              
                              const pct = ((1 - (compressedSizeInBytes / file.size)) * 100).toFixed(1);
                              
                              setUploadedProdImage(compressedBase64);
                              setImageCompressionInfo({
                                originalSize: originalSizeStr,
                                compressedSize: compressedSizeStr,
                                percentage: pct
                              });
                              showNotification(`Imagem otimizada! Tamanho reduzido em ${pct}% (${originalSizeStr} → ${compressedSizeStr}).`);
                            } catch (err) {
                              console.error(err);
                              showNotification("Erro na compressão. Carregando imagem original.");
                              const reader = new FileReader();
                              reader.onload = (event) => {
                                if (event.target?.result) {
                                  setUploadedProdImage(event.target.result as string);
                                  setImageCompressionInfo(null);
                                }
                              };
                              reader.readAsDataURL(file);
                            } finally {
                              setIsCompressingImage(false);
                            }
                          }
                        }}
                        className="text-xs text-slate-400 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-indigo-600/20 file:text-indigo-400 hover:file:bg-indigo-600/30 cursor-pointer"
                      />
                      {uploadedProdImage && !isCompressingImage && (
                        <button
                          type="button"
                          onClick={() => {
                            setUploadedProdImage(null);
                            setImageCompressionInfo(null);
                          }}
                          className="text-[10px] text-rose-400 hover:text-rose-300 font-bold"
                        >
                          Remover
                        </button>
                      )}
                    </div>
                    {isCompressingImage && (
                      <div className="text-xs text-indigo-400 font-semibold animate-pulse flex items-center gap-1.5 pt-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping"></span>
                        <span>A otimizar e comprimir imagem...</span>
                      </div>
                    )}
                    {imageCompressionInfo && !isCompressingImage && (
                      <div className="mt-2 flex items-start gap-2 bg-emerald-950/40 border border-emerald-900/60 text-emerald-400 rounded-lg p-2.5 text-[11px]">
                        <span className="w-2 h-2 mt-0.5 bg-emerald-500 rounded-full shrink-0 animate-pulse"></span>
                        <div className="leading-normal">
                          <p className="font-bold text-emerald-300">Base de dados leve &amp; POS Rápido</p>
                          <p className="text-slate-300">Tamanho da Imagem: <span className="line-through text-slate-400">{imageCompressionInfo.originalSize}</span> → <span className="font-semibold text-emerald-300">{imageCompressionInfo.compressedSize}</span> (Menos <span className="font-bold text-emerald-300">{imageCompressionInfo.percentage}%</span> em base64)</p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Registar Produto
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-cliente' && (
                <form onSubmit={handleAddClientSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Nome Completo</label>
                      <input name="nome" required placeholder="Ex: Lucas Ferreira" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">NIF / Número Contribuinte</label>
                      <input name="nif" required placeholder="999999999" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Email do Cliente</label>
                      <input type="email" name="email" required placeholder="lucas@email.com" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Contacto de Telemóvel</label>
                      <input name="telefone" required placeholder="941707061" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Registar Cliente
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-fornecedor' && (
                <form onSubmit={handleAddSupplierSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Nome da Distribuidora</label>
                      <input name="nome" required placeholder="Ex: Pfizer SA" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">NIF Comercial</label>
                      <input name="nif" required placeholder="540112345" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Contacto de Apoio</label>
                      <input name="contacto" required placeholder="210123456" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Email Comercial</label>
                      <input type="email" name="email" required placeholder="geral@pfizer.pt" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Registar Fornecedor
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-armazem' && (
                <form onSubmit={handleAddWarehouseSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Nome do Armazém</label>
                      <input name="nome" required placeholder="Ex: Armazém Norte" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Localização Física</label>
                      <input name="localizacao" required placeholder="Porto, Portugal" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Capacidade de Lotes</label>
                      <input type="number" name="capacidade" required placeholder="8000" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Responsável Administrativo</label>
                      <input name="responsavel" required placeholder="Joaquim Santos" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Criar Instalação
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-transferencia' && (
                <form onSubmit={handleAddTransferSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Armazém de Origem</label>
                      <select name="origem" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500">
                        {warehouses.map(w => (
                          <option key={w.id} value={w.nome}>{w.nome}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Armazém de Destino</label>
                      <select name="destino" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500">
                        {warehouses.map(w => (
                          <option key={w.id} value={w.nome}>{w.nome}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Medicamento</label>
                      <select name="produto" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500">
                        {products.map(p => (
                          <option key={p.id} value={p.nome}>{p.nome}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Quantidade a Transferir</label>
                      <input type="number" name="quantidade" required placeholder="50" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Emitir Guia de Transferência
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-encomenda' && (
                <form onSubmit={handleAddOrderSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Distribuidora / Fornecedor</label>
                      <select name="fornecedor" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500">
                        {suppliers.map(s => (
                          <option key={s.id} value={s.nome}>{s.nome}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Valor da Faturação ({config.moeda})</label>
                      <input type="number" step="0.01" name="valor" required placeholder="1500.00" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs text-slate-400 font-semibold">Resumo dos Fármacos Pedidos</label>
                    <textarea name="produtos" required placeholder="Ex: 100x Paracetamol 500mg, 50x Ibuprofeno 400mg" rows={3} className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Registar Ordem de Encomenda
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-entrada' && (
                <form onSubmit={(e) => handleAddCashEntrySubmit(e, 'Entrada')} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs text-slate-400 font-semibold">Descrição do Movimento de Entrada</label>
                    <input name="descricao" required placeholder="Ex: Suprimento manual para fundo de maneio" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs text-slate-400 font-semibold">Valor em Dinheiro ({config.moeda})</label>
                    <input type="number" step="0.01" name="valor" required placeholder="100.00" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Submeter Entrada de Caixa
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-saida' && (
                <form onSubmit={(e) => handleAddCashEntrySubmit(e, 'Saída')} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs text-slate-400 font-semibold">Descrição do Pagamento / Retirada</label>
                    <input name="descricao" required placeholder="Ex: Pagamento pontual de despesas de correio" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs text-slate-400 font-semibold">Valor de Despesa ({config.moeda})</label>
                    <input type="number" step="0.01" name="valor" required placeholder="50.00" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Registar Despesa de Saída
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-usuario' && (
                <form onSubmit={handleAddUserSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Nome do Colaborador</label>
                      <input name="nome" required placeholder="Ex: Rui Abreu" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Cargo / Categoria</label>
                      <select name="cargo" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500">
                        <option value="Administrador">Administrador</option>
                        <option value="Gerente">Gerente</option>
                        <option value="Operador">Operador/Farmacêutico</option>
                        <option value="Caixa">Operador de Caixa</option>
                      </select>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs text-slate-400 font-semibold">Endereço de Email de Acesso</label>
                    <input type="email" name="email" required placeholder={`rui@${config.empresa.toLowerCase().replace(/\s+/g, '')}.com`} className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Código PIN (Acesso Rápido - 4 dígitos)</label>
                      <input name="pin" maxLength={4} pattern="\d{4}" required placeholder="1234" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs text-slate-400 font-semibold">Palavra-passe (Login por Credenciais)</label>
                      <input type="password" name="password" required placeholder="••••••••" className="w-full px-3 py-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-100 text-xs focus:outline-none focus:border-indigo-500" />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex justify-end">
                    <button type="submit" className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all cursor-pointer">
                      Emitir Convite de Utilizador
                    </button>
                  </div>
                </form>
              )}

              {activeModal === 'modal-subscription' && (
                <div className="space-y-4 text-center">
                  <div className="mx-auto w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 flex items-center justify-center">
                    <CreditCard className="h-6 w-6" />
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-sm font-bold text-white">Consolidar Renovação {config.empresa}</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      A sua licença profissional expira dentro de 7 dias. Ao subscrever por €29.90/mês, desbloqueia backups ilimitados em nuvem e suporte premium 24h por telefone.
                    </p>
                  </div>
                  <div className="pt-4 border-t border-slate-850 flex gap-2">
                    <button 
                      onClick={() => {
                        setActiveModal(null);
                        addActivity('Subscrição anual renovada com sucesso!', 'sistema');
                        showNotification('Obrigado! Subscrição profissional estendida por mais 12 meses.');
                      }} 
                      className="flex-1 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all cursor-pointer"
                    >
                      Assinar Plano Mensal (€29.90)
                    </button>
                    <button 
                      onClick={() => setActiveModal(null)} 
                      className="px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-semibold transition-all cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* INVOICE PRINT PREVIEW MODAL overlay */}
      {currentInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto no-print">
          <div className="w-full max-w-2xl bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-8">
            {/* Modal Header Actions */}
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <span className="font-bold text-sm tracking-wider uppercase">Visualização da Factura</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <CheckCircle className="h-4 w-4" /> Imprimir (Ctrl+P)
                </button>
                <button
                  onClick={() => setCurrentInvoice(null)}
                  className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Printable Invoice Page */}
            <div id="printable-invoice" className="p-8 space-y-6 bg-white select-text">
              {/* Company & Document Header */}
              <div className="flex justify-between items-start border-b border-slate-200 pb-5">
                <div className="space-y-1">
                  <h2 className="text-xl font-black uppercase text-indigo-700 tracking-tight">{config.empresa}</h2>
                  <p className="text-xs text-slate-500 font-medium">{config.endereco}</p>
                  <p className="text-xs text-slate-500 font-mono">NIF: {config.nif}</p>
                  <p className="text-xs text-slate-500 font-mono">Tel: {config.telefone} | Email: {config.email}</p>
                </div>
                <div className="text-right space-y-1">
                  <span className="inline-block px-2.5 py-1 rounded bg-indigo-50 text-[10px] font-bold text-indigo-800 border border-indigo-100">
                    SISTEMA CERTIFICADO - REPUBLICA DE ANGOLA
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 font-mono pt-1">{currentInvoice.id}</h3>
                  <p className="text-xs text-slate-500">Data de Emissão: <span className="font-mono text-slate-700 font-medium">{currentInvoice.data}</span></p>
                </div>
              </div>

              {/* Client Info Block */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-150">
                <div className="space-y-0.5">
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Adquirente (Cliente)</span>
                  <p className="text-sm font-bold text-slate-800">{currentInvoice.clienteNome || 'Consumidor Final'}</p>
                </div>
                <div className="space-y-0.5 text-right">
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">NIF do Adquirente</span>
                  <p className="text-sm font-mono font-semibold text-slate-700">{currentInvoice.clienteNif || '999999999'}</p>
                </div>
              </div>

              {/* Table of items */}
              <div className="space-y-2">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b-2 border-slate-200 text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                      <th className="py-2.5">Descrição do Item</th>
                      <th className="py-2.5 text-center">Quant.</th>
                      <th className="py-2.5 text-right">P. Unitário</th>
                      <th className="py-2.5 text-right">Total Liquido</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentInvoice.items.map((item, idx) => (
                      <tr key={idx} className="border-b border-slate-100 text-slate-700 text-xs">
                        <td className="py-2.5 font-semibold text-slate-800">{item.nome}</td>
                        <td className="py-2.5 text-center font-mono">{item.quantidade}</td>
                        <td className="py-2.5 text-right font-mono">{config.moeda}{item.preco.toFixed(2)}</td>
                        <td className="py-2.5 text-right font-mono font-semibold text-slate-900">{config.moeda}{(item.preco * item.quantidade).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Calculations block */}
              <div className="pt-4 border-t border-slate-200 grid grid-cols-2 gap-4">
                <div className="space-y-1.5 text-xs text-slate-500 font-medium">
                  <p>Forma de Pagamento: <span className="font-bold text-slate-700">{currentInvoice.metodoPagamento}</span></p>
                  
                  {currentInvoice.pagamentoDetalhado && currentInvoice.pagamentoDetalhado.length > 0 ? (
                    <div className="mt-1.5 pt-1.5 border-t border-slate-100 space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Detalhamento dos Meios:</p>
                      {currentInvoice.pagamentoDetalhado.map((p, idx) => (
                        <p key={idx} className="text-xs text-slate-600">
                          • {p.metodo}: <span className="font-mono font-semibold text-slate-700">{config.moeda}{p.valor.toFixed(2)}</span>
                        </p>
                      ))}
                      {currentInvoice.troco > 0 && (
                        <p className="text-xs text-slate-600">
                          • Troco Entregue: <span className="font-mono font-semibold text-emerald-600">{config.moeda}{currentInvoice.troco.toFixed(2)}</span>
                        </p>
                      )}
                    </div>
                  ) : (
                    currentInvoice.metodoPagamento === 'Dinheiro' && (
                      <>
                        <p>Valor Pago: <span className="font-mono text-slate-700">{config.moeda}{currentInvoice.valorPago?.toFixed(2)}</span></p>
                        <p>Troco: <span className="font-mono text-slate-700">{config.moeda}{currentInvoice.troco?.toFixed(2)}</span></p>
                      </>
                    )
                  )}
                  <p className="text-[10px] text-slate-400 pt-1">Obrigado pela sua preferência!</p>
                </div>

                <div className="space-y-2 text-right">
                  <div className="flex justify-between text-xs text-slate-500 font-medium pl-12">
                    <span>Subtotal</span>
                    <span className="font-mono">{config.moeda}{currentInvoice.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-500 font-medium pl-12">
                    <span>Taxa IVA ({config.iva}%)</span>
                    <span className="font-mono">{config.moeda}{currentInvoice.iva.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-slate-200 font-black text-slate-900 pl-12">
                    <span className="text-xs uppercase">Total Pago</span>
                    <span className="font-mono text-base text-indigo-750">{config.moeda}{currentInvoice.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Legal Note footer */}
              <div className="pt-6 border-t border-dashed border-slate-200 text-center space-y-1">
                <p className="text-[9px] text-slate-400 font-semibold tracking-wide uppercase">Este documento não serve de fatura</p>
                <p className="text-[8px] text-slate-400 font-mono">Processado por software validado nº 075/AGT/2026 — NVUALASOT | KuatelaSoft</p>
              </div>
            </div>

            {/* Bottom Actions for user */}
            <div className="bg-slate-50 p-4 border-t border-slate-250 flex justify-end gap-2">
              <button
                onClick={() => setCurrentInvoice(null)}
                className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition-colors cursor-pointer animate-none"
              >
                Fechar Visualização
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-indigo-600/10"
              >
                <CheckCircle className="h-4 w-4" /> Imprimir Documento
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
    </>
    </AppProvider>
  );
}

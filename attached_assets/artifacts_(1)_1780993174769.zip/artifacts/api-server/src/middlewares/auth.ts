import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.SESSION_SECRET || "lab-dev-secret-2024";

export interface AuthPayload {
  role: "developer" | "funcionario" | "parceiro";
  empresaId?: number;
  empresaNome?: string;
  username: string;
  funcao?: string;
  funcionarioId?: number;
  funcionarioNome?: string;
  parceiroId?: number;
  parceiroNome?: string;
  parceiroInstituicao?: string;
}

declare global {
  namespace Express {
    interface Request {
      auth?: AuthPayload;
    }
  }
}

export function signToken(payload: AuthPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "30d" });
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Não autenticado" });
    return;
  }
  const token = authHeader.slice(7);
  try {
    req.auth = jwt.verify(token, JWT_SECRET) as AuthPayload;
    next();
  } catch {
    res.status(401).json({ error: "Token inválido" });
  }
}

export function requireDeveloper(req: Request, res: Response, next: NextFunction): void {
  if (!req.auth || req.auth.role !== "developer") {
    res.status(403).json({ error: "Acesso restrito a administradores." });
    return;
  }
  next();
}

export function requireEmpresa(req: Request, res: Response, next: NextFunction): void {
  if (!req.auth || (req.auth.role !== "funcionario" && req.auth.role !== "developer")) {
    res.status(403).json({ error: "Acesso negado." });
    return;
  }
  next();
}

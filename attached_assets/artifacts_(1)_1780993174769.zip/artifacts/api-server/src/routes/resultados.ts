import { Router } from "express";
import { db } from "@workspace/db";
import { resultadosTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireEmpresa } from "../middlewares/auth";

const router = Router();
router.use(requireAuth, requireEmpresa);

function getEmpresaId(req: any): number { return req.auth.empresaId as number; }

router.get("/resultados", async (req, res) => {
  try {
    const rows = await db.select().from(resultadosTable).where(eq(resultadosTable.empresaId, getEmpresaId(req))).orderBy(resultadosTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/resultados", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const [row] = await db.insert(resultadosTable).values({
      empresaId: getEmpresaId(req),
      pacienteId: Number(body.pacienteId),
      pacienteNome: body.pacienteNome || "",
      data: body.data || "",
      dataEmissao: body.dataEmissao || "",
      parametros: Array.isArray(body.parametros) ? body.parametros : [],
      tecnicoNome: body.tecnicoNome || "",
    }).returning();
    res.status(201).json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/resultados/:id", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const updates: Partial<typeof resultadosTable.$inferInsert> = {};
    if (body.pacienteId !== undefined) updates.pacienteId = Number(body.pacienteId);
    if (body.pacienteNome !== undefined) updates.pacienteNome = body.pacienteNome;
    if (body.data !== undefined) updates.data = body.data;
    if (body.dataEmissao !== undefined) updates.dataEmissao = body.dataEmissao;
    if (body.parametros !== undefined) updates.parametros = Array.isArray(body.parametros) ? body.parametros : [];
    if (body.tecnicoNome !== undefined) updates.tecnicoNome = body.tecnicoNome;
    const [row] = await db.update(resultadosTable).set(updates)
      .where(and(eq(resultadosTable.id, Number(req.params.id)), eq(resultadosTable.empresaId, getEmpresaId(req)))).returning();
    if (!row) return void res.status(404).json({ error: "Resultado não encontrado." });
    res.json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/resultados/:id", async (req, res) => {
  try {
    await db.delete(resultadosTable).where(and(
      eq(resultadosTable.id, Number(req.params.id)),
      eq(resultadosTable.empresaId, getEmpresaId(req)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

export default router;

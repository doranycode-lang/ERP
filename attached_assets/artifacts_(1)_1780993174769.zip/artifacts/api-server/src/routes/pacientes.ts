import { Router } from "express";
import { db } from "@workspace/db";
import { pacientesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireEmpresa } from "../middlewares/auth";

const router = Router();
router.use(requireAuth, requireEmpresa);

function getEmpresaId(req: any): number {
  return req.auth.empresaId as number;
}

router.get("/pacientes", async (req, res) => {
  try {
    const rows = await db.select().from(pacientesTable).where(eq(pacientesTable.empresaId, getEmpresaId(req))).orderBy(pacientesTable.id);
    res.json(rows.map(toClient));
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/pacientes", async (req, res) => {
  try {
    const empresaId = getEmpresaId(req);
    const body = req.body as Record<string, any>;
    const [row] = await db.insert(pacientesTable).values({
      empresaId, nome: body.nome || "", nasc: body.nasc || "", sexo: body.sexo || "",
      idade: body.idade || "", bi: body.bi || "", nif: body.nif || "",
      nacionalidade: body.nacionalidade || "Angolana", estadoCivil: body.estadoCivil || "",
      profissao: body.profissao || "", telefone: body.telefone || "", telefone2: body.telefone2 || "",
      email: body.email || "", endereco: body.endereco || "", grupoSanguineo: body.grupoSanguineo || "",
      fatorRh: body.fatorRh || "", alergias: body.alergias || "",
      patologiasCronicas: body.patologiasCronicas || "", medicacaoHabitual: body.medicacaoHabitual || "",
      contactoEmergenciaNome: body.contactoEmergenciaNome || "", contactoEmergenciaTel: body.contactoEmergenciaTel || "",
      empresa: body.empresa || "", processo: body.processo || "", medico: body.medico || "",
      nAmostra: body.nAmostra || "", recolha: body.recolha || "",
    }).returning();
    res.status(201).json(toClient(row));
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/pacientes/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const empresaId = getEmpresaId(req);
    const body = req.body as Record<string, any>;
    const fields: Partial<typeof pacientesTable.$inferInsert> = {};
    const strings = ["nome","nasc","sexo","idade","bi","nif","nacionalidade","estadoCivil","profissao",
      "telefone","telefone2","email","endereco","grupoSanguineo","fatorRh","alergias",
      "patologiasCronicas","medicacaoHabitual","contactoEmergenciaNome","contactoEmergenciaTel",
      "empresa","processo","medico","nAmostra","recolha"] as const;
    for (const k of strings) { if (k in body) (fields as any)[k] = body[k] ?? ""; }
    const [row] = await db.update(pacientesTable).set(fields)
      .where(and(eq(pacientesTable.id, id), eq(pacientesTable.empresaId, empresaId))).returning();
    if (!row) return void res.status(404).json({ error: "Paciente não encontrado." });
    res.json(toClient(row));
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/pacientes/:id", async (req, res) => {
  try {
    await db.delete(pacientesTable).where(and(
      eq(pacientesTable.id, Number(req.params.id)),
      eq(pacientesTable.empresaId, getEmpresaId(req)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

function toClient(row: typeof pacientesTable.$inferSelect) {
  return {
    id: row.id, nome: row.nome, nasc: row.nasc, sexo: row.sexo, idade: row.idade,
    bi: row.bi, nif: row.nif, nacionalidade: row.nacionalidade, estadoCivil: row.estadoCivil,
    profissao: row.profissao, telefone: row.telefone, telefone2: row.telefone2,
    email: row.email, endereco: row.endereco, grupoSanguineo: row.grupoSanguineo,
    fatorRh: row.fatorRh, alergias: row.alergias, patologiasCronicas: row.patologiasCronicas,
    medicacaoHabitual: row.medicacaoHabitual, contactoEmergenciaNome: row.contactoEmergenciaNome,
    contactoEmergenciaTel: row.contactoEmergenciaTel, empresa: row.empresa,
    processo: row.processo, medico: row.medico, nAmostra: row.nAmostra, recolha: row.recolha,
  };
}

export default router;

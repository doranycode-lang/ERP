import { Router } from "express";
import { db } from "@workspace/db";
import { devUsersTable, funcionariosTable, parceirosTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, signToken } from "../middlewares/auth";
import { hashPassword, verifyPassword, generateTempPassword } from "../lib/password";
import { logger } from "../lib/logger";

const router = Router();

router.post("/auth/login", async (req, res) => {
  const { username, password } = req.body as { username: string; password: string };
  if (!username || !password) {
    return res.status(400).json({ error: "Utilizador e senha são obrigatórios." });
  }

  try {
    const devUsers = await db.select().from(devUsersTable).where(eq(devUsersTable.username, username));
    if (devUsers.length > 0) {
      const u = devUsers[0];
      if (!verifyPassword(password, u.passwordHash)) return res.status(401).json({ error: "Credenciais inválidas." });
      const token = signToken({ role: "developer", username: u.username });
      return res.json({ token, role: "developer", username: u.username });
    }

    const funcs = await db.select().from(funcionariosTable).where(eq(funcionariosTable.username, username));
    if (funcs.length > 0) {
      const f = funcs[0];
      if (!f.ativo) return res.status(401).json({ error: "Conta inactiva." });
      if (!verifyPassword(password, f.passwordHash)) return res.status(401).json({ error: "Credenciais inválidas." });
      const token = signToken({
        role: "funcionario",
        empresaId: f.empresaId,
        username: f.username,
        funcao: f.funcao,
        funcionarioId: f.id,
        funcionarioNome: f.nome,
      });
      return res.json({ token, role: "funcionario", empresaId: String(f.empresaId), username: f.username, funcao: f.funcao, funcionarioId: String(f.id), funcionarioNome: f.nome });
    }

    const pars = await db.select().from(parceirosTable).where(eq(parceirosTable.username, username));
    if (pars.length > 0) {
      const p = pars[0];
      if (!p.ativo) return res.status(401).json({ error: "Conta inactiva." });
      if (!verifyPassword(password, p.passwordHash)) return res.status(401).json({ error: "Credenciais inválidas." });
      const token = signToken({
        role: "parceiro",
        empresaId: p.empresaId,
        username: p.username,
        parceiroId: p.id,
        parceiroNome: p.nome,
        parceiroInstituicao: p.instituicao,
      });
      return res.json({ token, role: "parceiro", empresaId: String(p.empresaId), username: p.username, parceiroId: String(p.id), parceiroNome: p.nome, parceiroInstituicao: p.instituicao });
    }

    return res.status(401).json({ error: "Credenciais inválidas." });
  } catch (err) {
    req.log.error({ err }, "login error");
    return res.status(500).json({ error: "Erro interno." });
  }
});

router.post("/auth/logout", (_req, res) => {
  res.json({ ok: true });
});

router.get("/auth/me", requireAuth, (req, res) => {
  res.json(req.auth);
});

router.post("/auth/change-password", requireAuth, async (req, res) => {
  const { currentPassword, newPassword } = req.body as { currentPassword: string; newPassword: string };
  if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: "A nova senha deve ter pelo menos 6 caracteres." });
  const auth = req.auth!;
  try {
    if (auth.role === "funcionario" && auth.funcionarioId) {
      const rows = await db.select().from(funcionariosTable).where(eq(funcionariosTable.id, auth.funcionarioId));
      if (!rows.length) return res.status(404).json({ error: "Utilizador não encontrado." });
      if (!verifyPassword(currentPassword, rows[0].passwordHash)) return res.status(401).json({ error: "Senha actual incorrecta." });
      await db.update(funcionariosTable).set({ passwordHash: hashPassword(newPassword) }).where(eq(funcionariosTable.id, auth.funcionarioId));
      return res.json({ ok: true });
    }
    if (auth.role === "parceiro" && auth.parceiroId) {
      const rows = await db.select().from(parceirosTable).where(eq(parceirosTable.id, auth.parceiroId));
      if (!rows.length) return res.status(404).json({ error: "Utilizador não encontrado." });
      if (!verifyPassword(currentPassword, rows[0].passwordHash)) return res.status(401).json({ error: "Senha actual incorrecta." });
      await db.update(parceirosTable).set({ passwordHash: hashPassword(newPassword) }).where(eq(parceirosTable.id, auth.parceiroId));
      return res.json({ ok: true });
    }
    return res.status(400).json({ error: "Não suportado para este tipo de conta." });
  } catch (err) {
    req.log.error({ err }, "change-password error");
    return res.status(500).json({ error: "Erro interno." });
  }
});

export default router;

import { Router } from "express";
import { db } from "@workspace/db";
import { faturasTable, configTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireEmpresa } from "../middlewares/auth";

const router = Router();
router.use(requireAuth, requireEmpresa);

function getEmpresaId(req: any): number { return req.auth.empresaId as number; }

router.get("/faturas", async (req, res) => {
  try {
    const rows = await db.select().from(faturasTable).where(eq(faturasTable.empresaId, getEmpresaId(req))).orderBy(faturasTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/faturas", async (req, res) => {
  try {
    const empresaId = getEmpresaId(req);
    const body = req.body as Record<string, any>;

    const cfgRows = await db.select().from(configTable).where(eq(configTable.empresaId, empresaId));
    const cfg = cfgRows[0];
    const nextNum = cfg?.proximoNumeroFatura ?? 1;
    const serie = cfg?.serie || "FT";
    const numero = `${serie} ${new Date().getFullYear()}/${String(nextNum).padStart(4, "0")}`;

    if (cfg) {
      await db.update(configTable).set({ proximoNumeroFatura: nextNum + 1 }).where(eq(configTable.empresaId, empresaId));
    }

    const [row] = await db.insert(faturasTable).values({
      empresaId, numero, serie: body.serie || serie,
      data: body.data || "", dataVencimento: body.dataVencimento || "",
      clienteNome: body.clienteNome || "Consumidor Final", clienteNif: body.clienteNif || "",
      clienteEndereco: body.clienteEndereco || "",
      linhas: Array.isArray(body.linhas) ? body.linhas : [],
      subtotalSemIva: Number(body.subtotalSemIva) || 0,
      totalIva: Number(body.totalIva) || 0,
      ivaTaxa: Number(body.ivaTaxa) || 0,
      total: Number(body.total) || 0,
      estado: body.estado || "rascunho",
      observacoes: body.observacoes || "",
      pacienteId: body.pacienteId ? Number(body.pacienteId) : null,
      resultadoId: body.resultadoId ? Number(body.resultadoId) : null,
      emitidoPor: body.emitidoPor || req.auth?.funcionarioNome || "",
    }).returning();
    res.status(201).json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/faturas/:id", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const updates: Partial<typeof faturasTable.$inferInsert> = {};
    const fields = ["data","dataVencimento","clienteNome","clienteNif","clienteEndereco","estado","observacoes","emitidoPor","serie","numero"] as const;
    for (const f of fields) if (f in body) (updates as any)[f] = body[f];
    if (body.linhas !== undefined) updates.linhas = Array.isArray(body.linhas) ? body.linhas : [];
    if (body.subtotalSemIva !== undefined) updates.subtotalSemIva = Number(body.subtotalSemIva);
    if (body.totalIva !== undefined) updates.totalIva = Number(body.totalIva);
    if (body.ivaTaxa !== undefined) updates.ivaTaxa = Number(body.ivaTaxa);
    if (body.total !== undefined) updates.total = Number(body.total);
    if (body.pacienteId !== undefined) updates.pacienteId = body.pacienteId ? Number(body.pacienteId) : null;
    const [row] = await db.update(faturasTable).set(updates)
      .where(and(eq(faturasTable.id, Number(req.params.id)), eq(faturasTable.empresaId, getEmpresaId(req)))).returning();
    if (!row) return void res.status(404).json({ error: "Fatura não encontrada." });
    res.json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/faturas/:id", async (req, res) => {
  try {
    await db.delete(faturasTable).where(and(
      eq(faturasTable.id, Number(req.params.id)),
      eq(faturasTable.empresaId, getEmpresaId(req)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

export default router;

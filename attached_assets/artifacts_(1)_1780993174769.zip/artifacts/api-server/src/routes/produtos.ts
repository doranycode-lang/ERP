import { Router } from "express";
import { db } from "@workspace/db";
import { produtosTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireEmpresa } from "../middlewares/auth";

const router = Router();
router.use(requireAuth, requireEmpresa);

function getEmpresaId(req: any): number { return req.auth.empresaId as number; }

router.get("/produtos", async (req, res) => {
  try {
    const rows = await db.select().from(produtosTable).where(eq(produtosTable.empresaId, getEmpresaId(req))).orderBy(produtosTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/produtos", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const [row] = await db.insert(produtosTable).values({
      empresaId: getEmpresaId(req),
      codigo: body.codigo || "", nome: body.nome || "", categoria: body.categoria || "",
      preco: Number(body.preco) || 0, ivaIsento: body.ivaIsento !== false,
      descricao: body.descricao || "", ativo: body.ativo !== false,
    }).returning();
    res.status(201).json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/produtos/:id", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const updates: Partial<typeof produtosTable.$inferInsert> = {};
    if (body.codigo !== undefined) updates.codigo = body.codigo;
    if (body.nome !== undefined) updates.nome = body.nome;
    if (body.categoria !== undefined) updates.categoria = body.categoria;
    if (body.preco !== undefined) updates.preco = Number(body.preco);
    if (body.ivaIsento !== undefined) updates.ivaIsento = body.ivaIsento;
    if (body.descricao !== undefined) updates.descricao = body.descricao;
    if (body.ativo !== undefined) updates.ativo = body.ativo;
    const [row] = await db.update(produtosTable).set(updates)
      .where(and(eq(produtosTable.id, Number(req.params.id)), eq(produtosTable.empresaId, getEmpresaId(req)))).returning();
    if (!row) return void res.status(404).json({ error: "Produto não encontrado." });
    res.json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/produtos/:id", async (req, res) => {
  try {
    await db.delete(produtosTable).where(and(
      eq(produtosTable.id, Number(req.params.id)),
      eq(produtosTable.empresaId, getEmpresaId(req)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

export default router;

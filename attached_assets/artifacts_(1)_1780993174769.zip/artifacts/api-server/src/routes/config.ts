import { Router } from "express";
import { db } from "@workspace/db";
import { configTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireEmpresa } from "../middlewares/auth";

const router = Router();
router.use(requireAuth, requireEmpresa);

function getEmpresaId(req: any): number { return req.auth.empresaId as number; }

const DEFAULT_CONFIG = {
  nomeClinica: "Laboratório de Análises Clínicas",
  nif: "", endereco: "Luanda, Angola", telefone: "900 000 000",
  email: "", directorTecnico: "Director Técnico", logoData: "", assinaturaData: "",
  serie: "A", proximoNumeroFatura: 1, ivaTaxa: 14, moeda: "AOA", website: "",
};

router.get("/config", async (req, res) => {
  try {
    const rows = await db.select().from(configTable).where(eq(configTable.empresaId, getEmpresaId(req)));
    res.json(rows[0] ? toClient(rows[0]) : DEFAULT_CONFIG);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/config", async (req, res) => {
  try {
    const empresaId = getEmpresaId(req);
    const body = req.body as Record<string, any>;
    const updates: Partial<typeof configTable.$inferInsert> = {};
    const strings = ["nomeClinica","nif","endereco","telefone","email","directorTecnico","logoData","assinaturaData","serie","moeda","website"] as const;
    for (const f of strings) if (f in body) (updates as any)[f] = body[f];
    if (body.proximoNumeroFatura !== undefined) updates.proximoNumeroFatura = Number(body.proximoNumeroFatura);
    if (body.ivaTaxa !== undefined) updates.ivaTaxa = Number(body.ivaTaxa);

    const existing = await db.select().from(configTable).where(eq(configTable.empresaId, empresaId));
    let row;
    if (existing.length > 0) {
      [row] = await db.update(configTable).set(updates).where(eq(configTable.empresaId, empresaId)).returning();
    } else {
      [row] = await db.insert(configTable).values({ empresaId, ...DEFAULT_CONFIG, ...updates }).returning();
    }
    res.json(toClient(row));
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

function toClient(row: typeof configTable.$inferSelect) {
  return {
    nomeClinica: row.nomeClinica, nif: row.nif, endereco: row.endereco,
    telefone: row.telefone, email: row.email, directorTecnico: row.directorTecnico,
    logoData: row.logoData, assinaturaData: row.assinaturaData, serie: row.serie,
    proximoNumeroFatura: row.proximoNumeroFatura, ivaTaxa: row.ivaTaxa,
    moeda: row.moeda, website: row.website,
  };
}

export default router;

import { Router } from "express";
import { db } from "@workspace/db";
import { movimentosTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireEmpresa } from "../middlewares/auth";

const router = Router();
router.use(requireAuth, requireEmpresa);

function getEmpresaId(req: any): number { return req.auth.empresaId as number; }

router.get("/movimentos", async (req, res) => {
  try {
    const rows = await db.select().from(movimentosTable).where(eq(movimentosTable.empresaId, getEmpresaId(req))).orderBy(movimentosTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/movimentos", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const [row] = await db.insert(movimentosTable).values({
      empresaId: getEmpresaId(req),
      data: body.data || "", descricao: body.descricao || "",
      tipo: body.tipo || "entrada", valor: Number(body.valor) || 0,
      categoria: body.categoria || "", referencia: body.referencia || "",
      faturaId: body.faturaId ? Number(body.faturaId) : null,
      registadoPor: body.registadoPor || req.auth?.funcionarioNome || "",
    }).returning();
    res.status(201).json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/movimentos/:id", async (req, res) => {
  try {
    await db.delete(movimentosTable).where(and(
      eq(movimentosTable.id, Number(req.params.id)),
      eq(movimentosTable.empresaId, getEmpresaId(req)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

export default router;

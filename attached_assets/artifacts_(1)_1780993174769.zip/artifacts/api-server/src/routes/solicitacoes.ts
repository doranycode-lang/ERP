import { Router } from "express";
import { db } from "@workspace/db";
import { solicitacoesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();
router.use(requireAuth);

router.get("/solicitacoes", async (req, res) => {
  if (!req.auth?.empresaId) return void res.status(403).json({ error: "Acesso negado." });
  try {
    const rows = await db.select().from(solicitacoesTable)
      .where(eq(solicitacoesTable.empresaId, req.auth.empresaId))
      .orderBy(solicitacoesTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.get("/solicitacoes/minhas", async (req, res) => {
  if (!req.auth?.parceiroId) return void res.status(403).json({ error: "Acesso restrito a parceiros." });
  try {
    const rows = await db.select().from(solicitacoesTable)
      .where(eq(solicitacoesTable.parceiroId, req.auth.parceiroId))
      .orderBy(solicitacoesTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/solicitacoes", async (req, res) => {
  if (!req.auth?.parceiroId || !req.auth?.empresaId) return void res.status(403).json({ error: "Acesso restrito a parceiros." });
  try {
    const body = req.body as Record<string, any>;
    const [row] = await db.insert(solicitacoesTable).values({
      empresaId: req.auth.empresaId,
      parceiroId: req.auth.parceiroId,
      parceiroNome: req.auth.parceiroNome || "",
      pacienteNome: body.pacienteNome || "",
      exameSolicitado: body.exameSolicitado || "",
      observacoes: body.observacoes || "",
    }).returning();
    res.status(201).json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/solicitacoes/:id", async (req, res) => {
  if (!req.auth?.empresaId) return void res.status(403).json({ error: "Acesso negado." });
  try {
    const body = req.body as Record<string, any>;
    const updates: Partial<typeof solicitacoesTable.$inferInsert> = {};
    if (body.estado !== undefined) updates.estado = body.estado;
    if (body.resultadoId !== undefined) updates.resultadoId = body.resultadoId ? Number(body.resultadoId) : null;
    const [row] = await db.update(solicitacoesTable).set(updates)
      .where(and(eq(solicitacoesTable.id, Number(req.params.id)), eq(solicitacoesTable.empresaId, req.auth.empresaId))).returning();
    if (!row) return void res.status(404).json({ error: "Solicitação não encontrada." });
    res.json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

export default router;

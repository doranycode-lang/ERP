import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import empresasRouter from "./empresas";
import pacientesRouter from "./pacientes";
import resultadosRouter from "./resultados";
import faturasRouter from "./faturas";
import movimentosRouter from "./movimentos";
import produtosRouter from "./produtos";
import examesCustomRouter from "./exames-custom";
import configRouter from "./config";
import solicitacoesRouter from "./solicitacoes";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(empresasRouter);
router.use(pacientesRouter);
router.use(resultadosRouter);
router.use(faturasRouter);
router.use(movimentosRouter);
router.use(produtosRouter);
router.use(examesCustomRouter);
router.use(configRouter);
router.use(solicitacoesRouter);

export default router;

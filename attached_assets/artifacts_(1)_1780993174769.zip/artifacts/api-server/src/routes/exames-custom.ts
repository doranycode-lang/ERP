import { Router } from "express";
import { db } from "@workspace/db";
import { examesCustomTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireEmpresa } from "../middlewares/auth";

const router = Router();
router.use(requireAuth, requireEmpresa);

function getEmpresaId(req: any): number { return req.auth.empresaId as number; }

router.get("/exames-custom", async (req, res) => {
  try {
    const rows = await db.select().from(examesCustomTable).where(eq(examesCustomTable.empresaId, getEmpresaId(req))).orderBy(examesCustomTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/exames-custom", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const [row] = await db.insert(examesCustomTable).values({
      empresaId: getEmpresaId(req),
      categoria: body.categoria || "", nome: body.nome || "",
      parametros: Array.isArray(body.parametros) ? body.parametros : [],
    }).returning();
    res.status(201).json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/exames-custom/:id", async (req, res) => {
  try {
    const body = req.body as Record<string, any>;
    const updates: Partial<typeof examesCustomTable.$inferInsert> = {};
    if (body.categoria !== undefined) updates.categoria = body.categoria;
    if (body.nome !== undefined) updates.nome = body.nome;
    if (body.parametros !== undefined) updates.parametros = Array.isArray(body.parametros) ? body.parametros : [];
    const [row] = await db.update(examesCustomTable).set(updates)
      .where(and(eq(examesCustomTable.id, Number(req.params.id)), eq(examesCustomTable.empresaId, getEmpresaId(req)))).returning();
    if (!row) return void res.status(404).json({ error: "Exame não encontrado." });
    res.json(row);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/exames-custom/:id", async (req, res) => {
  try {
    await db.delete(examesCustomTable).where(and(
      eq(examesCustomTable.id, Number(req.params.id)),
      eq(examesCustomTable.empresaId, getEmpresaId(req)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

export default router;

import { Router } from "express";
import { db } from "@workspace/db";
import { empresasTable, funcionariosTable, parceirosTable, configTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireDeveloper } from "../middlewares/auth";
import { hashPassword, generateTempPassword } from "../lib/password";

const router = Router();

router.use(requireAuth);

// ── Empresas (developer only) ──────────────────────────────────────────────

router.get("/empresas", requireDeveloper, async (req, res) => {
  try {
    const rows = await db.select().from(empresasTable).orderBy(empresasTable.id);
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/empresas", requireDeveloper, async (req, res) => {
  try {
    const { nome, nif = "" } = req.body as { nome: string; nif?: string };
    if (!nome) return void res.status(400).json({ error: "Nome é obrigatório." });
    const [emp] = await db.insert(empresasTable).values({ nome, nif }).returning();
    await db.insert(configTable).values({ empresaId: emp.id });
    res.status(201).json(emp);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.put("/empresas/:id", requireDeveloper, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { nome, nif, ativo } = req.body as { nome?: string; nif?: string; ativo?: boolean };
    const updates: Partial<typeof empresasTable.$inferInsert> = {};
    if (nome !== undefined) updates.nome = nome;
    if (nif !== undefined) updates.nif = nif;
    if (ativo !== undefined) updates.ativo = ativo;
    const [emp] = await db.update(empresasTable).set(updates).where(eq(empresasTable.id, id)).returning();
    if (!emp) return void res.status(404).json({ error: "Empresa não encontrada." });
    res.json(emp);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/empresas/:id", requireDeveloper, async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(empresasTable).where(eq(empresasTable.id, id));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

// ── Funcionários ───────────────────────────────────────────────────────────

router.get("/empresas/:id/funcionarios", requireDeveloper, async (req, res) => {
  try {
    const rows = await db.select({
      id: funcionariosTable.id, empresaId: funcionariosTable.empresaId,
      nome: funcionariosTable.nome, username: funcionariosTable.username,
      funcao: funcionariosTable.funcao, telefone: funcionariosTable.telefone,
      email: funcionariosTable.email, ativo: funcionariosTable.ativo,
      createdAt: funcionariosTable.createdAt,
    }).from(funcionariosTable).where(eq(funcionariosTable.empresaId, Number(req.params.id)));
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/empresas/:id/funcionarios", requireDeveloper, async (req, res) => {
  try {
    const empresaId = Number(req.params.id);
    const { nome, username, funcao = "rececionista", telefone = "", email = "" } = req.body as {
      nome: string; username: string; funcao?: string; telefone?: string; email?: string;
    };
    if (!nome || !username) return void res.status(400).json({ error: "Nome e utilizador são obrigatórios." });
    const tempPassword = generateTempPassword();
    const [func] = await db.insert(funcionariosTable).values({
      empresaId, nome, username, passwordHash: hashPassword(tempPassword), funcao, telefone, email,
    }).returning();
    res.status(201).json({
      id: func.id, empresaId: func.empresaId, nome: func.nome, username: func.username,
      funcao: func.funcao, telefone: func.telefone, email: func.email, ativo: func.ativo,
      tempPassword,
    });
  } catch (err: any) {
    if (err?.code === "23505") return void res.status(409).json({ error: "Nome de utilizador já existe." });
    req.log.error({ err }); res.status(500).json({ error: "Erro interno." });
  }
});

router.put("/empresas/:id/funcionarios/:fid", requireDeveloper, async (req, res) => {
  try {
    const empresaId = Number(req.params.id);
    const fid = Number(req.params.fid);
    const { nome, funcao, telefone, email, ativo, newPassword } = req.body as {
      nome?: string; funcao?: string; telefone?: string; email?: string;
      ativo?: boolean; newPassword?: string;
    };
    const updates: Partial<typeof funcionariosTable.$inferInsert> = {};
    if (nome !== undefined) updates.nome = nome;
    if (funcao !== undefined) updates.funcao = funcao;
    if (telefone !== undefined) updates.telefone = telefone;
    if (email !== undefined) updates.email = email;
    if (ativo !== undefined) updates.ativo = ativo;
    let tempPassword: string | undefined;
    if (newPassword) { updates.passwordHash = hashPassword(newPassword); }
    else if (req.body.resetPassword) {
      tempPassword = generateTempPassword();
      updates.passwordHash = hashPassword(tempPassword);
    }
    const [func] = await db.update(funcionariosTable).set(updates)
      .where(and(eq(funcionariosTable.id, fid), eq(funcionariosTable.empresaId, empresaId))).returning();
    if (!func) return void res.status(404).json({ error: "Funcionário não encontrado." });
    res.json({
      id: func.id, empresaId: func.empresaId, nome: func.nome, username: func.username,
      funcao: func.funcao, telefone: func.telefone, email: func.email, ativo: func.ativo,
      ...(tempPassword ? { tempPassword } : {}),
    });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/empresas/:id/funcionarios/:fid", requireDeveloper, async (req, res) => {
  try {
    await db.delete(funcionariosTable).where(and(
      eq(funcionariosTable.id, Number(req.params.fid)),
      eq(funcionariosTable.empresaId, Number(req.params.id)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

// ── Parceiros ──────────────────────────────────────────────────────────────

function canAccessEmpresa(auth: { role: string; empresaId?: number }, empresaId: number): boolean {
  if (auth.role === "developer") return true;
  return auth.empresaId === empresaId;
}

router.get("/empresas/:id/parceiros", async (req, res) => {
  if (!req.auth) return void res.status(401).json({ error: "Não autenticado." });
  if (!canAccessEmpresa(req.auth, Number(req.params.id))) return void res.status(403).json({ error: "Acesso negado." });
  try {
    const rows = await db.select({
      id: parceirosTable.id, empresaId: parceirosTable.empresaId,
      nome: parceirosTable.nome, instituicao: parceirosTable.instituicao,
      username: parceirosTable.username, telefone: parceirosTable.telefone,
      email: parceirosTable.email, ativo: parceirosTable.ativo,
      createdAt: parceirosTable.createdAt,
    }).from(parceirosTable).where(eq(parceirosTable.empresaId, Number(req.params.id)));
    res.json(rows);
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.post("/empresas/:id/parceiros", async (req, res) => {
  if (!req.auth) return void res.status(401).json({ error: "Não autenticado." });
  if (!canAccessEmpresa(req.auth, Number(req.params.id))) return void res.status(403).json({ error: "Acesso negado." });
  try {
    const empresaId = Number(req.params.id);
    const { nome, instituicao = "", username, telefone = "", email = "", ativo = true } = req.body as {
      nome: string; instituicao?: string; username: string;
      telefone?: string; email?: string; ativo?: boolean;
    };
    if (!nome || !username) return void res.status(400).json({ error: "Nome e utilizador são obrigatórios." });
    const tempPassword = generateTempPassword();
    const [par] = await db.insert(parceirosTable).values({
      empresaId, nome, instituicao, username, passwordHash: hashPassword(tempPassword),
      telefone, email, ativo,
    }).returning();
    res.status(201).json({
      id: par.id, empresaId: par.empresaId, nome: par.nome, instituicao: par.instituicao,
      username: par.username, telefone: par.telefone, email: par.email, ativo: par.ativo,
      tempPassword,
    });
  } catch (err: any) {
    if (err?.code === "23505") return void res.status(409).json({ error: "Nome de utilizador já existe." });
    req.log.error({ err }); res.status(500).json({ error: "Erro interno." });
  }
});

router.put("/empresas/:id/parceiros/:pid", async (req, res) => {
  if (!req.auth) return void res.status(401).json({ error: "Não autenticado." });
  if (!canAccessEmpresa(req.auth, Number(req.params.id))) return void res.status(403).json({ error: "Acesso negado." });
  try {
    const empresaId = Number(req.params.id);
    const pid = Number(req.params.pid);
    const { nome, instituicao, telefone, email, ativo } = req.body as {
      nome?: string; instituicao?: string; telefone?: string; email?: string; ativo?: boolean;
    };
    const updates: Partial<typeof parceirosTable.$inferInsert> = {};
    if (nome !== undefined) updates.nome = nome;
    if (instituicao !== undefined) updates.instituicao = instituicao;
    if (telefone !== undefined) updates.telefone = telefone;
    if (email !== undefined) updates.email = email;
    if (ativo !== undefined) updates.ativo = ativo;
    let tempPassword: string | undefined;
    if (req.body.resetPassword) {
      tempPassword = generateTempPassword();
      updates.passwordHash = hashPassword(tempPassword);
    }
    const [par] = await db.update(parceirosTable).set(updates)
      .where(and(eq(parceirosTable.id, pid), eq(parceirosTable.empresaId, empresaId))).returning();
    if (!par) return void res.status(404).json({ error: "Parceiro não encontrado." });
    res.json({
      id: par.id, empresaId: par.empresaId, nome: par.nome, instituicao: par.instituicao,
      username: par.username, telefone: par.telefone, email: par.email, ativo: par.ativo,
      ...(tempPassword ? { tempPassword } : {}),
    });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

router.delete("/empresas/:id/parceiros/:pid", async (req, res) => {
  if (!req.auth) return void res.status(401).json({ error: "Não autenticado." });
  if (!canAccessEmpresa(req.auth, Number(req.params.id))) return void res.status(403).json({ error: "Acesso negado." });
  try {
    await db.delete(parceirosTable).where(and(
      eq(parceirosTable.id, Number(req.params.pid)),
      eq(parceirosTable.empresaId, Number(req.params.id)),
    ));
    res.json({ ok: true });
  } catch (err) { req.log.error({ err }); res.status(500).json({ error: "Erro interno." }); }
});

export default router;

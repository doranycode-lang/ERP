import { db } from "@workspace/db";
import { devUsersTable, funcionariosTable, empresasTable, configTable } from "@workspace/db";
import { hashPassword } from "./password";
import { logger } from "./logger";

export async function seedIfEmpty() {
  try {
    const devs = await db.select().from(devUsersTable).limit(1);
    if (devs.length > 0) return;

    logger.info("First run — seeding initial data...");

    const devPassword = "dev123";
    await db.insert(devUsersTable).values({
      username: "dev",
      passwordHash: hashPassword(devPassword),
    });

    const [emp] = await db.insert(empresasTable).values({
      nome: "Laboratório de Análises Clínicas",
      nif: "000000000",
    }).returning();

    await db.insert(configTable).values({ empresaId: emp.id });

    const adminPassword = "admin123";
    await db.insert(funcionariosTable).values({
      empresaId: emp.id,
      nome: "Administrador",
      username: "admin",
      passwordHash: hashPassword(adminPassword),
      funcao: "admin",
    });

    logger.info(
      { dev: { username: "dev", password: devPassword }, admin: { username: "admin", password: adminPassword }, empresaId: emp.id },
      "✅ Seed complete — use these credentials to log in"
    );
  } catch (err) {
    logger.error({ err }, "Seed failed");
  }
}

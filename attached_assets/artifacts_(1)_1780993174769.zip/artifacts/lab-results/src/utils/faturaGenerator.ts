import { Fatura, Config, formatCurrency } from "../store/storage";

// ── Número por extenso (Angola Portuguese) ─────────────────────────────────
const unidades = ["", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove",
  "Dez", "Onze", "Doze", "Treze", "Catorze", "Quinze", "Dezasseis", "Dezassete", "Dezoito", "Dezanove"];
const dezenas = ["", "", "Vinte", "Trinta", "Quarenta", "Cinquenta", "Sessenta", "Setenta", "Oitenta", "Noventa"];
const centenas = ["", "Cem", "Duzentos", "Trezentos", "Quatrocentos", "Quinhentos",
  "Seiscentos", "Setecentos", "Oitocentos", "Novecentos"];

function menorQueMil(n: number): string {
  if (n === 0) return "";
  if (n < 20) return unidades[n];
  if (n < 100) {
    const d = Math.floor(n / 10);
    const u = n % 10;
    return dezenas[d] + (u ? " e " + unidades[u] : "");
  }
  const c = Math.floor(n / 100);
  const resto = n % 100;
  if (n === 100) return "Cem";
  return centenas[c] + (resto ? " e " + menorQueMil(resto) : "");
}

function valorPorExtenso(valor: number): string {
  if (valor === 0) return "Zero Kwanzas";
  const inteiro = Math.floor(valor);
  const centavos = Math.round((valor - inteiro) * 100);
  let resultado = "";
  const milh = Math.floor(inteiro / 1_000_000);
  const mil = Math.floor((inteiro % 1_000_000) / 1000);
  const cent = inteiro % 1000;
  if (milh) resultado += menorQueMil(milh) + (milh === 1 ? " Milhão" : " Milhões") + " ";
  if (mil) resultado += menorQueMil(mil) + " Mil ";
  if (cent) resultado += menorQueMil(cent) + " ";
  resultado = resultado.trim() + (inteiro === 1 ? " Kwanza" : " Kwanzas");
  if (centavos) resultado += " e " + menorQueMil(centavos) + (centavos === 1 ? " Cêntimo" : " Cêntimos");
  return resultado.trim();
}

function gerarCodigoVerificacao(fatura: Fatura): string {
  const seed = `${fatura.numero}|${fatura.data}|${fatura.total}|${fatura.clienteNif || "CF"}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = ((hash << 5) - hash) + seed.charCodeAt(i);
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).toUpperCase().padStart(8, "0");
  return `${hex.slice(0, 4)}-${hex.slice(4, 8)}-${fatura.serie}`;
}

function getTipoDocumento(estado: Fatura["estado"]): string {
  if (estado === "paga") return "FATURA-RECIBO";
  if (estado === "anulada") return "NOTA DE ANULAÇÃO";
  return "FATURA";
}

export function generateFaturaHTML(fatura: Fatura, config: Config): string {
  const moeda = config.moeda || "AOA";
  const codigoVerif = gerarCodigoVerificacao(fatura);
  const tipoDoc = getTipoDocumento(fatura.estado);
  const clienteNif = fatura.clienteNif?.trim() || "CONSUMIDOR FINAL";

  const logoHTML = config.logoData
    ? `<img src="${config.logoData}" style="max-height:65px;max-width:140px;object-fit:contain;" />`
    : "";

  const agora = new Date();
  const horaEmissao = `${String(agora.getHours()).padStart(2, "0")}:${String(agora.getMinutes()).padStart(2, "0")}:${String(agora.getSeconds()).padStart(2, "0")}`;

  // Lines
  const linhasHTML = fatura.linhas.map((l, i) => {
    const subtotal = l.quantidade * l.precoUnitario;
    const ivaTaxa = l.ivaIsento ? 0 : fatura.ivaTaxa;
    const ivaValor = subtotal * (ivaTaxa / 100);
    const bg = i % 2 === 0 ? "#fff" : "#f7f7f7";
    return `
    <tr style="background:${bg};">
      <td style="padding:5px 8px;font-size:10.5px;border-bottom:0.5px solid #ddd;">${l.descricao}</td>
      <td style="padding:5px 8px;font-size:10.5px;text-align:center;border-bottom:0.5px solid #ddd;">${l.quantidade}</td>
      <td style="padding:5px 8px;font-size:10.5px;text-align:right;border-bottom:0.5px solid #ddd;white-space:nowrap;">${formatCurrency(l.precoUnitario, moeda)}</td>
      <td style="padding:5px 8px;font-size:10.5px;text-align:right;border-bottom:0.5px solid #ddd;white-space:nowrap;">${formatCurrency(subtotal, moeda)}</td>
      <td style="padding:5px 8px;font-size:10.5px;text-align:center;border-bottom:0.5px solid #ddd;">${l.ivaIsento ? "Isento" : ivaTaxa + "%"}</td>
      <td style="padding:5px 8px;font-size:10.5px;text-align:right;border-bottom:0.5px solid #ddd;font-weight:bold;white-space:nowrap;">${formatCurrency(subtotal + ivaValor, moeda)}</td>
    </tr>`;
  }).join("");

  // IVA breakdown
  const ivaGroups: Record<string, { base: number; iva: number }> = {};
  for (const l of fatura.linhas) {
    const taxa = l.ivaIsento ? 0 : fatura.ivaTaxa;
    const key = taxa === 0 ? "Isento" : `${taxa}%`;
    const sub = l.quantidade * l.precoUnitario;
    if (!ivaGroups[key]) ivaGroups[key] = { base: 0, iva: 0 };
    ivaGroups[key].base += sub;
    ivaGroups[key].iva += sub * (taxa / 100);
  }

  const ivaDetalheHTML = Object.entries(ivaGroups).map(([taxa, vals]) => `
    <tr>
      <td style="padding:3px 8px;font-size:9.5px;color:#555;">Base trib. IVA ${taxa}:</td>
      <td style="padding:3px 8px;font-size:9.5px;text-align:right;">${formatCurrency(vals.base, moeda)}</td>
    </tr>
    <tr>
      <td style="padding:3px 8px;font-size:9.5px;color:#555;">IVA ${taxa}:</td>
      <td style="padding:3px 8px;font-size:9.5px;text-align:right;">${formatCurrency(vals.iva, moeda)}</td>
    </tr>`).join("");

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>${tipoDoc} ${fatura.numero}</title>
  <style>
    @page { size: A4; margin: 1.4cm 1.6cm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #111; background: white; }
    @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
  </style>
</head>
<body>
<div style="width:100%;">

  <!-- ═══ CABEÇALHO ═══════════════════════════════════════════════════════ -->
  <table style="width:100%;margin-bottom:12px;border-bottom:2px solid #111;padding-bottom:10px;">
    <tr>
      <td style="vertical-align:middle;width:55%;">
        <div style="display:flex;align-items:center;gap:12px;">
          ${logoHTML}
          <div>
            <div style="font-size:16px;font-weight:bold;">${config.nomeClinica}</div>
            <div style="font-size:9px;color:#555;margin-top:2px;">
              NIF: <strong>${config.nif || "—"}</strong>
              ${config.endereco ? `&nbsp;|&nbsp; ${config.endereco}` : ""}
            </div>
            <div style="font-size:9px;color:#555;">
              ${config.telefone ? "Tel: " + config.telefone : ""}
              ${config.email ? `&nbsp;|&nbsp; ${config.email}` : ""}
            </div>
          </div>
        </div>
      </td>
      <td style="text-align:right;vertical-align:top;">
        <div style="font-size:28px;font-weight:900;letter-spacing:2px;line-height:1;">${tipoDoc}</div>
        <div style="font-size:15px;font-weight:bold;margin-top:4px;letter-spacing:1px;">${fatura.numero}</div>
        <div style="margin-top:6px;font-size:9px;color:#555;line-height:1.7;">
          Emissão: <strong>${fatura.data}</strong> às ${horaEmissao}<br/>
          Vencimento: <strong>${fatura.dataVencimento}</strong><br/>
          Série: <strong>${fatura.serie}</strong>
        </div>
      </td>
    </tr>
  </table>

  <!-- ═══ PARTES ══════════════════════════════════════════════════════════ -->
  <table style="width:100%;margin-bottom:14px;border-collapse:collapse;">
    <tr>
      <td style="width:49%;vertical-align:top;padding-right:8px;">
        <div style="border:1px solid #ccc;padding:9px 12px;">
          <div style="font-size:8px;font-weight:bold;text-transform:uppercase;letter-spacing:1px;color:#555;border-bottom:0.5px solid #ddd;padding-bottom:3px;margin-bottom:5px;">FORNECEDOR / EMITENTE</div>
          <div style="font-size:11px;font-weight:bold;">${config.nomeClinica}</div>
          <div style="font-size:9.5px;color:#444;margin-top:2px;">NIF: <strong>${config.nif || "—"}</strong></div>
          <div style="font-size:9.5px;color:#444;">${config.endereco}</div>
          <div style="font-size:9.5px;color:#444;">${config.telefone}${config.email ? " | " + config.email : ""}</div>
        </div>
      </td>
      <td style="width:2%;"></td>
      <td style="width:49%;vertical-align:top;padding-left:8px;">
        <div style="border:1.5px solid #111;padding:9px 12px;">
          <div style="font-size:8px;font-weight:bold;text-transform:uppercase;letter-spacing:1px;color:#555;border-bottom:0.5px solid #ddd;padding-bottom:3px;margin-bottom:5px;">ADQUIRENTE / CLIENTE</div>
          <div style="font-size:11px;font-weight:bold;">${fatura.clienteNome || "—"}</div>
          <div style="font-size:9.5px;color:#444;margin-top:2px;">NIF: <strong>${clienteNif}</strong></div>
          ${fatura.clienteEndereco ? `<div style="font-size:9.5px;color:#444;">${fatura.clienteEndereco}</div>` : ""}
        </div>
      </td>
    </tr>
  </table>

  <!-- ═══ TABELA DE SERVIÇOS ══════════════════════════════════════════════ -->
  <table style="width:100%;border-collapse:collapse;margin-bottom:14px;">
    <thead>
      <tr style="border-top:1.5px solid #111;border-bottom:1px solid #111;background:#f0f0f0;">
        <th style="padding:6px 8px;text-align:left;font-size:9.5px;">Descrição do Serviço / Bem</th>
        <th style="padding:6px 8px;text-align:center;font-size:9.5px;width:45px;">Qtd.</th>
        <th style="padding:6px 8px;text-align:right;font-size:9.5px;width:100px;">Preço Unit.</th>
        <th style="padding:6px 8px;text-align:right;font-size:9.5px;width:100px;">Valor s/IVA</th>
        <th style="padding:6px 8px;text-align:center;font-size:9.5px;width:60px;">Taxa IVA</th>
        <th style="padding:6px 8px;text-align:right;font-size:9.5px;width:105px;">Valor c/IVA</th>
      </tr>
    </thead>
    <tbody>
      ${linhasHTML}
    </tbody>
  </table>

  <!-- ═══ TOTAIS + DETALHE IVA ════════════════════════════════════════════ -->
  <table style="width:100%;margin-bottom:14px;">
    <tr>
      <td style="width:52%;vertical-align:top;padding-right:14px;">
        ${fatura.observacoes ? `
        <div style="border:1px solid #ccc;padding:7px 10px;margin-bottom:8px;">
          <div style="font-size:8px;font-weight:bold;text-transform:uppercase;color:#555;margin-bottom:3px;">Observações</div>
          <div style="font-size:9.5px;">${fatura.observacoes}</div>
        </div>` : ""}
        <div style="border:1px solid #ccc;">
          <div style="background:#f0f0f0;padding:5px 8px;font-size:8px;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;color:#333;border-bottom:0.5px solid #ccc;">Detalhe de IVA (conforme PVD/AGT)</div>
          <table style="width:100%;">
            ${ivaDetalheHTML}
          </table>
        </div>
      </td>
      <td style="width:48%;vertical-align:top;">
        <table style="width:100%;border-collapse:collapse;border:1px solid #ccc;">
          <tr>
            <td style="padding:6px 10px;font-size:10px;color:#555;border-bottom:0.5px solid #ddd;">Subtotal sem IVA:</td>
            <td style="padding:6px 10px;font-size:10px;text-align:right;border-bottom:0.5px solid #ddd;">${formatCurrency(fatura.subtotalSemIva, moeda)}</td>
          </tr>
          <tr>
            <td style="padding:6px 10px;font-size:10px;color:#555;border-bottom:1px solid #333;">IVA (${fatura.ivaTaxa}%):</td>
            <td style="padding:6px 10px;font-size:10px;text-align:right;border-bottom:1px solid #333;">${formatCurrency(fatura.totalIva, moeda)}</td>
          </tr>
          <tr>
            <td style="padding:9px 10px;font-size:13px;font-weight:bold;">TOTAL A PAGAR:</td>
            <td style="padding:9px 10px;font-size:13px;font-weight:bold;text-align:right;">${formatCurrency(fatura.total, moeda)}</td>
          </tr>
          <tr>
            <td colspan="2" style="padding:5px 10px;font-size:8.5px;font-style:italic;color:#555;border-top:0.5px solid #ddd;">
              Por extenso: <strong>${valorPorExtenso(fatura.total)}</strong>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>

  <!-- ═══ CÓDIGO DE VERIFICAÇÃO AGT ═══════════════════════════════════════ -->
  <div style="border:1px solid #999;padding:8px 14px;margin-bottom:12px;display:flex;align-items:center;gap:20px;">
    <div style="flex:1;">
      <div style="font-size:8px;font-weight:bold;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:3px;">Código de Verificação (AGT/PVD)</div>
      <div style="font-family:monospace;font-size:14px;font-weight:bold;letter-spacing:4px;">${codigoVerif}</div>
    </div>
    <div style="text-align:right;flex-shrink:0;">
      <div style="font-size:8.5px;color:#555;">Verifique em:</div>
      <div style="font-size:8.5px;font-weight:bold;">portalfiscal.agt.gov.ao</div>
    </div>
  </div>

  ${fatura.emitidoPor ? `<div style="font-size:8px;color:#888;text-align:right;margin-bottom:6px;">Emitido por: ${fatura.emitidoPor}</div>` : ""}

  <!-- ═══ RODAPÉ AGT OBRIGATÓRIO ═══════════════════════════════════════════ -->
  <div style="border-top:1.5px solid #111;padding-top:8px;">
    <div style="text-align:center;font-size:9px;font-weight:bold;margin-bottom:3px;">${config.nomeClinica}${config.nif ? " — NIF: " + config.nif : ""}</div>
    <div style="text-align:center;font-size:8px;color:#444;">${[config.endereco, config.telefone ? "Tel: " + config.telefone : "", config.email].filter(Boolean).join("  |  ")}</div>
    <div style="text-align:center;font-size:8px;color:#666;margin-top:5px;">
      <strong>Processado por computador</strong> — Nos termos da Lei n.º 2/22, de 27 de Fevereiro (Lei do IVA) e do Decreto Presidencial n.º 292/18 (PVD/AGT).
    </div>
    <div style="text-align:center;font-size:7.5px;color:#888;margin-top:2px;">
      Autoridade Geral Tributária — República de Angola &nbsp;|&nbsp; Este documento é válido como fatura fiscal.
    </div>
  </div>

</div>
</body>
</html>`;
}

export function downloadFatura(html: string, numero: string): void {
  const win = window.open("", "_blank");
  if (!win) {
    alert("Por favor, permita popups para imprimir.");
    return;
  }
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => { win.print(); }, 600);
}

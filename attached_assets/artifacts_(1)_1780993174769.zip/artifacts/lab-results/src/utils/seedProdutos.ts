import { EXAMES_BUILTIN } from "../data/exames";
import { Produto } from "../store/storage";

export interface ProdutoSeed extends Omit<Produto, "id"> {}

export function gerarProdutosDosCatalogo(): ProdutoSeed[] {
  const produtos: ProdutoSeed[] = [];
  let counter = 1;

  for (const [categoria, subExames] of Object.entries(EXAMES_BUILTIN)) {
    for (const nomeExame of Object.keys(subExames)) {
      produtos.push({
        codigo: "EX-" + String(counter).padStart(3, "0"),
        nome: nomeExame,
        categoria,
        preco: 0,
        ivaIsento: false,
        descricao: "",
        ativo: true,
      });
      counter++;
    }
  }

  const extras: ProdutoSeed[] = [
    { codigo: "SV-001", nome: "Consulta Médica",          categoria: "Serviços Gerais", preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-002", nome: "Taxa de Urgência",          categoria: "Serviços Gerais", preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-003", nome: "Taxa de Colheita",          categoria: "Serviços Gerais", preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-004", nome: "Taxa de Colheita ao Domicílio", categoria: "Serviços Gerais", preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-005", nome: "Ecografia Abdominal",       categoria: "Imagiologia",     preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-006", nome: "Ecografia Obstétrica",      categoria: "Imagiologia",     preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-007", nome: "Ecografia Pélvica",         categoria: "Imagiologia",     preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-008", nome: "Radiografia",               categoria: "Imagiologia",     preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-009", nome: "Electrocardiograma (ECG)",  categoria: "Imagiologia",     preco: 0, ivaIsento: false, descricao: "", ativo: true },
    { codigo: "SV-010", nome: "Material de Consumo",       categoria: "Serviços Gerais", preco: 0, ivaIsento: false, descricao: "", ativo: true },
  ];

  return [...produtos, ...extras];
}

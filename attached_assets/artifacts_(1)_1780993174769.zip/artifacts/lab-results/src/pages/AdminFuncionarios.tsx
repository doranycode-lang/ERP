import { useState, useEffect, useCallback } from "react";
import { api } from "../store/api";
import { Session, FuncaoFuncionario, FUNCAO_LABELS } from "../store/auth";

const FUNCOES: FuncaoFuncionario[] = ["gestor", "tecnico", "rececionista", "financeiro", "medico"];

const FUNCAO_DESC: Record<FuncaoFuncionario, string> = {
  admin: "Acesso total ao sistema",
  gestor: "Clínica + relatórios (sem financeiro e configurações)",
  tecnico: "Lançar resultados e histórico",
  rececionista: "Pacientes, histórico e faturação",
  financeiro: "Faturação e conta corrente",
  medico: "Todas as funções clínicas",
};

const emptyForm = { nome: "", username: "", password: "", funcao: "tecnico" as FuncaoFuncionario, ativo: true };

export default function AdminFuncionarios({ session }: { session: Session }) {
  const empresaId = session.empresaId!;
  const [funcionarios, setFuncionarios] = useState<any[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState<string | null>(null);
  const [showPass, setShowPass] = useState(false);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const [search, setSearch] = useState("");

  const load = useCallback(async () => {
    try {
      const list = await api.empresas.listFuncionarios(empresaId);
      setFuncionarios(list);
    } catch { /* ignore */ }
  }, [empresaId]);

  useEffect(() => { load(); }, [load]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.nome.trim() || !form.username.trim() || !form.password.trim()) {
      setMsg({ text: "Preencha todos os campos obrigatórios.", ok: false }); return;
    }
    try {
      if (editId) {
        await api.empresas.updateFuncionario(empresaId, editId, form);
        setMsg({ text: "Funcionário actualizado.", ok: true });
      } else {
        await api.empresas.createFuncionario(empresaId, form);
        setMsg({ text: `Funcionário "${form.nome}" criado com sucesso.`, ok: true });
      }
      setForm(emptyForm); setEditId(null);
      await load();
    } catch (err: any) {
      setMsg({ text: err.message || "Erro ao guardar funcionário.", ok: false });
    }
  }

  async function handleToggle(f: any) {
    await api.empresas.updateFuncionario(empresaId, f.id, { ...f, ativo: !f.ativo });
    await load();
  }

  async function handleDelete(id: string) {
    if (!window.confirm("Eliminar este funcionário?")) return;
    await api.empresas.deleteFuncionario(empresaId, id);
    await load();
  }

  const filtered = funcionarios.filter((f) =>
    !search || f.nome.toLowerCase().includes(search.toLowerCase()) ||
    f.username.toLowerCase().includes(search.toLowerCase())
  );

  const funcaoCor: Record<string, string> = {
    admin: "bg-purple-100 text-purple-700", gestor: "bg-blue-100 text-blue-700",
    tecnico: "bg-cyan-100 text-cyan-700", rececionista: "bg-amber-100 text-amber-700",
    financeiro: "bg-green-100 text-green-700", medico: "bg-rose-100 text-rose-700",
  };

  return (
    <div className="p-5 space-y-5">
      <h2 className="text-xl font-bold text-primary">Gestão de Funcionários</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="bg-white border border-border rounded-xl p-5">
          <h3 className="text-sm font-bold text-primary uppercase tracking-wide mb-4">
            {editId ? "Editar Funcionário" : "Novo Funcionário"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Nome Completo *</label>
              <input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })}
                className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" placeholder="Nome do funcionário" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Utilizador (login) *</label>
              <input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })}
                className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" placeholder="Ex: tecnico01" autoComplete="off" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Palavra-passe *</label>
              <div className="relative">
                <input type={showPass ? "text" : "password"} value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className="w-full border border-border rounded-lg px-3 py-2 pr-9 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="Palavra-passe" autoComplete="new-password" />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground">{showPass ? "🙈" : "👁"}</button>
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Função / Perfil *</label>
              <select value={form.funcao} onChange={(e) => setForm({ ...form, funcao: e.target.value as FuncaoFuncionario })}
                className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 bg-white">
                {FUNCOES.map((f) => <option key={f} value={f}>{FUNCAO_LABELS[f]}</option>)}
              </select>
              <p className="text-xs text-muted-foreground mt-1">{FUNCAO_DESC[form.funcao]}</p>
            </div>
            {editId && (
              <label className="flex items-center gap-2 cursor-pointer text-sm">
                <input type="checkbox" checked={form.ativo} onChange={(e) => setForm({ ...form, ativo: e.target.checked })} style={{ accentColor: "hsl(var(--primary))" }} />
                Conta activa
              </label>
            )}
            {msg && (
              <div className={`text-xs rounded-lg px-3 py-2 ${msg.ok ? "bg-green-50 border border-green-200 text-green-700" : "bg-red-50 border border-red-200 text-red-700"}`}>{msg.text}</div>
            )}
            <div className="flex gap-2 pt-1">
              <button type="submit" className="flex-1 bg-primary text-primary-foreground py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition">
                {editId ? "Guardar" : "Criar Funcionário"}
              </button>
              {editId && (
                <button type="button" onClick={() => { setForm(emptyForm); setEditId(null); setMsg(null); }}
                  className="flex-1 bg-muted text-muted-foreground py-2 rounded-lg text-sm font-semibold hover:opacity-80 transition">Cancelar</button>
              )}
            </div>
          </form>
          <div className="mt-5 pt-4 border-t border-border">
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-3">Permissões por Função</div>
            <div className="space-y-1.5">
              {FUNCOES.map((f) => (
                <div key={f} className="flex items-start gap-2">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold flex-shrink-0 mt-0.5 ${funcaoCor[f]}`}>{FUNCAO_LABELS[f].split(" ")[0]}</span>
                  <span className="text-xs text-muted-foreground">{FUNCAO_DESC[f]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="lg:col-span-2 bg-white border border-border rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-border flex items-center gap-3">
            <h3 className="text-sm font-bold">Funcionários ({filtered.length})</h3>
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar..."
              className="ml-auto border border-border rounded-lg px-3 py-1.5 text-xs w-44 focus:outline-none focus:ring-2 focus:ring-primary/30" />
          </div>
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground text-sm">
              {funcionarios.length === 0 ? "Nenhum funcionário criado. Use o formulário ao lado." : "Nenhum resultado encontrado."}
            </div>
          ) : (
            <div className="divide-y divide-border">
              {filtered.map((f) => (
                <div key={f.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-accent/20 transition-colors">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                    style={{ background: f.ativo ? "hsl(var(--primary))" : "#9ca3af" }}>
                    {f.nome.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm">{f.nome}</div>
                    <div className="text-xs text-muted-foreground">@{f.username}</div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${funcaoCor[f.funcao] || "bg-gray-100 text-gray-700"}`}>
                      {FUNCAO_LABELS[f.funcao as FuncaoFuncionario] || f.funcao}
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${f.ativo ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                      {f.ativo ? "Activo" : "Inactivo"}
                    </span>
                  </div>
                  <div className="flex gap-2 text-xs flex-shrink-0">
                    <button onClick={() => { setForm({ nome: f.nome, username: f.username, password: f.password, funcao: f.funcao, ativo: f.ativo }); setEditId(f.id); setMsg(null); }}
                      className="text-primary hover:underline font-semibold">Editar</button>
                    <span className="text-border">|</span>
                    <button onClick={() => handleToggle(f)} className="text-amber-600 hover:underline font-semibold">{f.ativo ? "Desactivar" : "Activar"}</button>
                    <span className="text-border">|</span>
                    <button onClick={() => handleDelete(f.id)} className="text-destructive hover:underline font-semibold">Eliminar</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

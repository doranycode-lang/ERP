import { useState } from "react";
import { useApp } from "../store/AppContext";
import { Produto } from "../store/AppContext";
import { formatCurrency } from "../store/storage";
import { gerarProdutosDosCatalogo } from "../utils/seedProdutos";

const CATEGORIAS = [
  "Hematologia", "Bioquímica", "Imunologia / Serologia", "Hormonas / Endocrinologia",
  "Função Tiroideia", "iChroma I — Tiróide", "iChroma II — Cardíaco/Anemia", "iChroma III — Hormonal",
  "Análise de Urina", "Microbiologia / Bacteriologia", "Parasitologia / Coprologia",
  "Marcadores Tumorais", "Marcadores Cardíacos", "Coagulação", "Genética / Biologia Molecular",
  "Toxicologia / Drogas", "Consulta Médica", "Ecografia", "Radiografia", "Electrocardiograma",
  "Taxa de Urgência", "Taxa de Colheita", "Material de Consumo", "Serviço Hospitalar", "Outro",
];

function nextCodigo(produtos: Produto[]): string {
  const nums = produtos
    .map((p) => parseInt(p.codigo.replace(/\D/g, "") || "0"))
    .filter((n) => !isNaN(n));
  const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
  return "LAB-" + String(next).padStart(3, "0");
}

const emptyForm: Omit<Produto, "id"> = {
  codigo: "", nome: "", categoria: "Bioquímica", preco: 0, ivaIsento: false, descricao: "", ativo: true,
};

export default function GestaProdutos() {
  const { data, addProduto, updateProduto, removeProduto } = useApp();
  const moeda = data.config.moeda || "AOA";
  const produtos = data.produtos ?? [];

  const [form, setForm] = useState<Omit<Produto, "id">>(() => ({ ...emptyForm, codigo: nextCodigo(produtos) }));
  const [editId, setEditId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [filtroCat, setFiltroCat] = useState("");
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);

  function handleImportarCatalogo() {
    const seeds = gerarProdutosDosCatalogo();
    const existentes = new Set(produtos.map((p) => p.nome.toLowerCase().trim()));
    const novos = seeds.filter((s) => !existentes.has(s.nome.toLowerCase().trim()));
    if (novos.length === 0) {
      setMsg({ text: "Todos os exames do catálogo já estão importados.", ok: true });
      return;
    }
    if (!window.confirm(`Importar ${novos.length} exame(s) do catálogo como produtos? (preço 0 — pode editar depois)`)) return;
    novos.forEach((p) => addProduto(p));
    setMsg({ text: `${novos.length} produto(s) importado(s) com sucesso. Defina os preços na tabela.`, ok: true });
  }

  function handleSincronizarCatalogo() {
    const seeds = gerarProdutosDosCatalogo();
    const existentes = new Set(produtos.map((p) => p.nome.toLowerCase().trim()));
    const novos = seeds.filter((s) => !existentes.has(s.nome.toLowerCase().trim()));
    if (novos.length === 0) {
      setMsg({ text: "Catálogo já sincronizado — sem novos exames.", ok: true });
      return;
    }
    novos.forEach((p) => addProduto(p));
    setMsg({ text: `Sincronização concluída: ${novos.length} novo(s) exame(s) adicionado(s).`, ok: true });
  }

  function f<K extends keyof typeof emptyForm>(field: K, val: (typeof emptyForm)[K]) {
    setForm((prev) => ({ ...prev, [field]: val }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.nome.trim()) { setMsg({ text: "O nome é obrigatório.", ok: false }); return; }
    if (!form.codigo.trim()) { setMsg({ text: "O código é obrigatório.", ok: false }); return; }
    const dup = produtos.find((p) => p.codigo === form.codigo.trim() && p.id !== editId);
    if (dup) { setMsg({ text: "Já existe um produto com este código.", ok: false }); return; }
    if (editId !== null) {
      updateProduto(editId, { ...form, nome: form.nome.trim(), codigo: form.codigo.trim() });
      setMsg({ text: "Produto actualizado com sucesso.", ok: true });
      setEditId(null);
    } else {
      addProduto({ ...form, nome: form.nome.trim(), codigo: form.codigo.trim() });
      setMsg({ text: `Produto "${form.nome}" registado.`, ok: true });
    }
    const next = { ...emptyForm, codigo: nextCodigo([...produtos, { id: 0, ...form }]) };
    setForm(next);
  }

  function handleEdit(p: Produto) {
    const { id, ...rest } = p;
    setForm(rest);
    setEditId(id);
    setMsg(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleRemove(p: Produto) {
    if (!window.confirm(`Eliminar "${p.nome}"?`)) return;
    removeProduto(p.id);
  }

  const filtered = produtos.filter((p) => {
    const matchSearch = !search ||
      p.nome.toLowerCase().includes(search.toLowerCase()) ||
      p.codigo.toLowerCase().includes(search.toLowerCase()) ||
      p.categoria.toLowerCase().includes(search.toLowerCase());
    const matchCat = !filtroCat || p.categoria === filtroCat;
    return matchSearch && matchCat;
  });

  const cats = [...new Set(produtos.map((p) => p.categoria))].sort();
  const totalAtivos = produtos.filter((p) => p.ativo).length;
  const totalCategorias = new Set(produtos.map((p) => p.categoria)).size;

  const inp = "w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 bg-white";

  return (
    <div className="p-5 space-y-5">
      <div className="flex items-center gap-3 flex-wrap">
        <h2 className="text-xl font-bold text-primary">Gestão de Produtos e Serviços</h2>
        <span className="text-xs text-muted-foreground bg-secondary px-3 py-1 rounded-full">Tabela de Preços (PVD)</span>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-2.5 text-xs text-blue-700 flex items-center justify-between gap-4 flex-wrap">
        <span>Registe aqui todos os exames e serviços prestados com os respectivos preços. Esta tabela alimenta directamente a faturação e o sistema PVD/AGT.</span>
        <div className="flex gap-2 flex-shrink-0">
          <button
            onClick={handleImportarCatalogo}
            className="bg-blue-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-blue-800 transition whitespace-nowrap"
          >
            ⬇ Importar catálogo de exames
          </button>
          <button
            onClick={handleSincronizarCatalogo}
            className="bg-white border border-blue-400 text-blue-700 text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-blue-50 transition whitespace-nowrap"
          >
            🔄 Sincronizar novos exames
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-primary">{produtos.length}</div>
          <div className="text-xs text-muted-foreground">Produtos Registados</div>
        </div>
        <div className="bg-white border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{totalAtivos}</div>
          <div className="text-xs text-muted-foreground">Activos</div>
        </div>
        <div className="bg-white border border-border rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">{totalCategorias}</div>
          <div className="text-xs text-muted-foreground">Categorias</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Form */}
        <div className="bg-white border border-border rounded-xl p-5">
          <h3 className="text-sm font-bold text-primary uppercase tracking-wide mb-4">
            {editId !== null ? "Editar Produto" : "Novo Produto / Serviço"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-medium text-muted-foreground">Código *</label>
                <input value={form.codigo} onChange={(e) => f("codigo", e.target.value)} className={inp} placeholder="LAB-001" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-medium text-muted-foreground">Categoria *</label>
                <select value={form.categoria} onChange={(e) => f("categoria", e.target.value)} className={inp}>
                  {CATEGORIAS.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Nome do Produto / Serviço *</label>
              <input value={form.nome} onChange={(e) => f("nome", e.target.value)} className={inp} placeholder="Ex: Hemograma Completo" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Descrição (opcional)</label>
              <textarea value={form.descricao} onChange={(e) => f("descricao", e.target.value)}
                className={inp + " resize-none"} rows={2}
                placeholder="Breve descrição do serviço..." />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Preço ({moeda}) *</label>
              <input type="number" value={form.preco} onChange={(e) => f("preco", Number(e.target.value))}
                className={inp} min={0} step={0.01} placeholder="0.00" />
            </div>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer text-sm">
                <input type="checkbox" checked={form.ivaIsento}
                  onChange={(e) => f("ivaIsento", e.target.checked)}
                  style={{ accentColor: "hsl(var(--primary))" }} />
                Isento de IVA
              </label>
              {editId !== null && (
                <label className="flex items-center gap-2 cursor-pointer text-sm">
                  <input type="checkbox" checked={form.ativo}
                    onChange={(e) => f("ativo", e.target.checked)}
                    style={{ accentColor: "hsl(var(--primary))" }} />
                  Produto activo
                </label>
              )}
            </div>
            {!form.ivaIsento && (
              <div className="text-xs text-muted-foreground bg-secondary/50 rounded px-3 py-2">
                Preço c/ IVA ({data.config.ivaTaxa}%): <strong>
                  {formatCurrency(form.preco * (1 + (data.config.ivaTaxa || 14) / 100), moeda)}
                </strong>
              </div>
            )}
            {msg && (
              <div className={`text-xs rounded-lg px-3 py-2 ${msg.ok ? "bg-green-50 border border-green-200 text-green-700" : "bg-red-50 border border-red-200 text-red-700"}`}>
                {msg.text}
              </div>
            )}
            <div className="flex gap-2 pt-1">
              <button type="submit"
                className="flex-1 bg-primary text-primary-foreground py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition">
                {editId !== null ? "Guardar" : "Registar Produto"}
              </button>
              {editId !== null && (
                <button type="button"
                  onClick={() => { setForm({ ...emptyForm, codigo: nextCodigo(produtos) }); setEditId(null); setMsg(null); }}
                  className="flex-1 bg-muted text-muted-foreground py-2 rounded-lg text-sm font-semibold hover:opacity-80 transition">
                  Cancelar
                </button>
              )}
            </div>
          </form>
        </div>

        {/* List */}
        <div className="lg:col-span-2 bg-white border border-border rounded-xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-border flex items-center gap-3 flex-wrap">
            <h3 className="text-sm font-bold">Catálogo ({filtered.length})</h3>
            <select value={filtroCat} onChange={(e) => setFiltroCat(e.target.value)}
              className="border border-border rounded px-2 py-1 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-primary/30 max-w-40">
              <option value="">Todas as categorias</option>
              {cats.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Pesquisar..."
              className="ml-auto border border-border rounded px-3 py-1.5 text-xs w-44 focus:outline-none focus:ring-2 focus:ring-primary/30" />
          </div>

          {filtered.length === 0 ? (
            <div className="py-14 text-center text-muted-foreground text-sm">
              {produtos.length === 0
                ? "Nenhum produto registado. Use o formulário ao lado para começar."
                : "Nenhum produto encontrado com os filtros actuais."}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary">
                  <tr>
                    <th className="text-left px-4 py-2.5 font-semibold text-xs">Código</th>
                    <th className="text-left px-4 py-2.5 font-semibold text-xs">Nome / Serviço</th>
                    <th className="text-left px-4 py-2.5 font-semibold text-xs">Categoria</th>
                    <th className="text-right px-4 py-2.5 font-semibold text-xs">Preço s/IVA</th>
                    <th className="text-right px-4 py-2.5 font-semibold text-xs">Preço c/IVA</th>
                    <th className="text-center px-4 py-2.5 font-semibold text-xs">IVA</th>
                    <th className="text-center px-4 py-2.5 font-semibold text-xs">Estado</th>
                    <th className="text-center px-4 py-2.5 font-semibold text-xs">Acções</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((p) => {
                    const precoComIva = p.ivaIsento ? p.preco : p.preco * (1 + (data.config.ivaTaxa || 14) / 100);
                    return (
                      <tr key={p.id} className={`border-t border-border hover:bg-accent/20 transition-colors ${!p.ativo ? "opacity-50" : ""}`}>
                        <td className="px-4 py-2.5 font-mono text-xs text-muted-foreground">{p.codigo}</td>
                        <td className="px-4 py-2.5">
                          <div className="font-medium text-xs">{p.nome}</div>
                          {p.descricao && <div className="text-xs text-muted-foreground mt-0.5 truncate max-w-48">{p.descricao}</div>}
                        </td>
                        <td className="px-4 py-2.5 text-xs text-muted-foreground">{p.categoria}</td>
                        <td className="px-4 py-2.5 text-xs text-right font-medium">{formatCurrency(p.preco, moeda)}</td>
                        <td className="px-4 py-2.5 text-xs text-right font-bold text-primary">{formatCurrency(precoComIva, moeda)}</td>
                        <td className="px-4 py-2.5 text-center">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${p.ivaIsento ? "bg-gray-100 text-gray-600" : "bg-amber-100 text-amber-700"}`}>
                            {p.ivaIsento ? "Isento" : (data.config.ivaTaxa || 14) + "%"}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${p.ativo ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                            {p.ativo ? "Activo" : "Inactivo"}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <div className="flex items-center justify-center gap-2 text-xs">
                            <button onClick={() => handleEdit(p)} className="text-primary hover:underline font-semibold">Editar</button>
                            <span className="text-border">|</span>
                            <button onClick={() => updateProduto(p.id, { ...p, ativo: !p.ativo })}
                              className="text-amber-600 hover:underline font-semibold">
                              {p.ativo ? "Desact." : "Activar"}
                            </button>
                            <span className="text-border">|</span>
                            <button onClick={() => handleRemove(p)} className="text-destructive hover:underline font-semibold">Eliminar</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from "react";
import { useApp } from "../store/AppContext";
import { api } from "../store/api";
import { Session } from "../store/auth";

function ImageUploadBox({
  label, hint, preview, onSelect, onRemove, icon,
}: {
  label: string; hint: string; preview: string;
  onSelect: (dataUrl: string) => void; onRemove: () => void; icon: string;
}) {
  const fileRef = useRef<HTMLInputElement>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => onSelect(ev.target?.result as string);
    reader.readAsDataURL(file);
  }

  return (
    <div className="flex items-center gap-5">
      <div
        className="w-32 h-20 border-2 border-dashed border-border rounded-lg flex items-center justify-center overflow-hidden cursor-pointer hover:border-primary transition-colors bg-gray-50"
        onClick={() => fileRef.current?.click()}
      >
        {preview ? (
          <img src={preview} alt={label} className="max-h-full max-w-full object-contain p-1" />
        ) : (
          <div className="text-center text-muted-foreground text-xs">
            <div className="text-2xl mb-1">{icon}</div>
            <div>Clique para carregar</div>
          </div>
        )}
      </div>
      <div className="space-y-2">
        <button type="button" onClick={() => fileRef.current?.click()}
          className="block bg-secondary text-secondary-foreground px-4 py-2 rounded text-sm font-medium hover:opacity-90 transition">
          Seleccionar {label}
        </button>
        {preview && (
          <button type="button" onClick={onRemove}
            className="block text-destructive text-sm hover:underline font-medium">
            Remover
          </button>
        )}
        <p className="text-xs text-muted-foreground">{hint}</p>
      </div>
      <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
    </div>
  );
}

interface Parceiro {
  id: string;
  nome: string;
  instituicao: string;
  username: string;
  telefone?: string;
  email?: string;
  ativo?: boolean;
}

const emptyParceiro: Omit<Parceiro, "id"> = {
  nome: "", instituicao: "", username: "", telefone: "", email: "", ativo: true,
};

export default function Configuracoes({ session }: { session?: Session }) {
  const { data, updateConfig } = useApp();
  const [form, setForm] = useState({ ...data.config });
  const [saved, setSaved] = useState(false);

  const [parceiros, setParceiros] = useState<Parceiro[]>([]);
  const [parceiroLoading, setParceiroLoading] = useState(false);
  const [showParceiroModal, setShowParceiroModal] = useState(false);
  const [parceiroForm, setParceiroForm] = useState({ ...emptyParceiro });
  const [parceiroEditId, setParceiroEditId] = useState<string | null>(null);
  const [parceiroSaving, setParceiroSaving] = useState(false);
  const [parceiroError, setParceiroError] = useState("");
  const [tempPasswordInfo, setTempPasswordInfo] = useState<{ username: string; password: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const empresaId = session?.empresaId;

  useEffect(() => {
    if (!empresaId) return;
    setParceiroLoading(true);
    api.empresas.listParceiros(empresaId)
      .then(setParceiros)
      .catch(() => setParceiros([]))
      .finally(() => setParceiroLoading(false));
  }, [empresaId]);

  async function handleParceiroSave() {
    if (!parceiroForm.nome.trim() || !parceiroForm.username.trim()) {
      setParceiroError("Nome e nome de utilizador são obrigatórios.");
      return;
    }
    if (!empresaId) return;
    setParceiroSaving(true);
    setParceiroError("");
    try {
      if (parceiroEditId) {
        await api.empresas.updateParceiro(empresaId, parceiroEditId, parceiroForm);
      } else {
        const result = await api.empresas.createParceiro(empresaId, parceiroForm);
        if (result?.tempPassword) {
          setTempPasswordInfo({ username: result.username, password: result.tempPassword });
          setCopied(false);
        }
      }
      const fresh = await api.empresas.listParceiros(empresaId);
      setParceiros(fresh);
      setShowParceiroModal(false);
      setParceiroForm({ ...emptyParceiro });
      setParceiroEditId(null);
    } catch (e: any) {
      setParceiroError(e.message || "Erro ao guardar parceiro.");
    } finally {
      setParceiroSaving(false);
    }
  }

  async function handleParceiroDelete(pid: string) {
    if (!empresaId) return;
    if (!window.confirm("Remover este parceiro? Esta acção não pode ser desfeita.")) return;
    try {
      await api.empresas.deleteParceiro(empresaId, pid);
      setParceiros(prev => prev.filter(p => p.id !== pid));
    } catch (e: any) {
      alert(e.message || "Erro ao remover.");
    }
  }

  function handleParceiroEdit(p: Parceiro) {
    const { id, ...rest } = p;
    setParceiroForm({ ...emptyParceiro, ...rest });
    setParceiroEditId(id);
    setParceiroError("");
    setShowParceiroModal(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    updateConfig(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  function field(label: string, key: keyof typeof form, placeholder?: string, type: string = "text") {
    return (
      <div className="space-y-1">
        <label className="text-xs font-medium text-muted-foreground">{label}</label>
        <input
          type={type}
          value={String(form[key] ?? "")}
          onChange={(e) => setForm({ ...form, [key]: type === "number" ? Number(e.target.value) : e.target.value })}
          className="w-full border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
          placeholder={placeholder}
        />
      </div>
    );
  }

  return (
    <div className="p-5 space-y-5 max-w-3xl">
      <h2 className="text-xl font-bold text-primary">Configurações da Empresa</h2>

      <form onSubmit={handleSubmit} className="space-y-6">

        {/* Images */}
        <div className="bg-white border border-border rounded-xl p-6 space-y-5">
          <h3 className="text-sm font-bold text-primary uppercase tracking-wide border-b border-border pb-2">Imagens</h3>
          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground mb-1">Logo da Empresa</div>
            <ImageUploadBox
              label="Logo" hint="PNG, JPG — aparece no cabeçalho do PDF e na aplicação"
              preview={form.logoData} icon="🏥"
              onSelect={(url) => setForm((prev) => ({ ...prev, logoData: url }))}
              onRemove={() => setForm((prev) => ({ ...prev, logoData: "" }))}
            />
          </div>
          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground mb-1">Assinatura do Director(a) Técnico(a)</div>
            <ImageUploadBox
              label="Assinatura" hint="PNG com fundo transparente — aparece no rodapé dos PDFs"
              preview={form.assinaturaData} icon="✍️"
              onSelect={(url) => setForm((prev) => ({ ...prev, assinaturaData: url }))}
              onRemove={() => setForm((prev) => ({ ...prev, assinaturaData: "" }))}
            />
          </div>
        </div>

        {/* Identity */}
        <div className="bg-white border border-border rounded-xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-primary uppercase tracking-wide border-b border-border pb-2">Dados da Empresa</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {field("Nome da Empresa / Laboratório *", "nomeClinica", "Nome que aparece nos documentos")}
            {field("NIF (Número de Identificação Fiscal)", "nif", "Ex: 5000000001LD")}
            {field("Endereço", "endereco", "Morada completa")}
            {field("Telefone", "telefone", "Ex: 923 000 000")}
            {field("E-mail", "email", "email@laboratorio.ao")}
            {field("Website", "website", "www.laboratorio.ao")}
            {field("Nome do Director(a) Técnico(a)", "directorTecnico", "Nome que assina os PDFs")}
          </div>
        </div>

        {/* Billing */}
        <div className="bg-white border border-border rounded-xl p-6 space-y-4">
          <h3 className="text-sm font-bold text-primary uppercase tracking-wide border-b border-border pb-2">Configurações de Faturação (AGT)</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {field("Série de Faturas", "serie", "Ex: A")}
            {field("Taxa IVA (%)", "ivaTaxa", "14", "number")}
            {field("Moeda", "moeda", "AOA")}
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-lg px-4 py-3 text-xs text-amber-800">
            <strong>Atenção:</strong> A série de faturas e o número sequencial não devem ser alterados após a emissão de faturas, de acordo com a legislação da AGT Angola. O próximo número de fatura é <strong>{form.proximoNumeroFatura}</strong>.
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button type="submit"
            className="bg-primary text-primary-foreground px-8 py-2.5 rounded-lg text-sm font-semibold hover:opacity-90 transition">
            Guardar Configurações
          </button>
          {saved && (
            <span className="text-green-600 text-sm font-semibold">✓ Guardado com sucesso</span>
          )}
        </div>
      </form>

      {/* Parceiros */}
      {empresaId && (
        <div className="bg-white border border-border rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-border pb-2">
            <h3 className="text-sm font-bold text-primary uppercase tracking-wide">Parceiros (Instituições Referenciadas)</h3>
            <button
              onClick={() => { setParceiroForm({ ...emptyParceiro }); setParceiroEditId(null); setParceiroError(""); setShowParceiroModal(true); }}
              className="bg-primary text-primary-foreground px-4 py-1.5 rounded-lg text-xs font-semibold hover:opacity-90 transition flex items-center gap-1.5"
            >
              <span>＋</span> Novo Parceiro
            </button>
          </div>

          {parceiroLoading ? (
            <div className="text-sm text-muted-foreground py-4 text-center">A carregar parceiros...</div>
          ) : parceiros.length === 0 ? (
            <div className="text-sm text-muted-foreground py-4 text-center">Nenhum parceiro registado. Clique em "Novo Parceiro" para adicionar.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 pr-3 text-xs font-semibold text-muted-foreground">Nome</th>
                    <th className="text-left py-2 pr-3 text-xs font-semibold text-muted-foreground">Instituição</th>
                    <th className="text-left py-2 pr-3 text-xs font-semibold text-muted-foreground">Utilizador</th>
                    <th className="text-left py-2 pr-3 text-xs font-semibold text-muted-foreground">Telefone</th>
                    <th className="text-left py-2 pr-3 text-xs font-semibold text-muted-foreground">Estado</th>
                    <th className="py-2 text-xs font-semibold text-muted-foreground text-right">Acções</th>
                  </tr>
                </thead>
                <tbody>
                  {parceiros.map((p) => (
                    <tr key={p.id} className="border-b border-border/50 hover:bg-secondary/30 transition">
                      <td className="py-2 pr-3 font-medium">{p.nome}</td>
                      <td className="py-2 pr-3 text-muted-foreground">{p.instituicao}</td>
                      <td className="py-2 pr-3 text-muted-foreground font-mono text-xs">{p.username}</td>
                      <td className="py-2 pr-3 text-muted-foreground">{p.telefone || "—"}</td>
                      <td className="py-2 pr-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${p.ativo !== false ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                          {p.ativo !== false ? "Activo" : "Inactivo"}
                        </span>
                      </td>
                      <td className="py-2 text-right">
                        <div className="flex gap-1.5 justify-end">
                          <button onClick={() => handleParceiroEdit(p)}
                            className="text-xs text-primary hover:underline font-medium px-2 py-1 rounded hover:bg-primary/10 transition">
                            Editar
                          </button>
                          <button onClick={() => handleParceiroDelete(p.id)}
                            className="text-xs text-destructive hover:underline font-medium px-2 py-1 rounded hover:bg-red-50 transition">
                            Remover
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Parceiro Modal */}
      {showParceiroModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-primary">{parceiroEditId ? "Editar Parceiro" : "Novo Parceiro"}</h3>
              <button onClick={() => setShowParceiroModal(false)}
                className="text-muted-foreground hover:text-foreground text-lg leading-none">✕</button>
            </div>
            <div className="space-y-3">
              {[
                { label: "Nome do Médico / Responsável *", key: "nome" as const, placeholder: "Dr. Nome Apelido" },
                { label: "Instituição *", key: "instituicao" as const, placeholder: "Ex: Clínica Cardio" },
                { label: "Nome de Utilizador *", key: "username" as const, placeholder: "nome.apelido" },
                { label: "Telefone", key: "telefone" as const, placeholder: "9XX XXX XXX" },
                { label: "E-mail", key: "email" as const, placeholder: "medico@clinica.ao" },
              ].map(({ label, key, placeholder }) => (
                <div key={key} className="space-y-1">
                  <label className="text-xs font-medium text-muted-foreground">{label}</label>
                  <input
                    value={parceiroForm[key] as string || ""}
                    onChange={(e) => setParceiroForm((prev) => ({ ...prev, [key]: e.target.value }))}
                    className="w-full border border-border rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                    placeholder={placeholder}
                  />
                </div>
              ))}
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="parceiroAtivo"
                  checked={parceiroForm.ativo !== false}
                  onChange={(e) => setParceiroForm((prev) => ({ ...prev, ativo: e.target.checked }))}
                  className="rounded"
                />
                <label htmlFor="parceiroAtivo" className="text-sm text-muted-foreground">Parceiro activo</label>
              </div>
              {parceiroError && (
                <div className="text-destructive text-xs bg-red-50 border border-red-200 rounded px-3 py-2">{parceiroError}</div>
              )}
            </div>
            <div className="flex gap-3 pt-2">
              <button onClick={handleParceiroSave} disabled={parceiroSaving}
                className="flex-1 bg-primary text-primary-foreground py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition disabled:opacity-60">
                {parceiroSaving ? "A guardar..." : (parceiroEditId ? "Actualizar" : "Criar Parceiro")}
              </button>
              <button onClick={() => setShowParceiroModal(false)}
                className="flex-1 border border-border py-2 rounded-lg text-sm font-medium hover:bg-secondary transition">
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Temp Password Reveal Modal */}
      {tempPasswordInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-xl">🔑</div>
              <div>
                <h3 className="text-base font-bold text-foreground">Parceiro criado com sucesso</h3>
                <p className="text-xs text-muted-foreground">Copie e partilhe esta senha — <strong>não será mostrada novamente.</strong></p>
              </div>
            </div>
            <div className="bg-gray-50 border border-border rounded-lg p-4 space-y-3">
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground font-medium">Nome de utilizador</div>
                <div className="font-mono text-sm font-semibold text-foreground">{tempPasswordInfo.username}</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground font-medium">Senha temporária</div>
                <div className="flex items-center gap-2">
                  <div className="font-mono text-lg font-bold text-primary tracking-widest flex-1 select-all">{tempPasswordInfo.password}</div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(tempPasswordInfo.password);
                      setCopied(true);
                    }}
                    className="text-xs px-3 py-1.5 rounded-md border border-border bg-white hover:bg-secondary transition font-medium"
                  >
                    {copied ? "✓ Copiado" : "Copiar"}
                  </button>
                </div>
              </div>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg px-4 py-3 text-xs text-amber-800">
              O parceiro deverá alterar esta senha no primeiro acesso em <strong>Configurações → Alterar Senha</strong>.
            </div>
            <button
              onClick={() => setTempPasswordInfo(null)}
              className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold hover:opacity-90 transition"
            >
              Entendido, fechar
            </button>
          </div>
        </div>
      )}

      {/* Preview */}
      <div className="bg-white border border-border rounded-xl p-5">
        <h3 className="text-sm font-bold text-primary mb-3 uppercase tracking-wide">Pré-visualização do Cabeçalho PDF</h3>
        <div className="border border-border rounded-lg p-4 bg-gray-50">
          <div className="flex items-center gap-4 mb-2">
            {form.logoData ? (
              <img src={form.logoData} alt="Logo" className="max-h-14 max-w-28 object-contain" />
            ) : (
              <div className="w-14 h-14 bg-green-100 rounded flex items-center justify-center text-xs text-green-700 font-bold">LOGO</div>
            )}
            <div>
              <div className="font-bold text-base text-green-800">{form.nomeClinica}</div>
              {form.nif && <div className="text-xs text-gray-500">NIF: {form.nif}</div>}
              <div className="text-xs text-gray-500">{form.telefone} | {form.email}</div>
              <div className="text-xs text-gray-500">{form.endereco}</div>
            </div>
          </div>
          <div className="border-t border-green-300 pt-2 text-center text-sm font-bold tracking-widest text-green-800">
            RELATÓRIO DE RESULTADOS DE ANÁLISES CLÍNICAS
          </div>
        </div>
      </div>
    </div>
  );
}

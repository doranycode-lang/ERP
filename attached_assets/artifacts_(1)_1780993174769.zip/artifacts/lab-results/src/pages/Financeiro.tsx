import { useState } from "react";
import { Session } from "../store/auth";
import Faturacao from "./Faturacao";
import ContaCorrente from "./ContaCorrente";
import GestaProdutos from "./GestaProdutos";

type FinTab = "faturas" | "conta" | "produtos";

const TABS: { id: FinTab; label: string }[] = [
  { id: "faturas",  label: "Faturação" },
  { id: "conta",    label: "Conta Corrente" },
  { id: "produtos", label: "Produtos / Serviços" },
];

export default function Financeiro({ session }: { session: Session }) {
  const [tab, setTab] = useState<FinTab>("faturas");

  return (
    <div className="flex flex-col h-full">
      <div className="border-b border-border bg-white px-6 flex-shrink-0">
        <div className="flex">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-5 py-3 text-sm font-medium border-b-2 transition-colors ${
                tab === t.id
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-auto">
        {tab === "faturas"  && <Faturacao session={session} />}
        {tab === "conta"    && <ContaCorrente session={session} />}
        {tab === "produtos" && <GestaProdutos />}
      </div>
    </div>
  );
}

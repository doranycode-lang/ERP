import { useState, useEffect, useCallback } from "react";
import { Session } from "../store/auth";
import { api } from "../store/api";

interface Props {
  session: Session;
  onLogout: () => void;
}

type Solicitacao = {
  id: number;
  pacienteNome: string;
  pacienteNascimento: string;
  pacienteSexo: string;
  pacienteTelefone: string;
  pacienteBi: string;
  examesSolicitados: string[];
  observacoes: string;
  urgente: boolean;
  estado: string;
  data: string;
  hora: string;
};

const ESTADOS = {
  pendente:    { label: "Pendente",    cls: "bg-amber-50 text-amber-700 border border-amber-200" },
  em_processo: { label: "Em Processo", cls: "bg-blue-50 text-blue-700 border border-blue-200" },
  concluido:   { label: "Concluído",   cls: "bg-emerald-50 text-emerald-700 border border-emerald-200" },
  cancelado:   { label: "Cancelado",   cls: "bg-red-50 text-red-600 border border-red-200" },
};

function todayStr() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}
function nowTime() {
  return new Date().toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
}

const emptyForm = {
  pacienteNome: "", pacienteNascimento: "", pacienteSexo: "", pacienteTelefone: "", pacienteBi: "",
  observacoes: "", urgente: false,
};

export default function PortalParceiro({ session, onLogout }: Props) {
  const [tab, setTab] = useState<"nova" | "minhas">("nova");
  const [solicitacoes, setSolicitacoes] = useState<Solicitacao[]>([]);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [exames, setExames] = useState<string[]>([]);
  const [exameInput, setExameInput] = useState("");
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const [printTarget, setPrintTarget] = useState<Solicitacao | null>(null);

  const loadSolicitacoes = useCallback(async () => {
    setLoading(true);
    try {
      const list = await api.solicitacoes.listMinhas();
      setSolicitacoes(list);
    } catch { /* ignore */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadSolicitacoes(); }, [loadSolicitacoes]);

  function addExame() {
    const e = exameInput.trim();
    if (!e || exames.includes(e)) return;
    setExames([...exames, e]);
    setExameInput("");
  }

  function removeExame(nome: string) {
    setExames(exames.filter((e) => e !== nome));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.pacienteNome.trim()) { setMsg({ text: "Nome do paciente é obrigatório.", ok: false }); return; }
    if (exames.length === 0) { setMsg({ text: "Adicione pelo menos um exame.", ok: false }); return; }
    setMsg(null);
    try {
      await api.solicitacoes.create({
        ...form,
        examesSolicitados: exames,
        data: todayStr(),
        hora: nowTime(),
      });
      setMsg({ text: "Solicitação enviada com sucesso! O laboratório irá processar o pedido.", ok: true });
      setForm(emptyForm);
      setExames([]);
      await loadSolicitacoes();
      setTab("minhas");
    } catch (err: any) {
      setMsg({ text: err.message || "Erro ao enviar solicitação.", ok: false });
    }
  }

  function handlePrint(sol: Solicitacao) {
    setPrintTarget(sol);
    setTimeout(() => { window.print(); setPrintTarget(null); }, 200);
  }

  const estadoBadge = (estado: string) => {
    const cfg = ESTADOS[estado as keyof typeof ESTADOS] ?? { label: estado, cls: "bg-gray-100 text-gray-600" };
    return <span className={`badge ${cfg.cls} text-xs`}>{cfg.label}</span>;
  };

  return (
    <>
      {/* Print overlay */}
      {printTarget && (
        <div className="pdf-preview fixed inset-0 bg-white z-50 p-10">
          <PrintPedido sol={printTarget} session={session} />
        </div>
      )}

      <div className="min-h-screen" style={{ background: "hsl(258 40% 8%)" }}>
        {/* Header */}
        <header className="border-b border-white/10 px-6 py-4 flex items-center gap-4">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "hsl(258 70% 55%)" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/>
              <path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/>
            </svg>
          </div>
          <div>
            <div className="text-white font-bold text-sm">{session.parceiroNome || session.username}</div>
            <div className="text-xs" style={{ color: "hsl(258 20% 60%)" }}>
              {session.parceiroInstituicao || "Parceiro"} · {session.empresaNome}
            </div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <div className="text-white/40 text-xs hidden sm:block">{todayStr()}</div>
            <button onClick={onLogout}
              className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg transition"
              style={{ background: "hsl(258 20% 18%)", color: "hsl(258 20% 65%)" }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              Sair
            </button>
          </div>
        </header>

        <div className="max-w-4xl mx-auto p-6">
          {/* Tabs */}
          <div className="flex gap-1 p-1 rounded-xl mb-6" style={{ background: "hsl(258 20% 14%)" }}>
            {([
              { id: "nova", label: "Nova Solicitação", icon: <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg> },
              { id: "minhas", label: `Meus Pedidos (${solicitacoes.length})`, icon: <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> },
            ] as const).map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all ${tab === t.id ? "text-white" : "text-white/40 hover:text-white/60"}`}
                style={tab === t.id ? { background: "hsl(258 70% 55%)" } : {}}>
                {t.icon}{t.label}
              </button>
            ))}
          </div>

          {/* Nova Solicitação */}
          {tab === "nova" && (
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Patient card */}
              <div className="rounded-xl overflow-hidden border border-white/10" style={{ background: "hsl(258 20% 14%)" }}>
                <div className="px-5 py-3 border-b border-white/10 flex items-center gap-2">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="hsl(258 70% 70%)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
                  </svg>
                  <span className="text-sm font-bold" style={{ color: "hsl(258 70% 75%)" }}>Dados do Paciente</span>
                </div>
                <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-white/50 mb-1.5 uppercase tracking-wide">Nome Completo *</label>
                    <input value={form.pacienteNome} onChange={e => setForm({ ...form, pacienteNome: e.target.value })}
                      className="w-full rounded-lg px-3 py-2 text-sm text-white border border-white/10 focus:outline-none focus:border-purple-400/50 focus:ring-1 focus:ring-purple-400/20"
                      style={{ background: "hsl(258 20% 10%)" }} placeholder="Nome completo do paciente" required />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-white/50 mb-1.5 uppercase tracking-wide">Data de Nascimento</label>
                    <input value={form.pacienteNascimento} onChange={e => setForm({ ...form, pacienteNascimento: e.target.value })}
                      className="w-full rounded-lg px-3 py-2 text-sm text-white border border-white/10 focus:outline-none focus:border-purple-400/50"
                      style={{ background: "hsl(258 20% 10%)" }} placeholder="DD/MM/AAAA" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-white/50 mb-1.5 uppercase tracking-wide">Sexo</label>
                    <select value={form.pacienteSexo} onChange={e => setForm({ ...form, pacienteSexo: e.target.value })}
                      className="w-full rounded-lg px-3 py-2 text-sm text-white border border-white/10 focus:outline-none focus:border-purple-400/50"
                      style={{ background: "hsl(258 20% 10%)" }}>
                      <option value="">Seleccionar...</option>
                      <option value="M">Masculino</option>
                      <option value="F">Feminino</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-white/50 mb-1.5 uppercase tracking-wide">Telefone</label>
                    <input value={form.pacienteTelefone} onChange={e => setForm({ ...form, pacienteTelefone: e.target.value })}
                      className="w-full rounded-lg px-3 py-2 text-sm text-white border border-white/10 focus:outline-none focus:border-purple-400/50"
                      style={{ background: "hsl(258 20% 10%)" }} placeholder="9XX XXX XXX" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-white/50 mb-1.5 uppercase tracking-wide">BI / Passaporte</label>
                    <input value={form.pacienteBi} onChange={e => setForm({ ...form, pacienteBi: e.target.value })}
                      className="w-full rounded-lg px-3 py-2 text-sm text-white border border-white/10 focus:outline-none focus:border-purple-400/50"
                      style={{ background: "hsl(258 20% 10%)" }} placeholder="Nº do documento" />
                  </div>
                </div>
              </div>

              {/* Exames card */}
              <div className="rounded-xl overflow-hidden border border-white/10" style={{ background: "hsl(258 20% 14%)" }}>
                <div className="px-5 py-3 border-b border-white/10 flex items-center gap-2">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="hsl(258 70% 70%)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9 3v11a6 6 0 006-6V3"/><line x1="6" y1="3" x2="18" y2="3"/><path d="M5 21h14"/>
                  </svg>
                  <span className="text-sm font-bold" style={{ color: "hsl(258 70% 75%)" }}>Exames Solicitados</span>
                  {exames.length > 0 && (
                    <span className="ml-auto text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: "hsl(258 70% 55% / 0.3)", color: "hsl(258 70% 75%)" }}>
                      {exames.length}
                    </span>
                  )}
                </div>
                <div className="p-5 space-y-3">
                  <div className="flex gap-2">
                    <input
                      value={exameInput}
                      onChange={e => setExameInput(e.target.value)}
                      onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addExame(); } }}
                      className="flex-1 rounded-lg px-3 py-2 text-sm text-white border border-white/10 focus:outline-none focus:border-purple-400/50"
                      style={{ background: "hsl(258 20% 10%)" }}
                      placeholder="Ex: Hemograma completo, Glicemia, TSH..." />
                    <button type="button" onClick={addExame}
                      className="px-4 py-2 rounded-lg text-sm font-semibold text-white transition hover:opacity-90"
                      style={{ background: "hsl(258 70% 55%)" }}>
                      Adicionar
                    </button>
                  </div>
                  {exames.length === 0 ? (
                    <p className="text-white/30 text-xs text-center py-4">Nenhum exame adicionado. Escreva o nome e clique Adicionar.</p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {exames.map((e) => (
                        <div key={e} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium"
                          style={{ background: "hsl(258 70% 55% / 0.2)", color: "hsl(258 70% 80%)" }}>
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M9 3v11a6 6 0 006-6V3"/><line x1="6" y1="3" x2="18" y2="3"/></svg>
                          {e}
                          <button type="button" onClick={() => removeExame(e)} className="ml-1 hover:text-red-400 transition">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Options card */}
              <div className="rounded-xl overflow-hidden border border-white/10" style={{ background: "hsl(258 20% 14%)" }}>
                <div className="p-5 space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-white/50 mb-1.5 uppercase tracking-wide">Observações / Notas Clínicas</label>
                    <textarea value={form.observacoes} onChange={e => setForm({ ...form, observacoes: e.target.value })}
                      rows={3}
                      className="w-full rounded-lg px-3 py-2 text-sm text-white border border-white/10 focus:outline-none focus:border-purple-400/50 resize-none"
                      style={{ background: "hsl(258 20% 10%)" }}
                      placeholder="Informações clínicas relevantes, medicações actuais, alergias..." />
                  </div>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <div onClick={() => setForm({ ...form, urgente: !form.urgente })}
                      className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all flex-shrink-0 ${form.urgente ? "border-red-400 bg-red-500" : "border-white/20"}`}>
                      {form.urgente && <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="2 6 5 9 10 3"/></svg>}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white">Pedido Urgente</div>
                      <div className="text-xs text-white/40">Assinala como urgente para o laboratório priorizar</div>
                    </div>
                  </label>
                </div>
              </div>

              {msg && (
                <div className={`rounded-xl px-5 py-4 flex items-start gap-3 ${msg.ok ? "bg-emerald-900/40 border border-emerald-500/30" : "bg-red-900/40 border border-red-500/30"}`}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={msg.ok ? "#34d399" : "#f87171"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-shrink-0 mt-0.5">
                    {msg.ok ? <><polyline points="20 6 9 17 4 12"/></> : <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>}
                  </svg>
                  <p className={`text-sm font-medium ${msg.ok ? "text-emerald-300" : "text-red-300"}`}>{msg.text}</p>
                </div>
              )}

              <button type="submit"
                className="w-full py-3 rounded-xl text-white font-bold text-sm transition hover:opacity-90 flex items-center justify-center gap-2"
                style={{ background: "hsl(258 70% 55%)" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
                Enviar Solicitação ao Laboratório
              </button>
            </form>
          )}

          {/* Meus Pedidos */}
          {tab === "minhas" && (
            <div className="space-y-3">
              {loading && (
                <div className="text-center py-12 text-white/30 text-sm">A carregar...</div>
              )}
              {!loading && solicitacoes.length === 0 && (
                <div className="rounded-xl border border-white/10 py-16 text-center" style={{ background: "hsl(258 20% 14%)" }}>
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="hsl(258 20% 35%)" strokeWidth="1.5" className="mx-auto mb-3">
                    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/>
                  </svg>
                  <p className="text-white/30 text-sm">Nenhuma solicitação enviada.</p>
                  <button onClick={() => setTab("nova")} className="mt-3 text-sm font-semibold" style={{ color: "hsl(258 70% 70%)" }}>
                    Criar a primeira solicitação →
                  </button>
                </div>
              )}
              {solicitacoes.map((sol) => (
                <div key={sol.id} className="rounded-xl border border-white/10 overflow-hidden" style={{ background: "hsl(258 20% 14%)" }}>
                  <div className="px-5 py-4 flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0"
                      style={{ background: "hsl(258 70% 55% / 0.25)", color: "hsl(258 70% 75%)" }}>
                      {sol.pacienteNome.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-white font-semibold text-sm">{sol.pacienteNome}</span>
                        {sol.urgente && (
                          <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30">URGENTE</span>
                        )}
                        {estadoBadge(sol.estado)}
                      </div>
                      <div className="text-xs text-white/40 mt-0.5">{sol.data} {sol.hora && `· ${sol.hora}`}</div>
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {(sol.examesSolicitados || []).map((e) => (
                          <span key={e} className="text-xs px-2 py-0.5 rounded-md" style={{ background: "hsl(258 20% 20%)", color: "hsl(258 40% 70%)" }}>
                            {e}
                          </span>
                        ))}
                      </div>
                      {sol.observacoes && (
                        <p className="text-xs text-white/30 mt-1.5 italic">"{sol.observacoes}"</p>
                      )}
                    </div>
                    <div className="flex flex-col gap-2 flex-shrink-0">
                      <button onClick={() => handlePrint(sol)}
                        className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg transition hover:opacity-80"
                        style={{ background: "hsl(258 20% 22%)", color: "hsl(258 40% 70%)" }}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                          <rect x="6" y="14" width="12" height="8"/>
                        </svg>
                        Imprimir
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function PrintPedido({ sol, session }: { sol: Solicitacao; session: Session }) {
  const now = new Date();
  return (
    <div style={{ fontFamily: "Arial, sans-serif", fontSize: "12px", color: "#000", maxWidth: "700px", margin: "0 auto" }}>
      <div style={{ textAlign: "center", borderBottom: "2px solid #333", paddingBottom: "16px", marginBottom: "16px" }}>
        <h2 style={{ margin: 0, fontSize: "18px" }}>PEDIDO DE EXAMES</h2>
        <p style={{ margin: "4px 0", color: "#555" }}>{session.empresaNome}</p>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "20px" }}>
        <div>
          <div style={{ fontSize: "10px", color: "#888", marginBottom: "2px" }}>PARCEIRO / MÉDICO</div>
          <div style={{ fontWeight: "bold" }}>{session.parceiroNome}</div>
          {session.parceiroInstituicao && <div style={{ color: "#555" }}>{session.parceiroInstituicao}</div>}
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: "10px", color: "#888", marginBottom: "2px" }}>DATA E HORA</div>
          <div style={{ fontWeight: "bold" }}>{sol.data}</div>
          <div style={{ color: "#555" }}>{sol.hora}</div>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: "6px", padding: "14px", marginBottom: "16px" }}>
        <div style={{ fontSize: "10px", color: "#888", marginBottom: "8px", fontWeight: "bold" }}>DADOS DO PACIENTE</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
          <div><span style={{ color: "#555" }}>Nome:</span> <strong>{sol.pacienteNome}</strong></div>
          {sol.pacienteNascimento && <div><span style={{ color: "#555" }}>Nascimento:</span> {sol.pacienteNascimento}</div>}
          {sol.pacienteSexo && <div><span style={{ color: "#555" }}>Sexo:</span> {sol.pacienteSexo === "M" ? "Masculino" : "Feminino"}</div>}
          {sol.pacienteTelefone && <div><span style={{ color: "#555" }}>Telefone:</span> {sol.pacienteTelefone}</div>}
          {sol.pacienteBi && <div><span style={{ color: "#555" }}>BI/Passaporte:</span> {sol.pacienteBi}</div>}
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: "6px", padding: "14px", marginBottom: "16px" }}>
        <div style={{ fontSize: "10px", color: "#888", marginBottom: "8px", fontWeight: "bold" }}>EXAMES SOLICITADOS</div>
        {sol.urgente && <div style={{ background: "#fee2e2", color: "#b91c1c", padding: "4px 10px", borderRadius: "4px", marginBottom: "8px", fontSize: "11px", fontWeight: "bold" }}>⚠ PEDIDO URGENTE</div>}
        {(sol.examesSolicitados || []).map((e, i) => (
          <div key={i} style={{ padding: "5px 0", borderBottom: "1px solid #f0f0f0", display: "flex", alignItems: "center", gap: "8px" }}>
            <div style={{ width: "16px", height: "16px", border: "1px solid #999", borderRadius: "3px", flexShrink: 0 }} />
            <span>{e}</span>
          </div>
        ))}
      </div>

      {sol.observacoes && (
        <div style={{ border: "1px solid #ddd", borderRadius: "6px", padding: "14px", marginBottom: "16px" }}>
          <div style={{ fontSize: "10px", color: "#888", marginBottom: "6px", fontWeight: "bold" }}>NOTAS CLÍNICAS / OBSERVAÇÕES</div>
          <p style={{ margin: 0, color: "#333" }}>{sol.observacoes}</p>
        </div>
      )}

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: "40px", paddingTop: "16px", borderTop: "1px solid #ddd" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ borderTop: "1px solid #333", width: "200px", marginBottom: "4px" }} />
          <div style={{ fontSize: "11px", color: "#555" }}>Assinatura do Médico / Parceiro</div>
          <div style={{ fontSize: "11px", fontWeight: "bold" }}>{session.parceiroNome}</div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ borderTop: "1px solid #333", width: "200px", marginBottom: "4px" }} />
          <div style={{ fontSize: "11px", color: "#555" }}>Assinatura / Carimbo do Laboratório</div>
        </div>
      </div>

      <p style={{ textAlign: "center", fontSize: "10px", color: "#aaa", marginTop: "30px" }}>
        Nº Ref: {sol.id} · Impresso em {now.toLocaleString("pt-PT")} · {session.empresaNome}
      </p>
    </div>
  );
}

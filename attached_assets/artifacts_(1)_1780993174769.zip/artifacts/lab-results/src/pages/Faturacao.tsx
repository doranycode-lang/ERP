import { useState, useMemo, useRef, useEffect } from "react";
import { useApp } from "../store/AppContext";
import { Session } from "../store/auth";

// ── Helpers ───────────────────────────────────────────────────────────────────
function todayStr() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}
function addDays(dateStr: string, days: number) {
  const p = dateStr.split("/");
  if (p.length !== 3) return dateStr;
  const d = new Date(`${p[2]}-${p[1]}-${p[0]}`);
  d.setDate(d.getDate() + days);
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}
function isVencida(dv: string, estado: string) {
  if (estado !== "emitida") return false;
  const p = dv.split("/");
  if (p.length !== 3) return false;
  return new Date(`${p[2]}-${p[1]}-${p[0]}`) < new Date();
}
function fmtCurrency(v: number) {
  return new Intl.NumberFormat("pt-AO", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v) + " Kz";
}

// ── Types ─────────────────────────────────────────────────────────────────────
type FaturaEstado = "emitida" | "rascunho" | "paga" | "anulada";

interface Linha {
  descricao: string;
  quantidade: number;
  precoUnitario: number;
  ivaIsento: boolean;
}

// ── Estado config ─────────────────────────────────────────────────────────────
const ESTADO_CONFIG: Record<string, { label: string; dot: string; bg: string; color: string; ring: string }> = {
  rascunho: { label: "Rascunho", dot: "#f59e0b", bg: "#fffbeb", color: "#92400e", ring: "#fde68a" },
  emitida:  { label: "Emitida",  dot: "#3b82f6", bg: "#eff6ff", color: "#1e40af", ring: "#bfdbfe" },
  paga:     { label: "Paga",     dot: "#10b981", bg: "#ecfdf5", color: "#065f46", ring: "#a7f3d0" },
  anulada:  { label: "Anulada",  dot: "#ef4444", bg: "#fef2f2", color: "#991b1b", ring: "#fecaca" },
};

const SIDE_PAGE_SIZE = 12;

// ── Badge ─────────────────────────────────────────────────────────────────────
function StatusBadge({ estado }: { estado: string }) {
  const cfg = ESTADO_CONFIG[estado] ?? ESTADO_CONFIG.rascunho;
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium"
      style={{ background: cfg.bg, color: cfg.color }}
    >
      <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: cfg.dot }} />
      {cfg.label}
    </span>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function Faturacao({ session }: { session: Session }) {
  const { data, addFatura, updateFatura, removeFatura } = useApp();
  const faturas = data.faturas ?? [];

  const hoje = todayStr();

  // Form state
  const [view, setView]                 = useState<"lista" | "form">("lista");
  const [editId, setEditId]             = useState<number | null>(null);
  const [clienteNome, setClienteNome]   = useState("");
  const [clienteNif, setClienteNif]     = useState("");
  const [clienteEndereco, setClienteEndereco] = useState("");
  const [pacienteId, setPacienteId]     = useState("");
  const [linhas, setLinhas]             = useState<Linha[]>([]);
  const [observacoes, setObservacoes]   = useState("");
  const [estado, setEstado]             = useState<FaturaEstado>("emitida");
  const [dataEmissao, setDataEmissao]   = useState(hoje);
  const [dataVenc, setDataVenc]         = useState(addDays(hoje, 30));
  const [ivaTaxa, setIvaTaxa]           = useState(14);
  const [desconto, setDesconto]         = useState(0);

  // Product search (form)
  const [produtoSearch, setProdutoSearch] = useState("");
  const [produtoQtd, setProdutoQtd]       = useState(1);
  const [showDropdown, setShowDropdown]   = useState(false);
  const [dropdownIdx, setDropdownIdx]     = useState(-1);
  const searchRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Side panel (product list in form)
  const [sidePanelSearch, setSidePanelSearch] = useState("");
  const [sidePanelPage, setSidePanelPage]     = useState(1);

  // List view
  const [search, setSearch]             = useState("");
  const [filtroEstado, setFiltroEstado] = useState("todos");
  const [showRascunhos, setShowRascunhos] = useState(true);

  // ── Computed ──────────────────────────────────────────────────────────────
  const produtosFiltrados = useMemo(() => {
    const q = produtoSearch.trim().toLowerCase();
    if (!q) return [];
    return data.produtos.filter(
      (p) => p.nome.toLowerCase().includes(q) || (p.codigo ?? "").toLowerCase().includes(q)
    ).slice(0, 8);
  }, [produtoSearch, data.produtos]);

  useEffect(() => {
    setShowDropdown(produtosFiltrados.length > 0 && !!produtoSearch.trim());
    setDropdownIdx(-1);
  }, [produtosFiltrados, produtoSearch]);

  const sideProdutos = useMemo(() => {
    const q = sidePanelSearch.trim().toLowerCase();
    return q
      ? data.produtos.filter((p) => p.nome.toLowerCase().includes(q) || (p.codigo ?? "").toLowerCase().includes(q))
      : data.produtos;
  }, [sidePanelSearch, data.produtos]);

  const sideTotalPages = Math.max(1, Math.ceil(sideProdutos.length / SIDE_PAGE_SIZE));
  const sidePageItems = sideProdutos.slice((sidePanelPage - 1) * SIDE_PAGE_SIZE, sidePanelPage * SIDE_PAGE_SIZE);

  function calcTotals(ls: Linha[], taxa: number, desc: number) {
    let sub = 0, iva = 0;
    for (const l of ls) {
      const s = l.quantidade * l.precoUnitario;
      sub += s;
      if (!l.ivaIsento) iva += s * (taxa / 100);
    }
    const dv = sub * (desc / 100);
    return { subtotal: sub - dv, totalIva: iva, total: sub - dv + iva };
  }
  const totals = useMemo(() => calcTotals(linhas, ivaTaxa, desconto), [linhas, ivaTaxa, desconto]);

  const filtered = useMemo(() => {
    let items = [...faturas];
    if (filtroEstado !== "todos") items = items.filter((f) => f.estado === filtroEstado);
    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(
        (f) => f.clienteNome.toLowerCase().includes(q) || f.numero.toLowerCase().includes(q)
      );
    }
    return items.sort((a, b) => b.id - a.id);
  }, [faturas, filtroEstado, search]);

  const rascunhos = filtered.filter((f) => f.estado === "rascunho");
  const outros    = filtered.filter((f) => f.estado !== "rascunho");

  const totalRecebido = faturas.filter((f) => f.estado === "paga").reduce((s, f) => s + f.total, 0);
  const totalPendente = faturas.filter((f) => f.estado === "emitida").reduce((s, f) => s + f.total, 0);

  // ── Actions ───────────────────────────────────────────────────────────────
  function resetForm() {
    setClienteNome(""); setClienteNif(""); setClienteEndereco(""); setPacienteId("");
    setLinhas([]); setObservacoes(""); setEstado("emitida");
    setDataEmissao(hoje); setDataVenc(addDays(hoje, 30));
    setIvaTaxa(14); setDesconto(0);
    setProdutoSearch(""); setProdutoQtd(1);
    setShowDropdown(false); setEditId(null);
  }

  function handleNovo() { resetForm(); setView("form"); }

  function handleEdit(f: (typeof faturas)[0]) {
    setClienteNome(f.clienteNome); setClienteNif(f.clienteNif ?? "");
    setClienteEndereco(f.clienteEndereco ?? "");
    setPacienteId(f.pacienteId ? String(f.pacienteId) : "");
    setLinhas(f.linhas.length ? [...f.linhas] : []);
    setObservacoes(f.observacoes ?? ""); setEstado((f.estado ?? "emitida") as FaturaEstado);
    setDataEmissao(f.data); setDataVenc(f.dataVencimento ?? addDays(f.data, 30));
    setIvaTaxa(f.ivaTaxa ?? 14); setDesconto(0);
    setEditId(f.id); setView("form");
  }

  async function handleSave() {
    const t = calcTotals(linhas, ivaTaxa, desconto);
    if (editId !== null) {
      await updateFatura(editId, {
        clienteNome: clienteNome || "Consumidor Final", clienteNif, clienteEndereco,
        linhas, subtotalSemIva: t.subtotal, totalIva: t.totalIva, total: t.total,
        estado, data: dataEmissao, dataVencimento: dataVenc, ivaTaxa, observacoes,
        pacienteId: pacienteId ? parseInt(pacienteId) : undefined,
      });
    } else {
      await addFatura({
        clienteNome: clienteNome || "Consumidor Final", clienteNif, clienteEndereco,
        linhas, subtotalSemIva: t.subtotal, totalIva: t.totalIva, total: t.total,
        estado, data: dataEmissao, dataVencimento: dataVenc, ivaTaxa, observacoes,
        pacienteId: pacienteId ? parseInt(pacienteId) : undefined,
        serie: "FT", emitidoPor: session.funcionarioNome || session.username,
      });
    }
    resetForm(); setView("lista");
  }

  function handleAddProduto(p?: typeof data.produtos[0]) {
    if (p) {
      setLinhas((prev) => [...prev, { descricao: p.nome, quantidade: produtoQtd, precoUnitario: p.preco, ivaIsento: !!p.ivaIsento }]);
    } else if (produtoSearch.trim()) {
      setLinhas((prev) => [...prev, { descricao: produtoSearch.trim(), quantidade: produtoQtd, precoUnitario: 0, ivaIsento: false }]);
    }
    setProdutoSearch(""); setProdutoQtd(1); setShowDropdown(false);
    setTimeout(() => searchRef.current?.focus(), 50);
  }

  function handleRemoveLinha(i: number) { setLinhas((p) => p.filter((_, idx) => idx !== i)); }
  function handleUpdateLinha(i: number, k: keyof Linha, v: string | number | boolean) {
    setLinhas((p) => p.map((l, idx) => idx === i ? { ...l, [k]: v } : l));
  }
  function handleSideAdd(p: typeof data.produtos[0]) {
    setLinhas((prev) => [...prev, { descricao: p.nome, quantidade: 1, precoUnitario: p.preco, ivaIsento: !!p.ivaIsento }]);
  }

  function handleSearchKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!showDropdown || !produtosFiltrados.length) {
      if (e.key === "Enter" && produtoSearch.trim()) { e.preventDefault(); handleAddProduto(); }
      return;
    }
    if (e.key === "ArrowDown") { e.preventDefault(); setDropdownIdx((i) => Math.min(i + 1, produtosFiltrados.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setDropdownIdx((i) => Math.max(i - 1, -1)); }
    else if (e.key === "Enter") { e.preventDefault(); handleAddProduto(dropdownIdx >= 0 ? produtosFiltrados[dropdownIdx] : produtosFiltrados[0]); }
    else if (e.key === "Escape") { setShowDropdown(false); }
  }

  async function handleMarcarPaga(f: typeof faturas[0], e: React.MouseEvent) {
    e.stopPropagation();
    await updateFatura(f.id, { estado: "paga" });
  }
  async function handleAnular(f: typeof faturas[0], e: React.MouseEvent) {
    e.stopPropagation();
    if (confirm(`Anular ${f.numero}?`)) await updateFatura(f.id, { estado: "anulada" });
  }
  async function handleDelete(f: typeof faturas[0], e: React.MouseEvent) {
    e.stopPropagation();
    if (confirm(`Eliminar ${f.numero}?`)) await removeFatura(f.id);
  }

  // ════════════════════════════════════════════════════════════════════════════
  // FORM VIEW
  // ════════════════════════════════════════════════════════════════════════════
  if (view === "form") {
    return (
      <div className="flex gap-0 h-full overflow-hidden">
        {/* ── Main form area ── */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-4 max-w-3xl">
            {/* Header */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => { resetForm(); setView("lista"); }}
                className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="15 18 9 12 15 6"/>
                </svg>
              </button>
              <div>
                <h2 className="text-base font-bold text-foreground">
                  {editId !== null ? "Editar Factura" : "Nova Factura"}
                </h2>
                <p className="text-xs text-muted-foreground">Documento de Faturação · FT</p>
              </div>
            </div>

            {/* Client card */}
            <div className="bg-white border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-border bg-muted/30">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Cliente</p>
              </div>
              <div className="p-4 space-y-3">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Selecione o Paciente</label>
                  <select
                    className="w-full px-3 py-2 text-sm border border-border rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    value={pacienteId}
                    onChange={(e) => {
                      const p = data.pacientes.find((x) => x.id === parseInt(e.target.value));
                      setPacienteId(e.target.value);
                      if (p) { setClienteNome(p.nome); setClienteNif(p.nif ?? ""); setClienteEndereco(p.endereco ?? ""); }
                      else { setClienteNome(""); setClienteNif(""); setClienteEndereco(""); }
                    }}
                  >
                    <option value="">— Consumidor Final —</option>
                    {data.pacientes.map((p) => (
                      <option key={p.id} value={p.id}>{p.nome}</option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-muted-foreground mb-1">Nome do Cliente</label>
                    <input
                      className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      value={clienteNome || "Consumidor Final"}
                      onChange={(e) => setClienteNome(e.target.value)}
                      placeholder="Nome"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-muted-foreground mb-1">NIF</label>
                    <input
                      className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      value={clienteNif}
                      onChange={(e) => setClienteNif(e.target.value)}
                      placeholder="NIF do cliente"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Items card */}
            <div className="bg-white border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-border bg-muted/30 flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Itens</p>
                </div>
                <span className="text-xs bg-muted px-2 py-0.5 rounded-full text-muted-foreground">
                  {linhas.length} item{linhas.length !== 1 ? "s" : ""}
                </span>
              </div>

              {linhas.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground">
                  <div className="text-3xl mb-2 opacity-30">📦</div>
                  <p className="text-sm">Nenhum item adicionado.</p>
                  <p className="text-xs mt-1">Pesquise um produto abaixo ou clique na lista à direita.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/30 border-b border-border">
                        <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide w-8"></th>
                        <th className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Produto / Serviço</th>
                        <th className="text-center px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide w-24">IVA</th>
                        <th className="text-right px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide w-28">P. Unit.</th>
                        <th className="text-center px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide w-28">Qtd.</th>
                        <th className="text-right px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide w-28">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {linhas.map((l, i) => {
                        const sub = l.quantidade * l.precoUnitario;
                        return (
                          <tr key={i} className="border-b border-border/50 last:border-0">
                            <td className="px-3 py-2">
                              <button
                                onClick={() => handleRemoveLinha(i)}
                                className="w-5 h-5 rounded-full border border-red-200 text-red-400 hover:bg-red-50 flex items-center justify-center text-xs leading-none transition-colors"
                              >×</button>
                            </td>
                            <td className="px-4 py-2">
                              <input
                                className="w-full text-sm border-0 border-b border-transparent focus:border-primary outline-none bg-transparent py-0.5 transition-colors"
                                value={l.descricao}
                                onChange={(e) => handleUpdateLinha(i, "descricao", e.target.value)}
                              />
                            </td>
                            <td className="px-3 py-2 text-center">
                              <button
                                className={`px-2 py-0.5 rounded-full text-xs font-semibold transition-colors ${
                                  l.ivaIsento
                                    ? "bg-muted text-muted-foreground"
                                    : "bg-blue-50 text-blue-700"
                                }`}
                                onClick={() => handleUpdateLinha(i, "ivaIsento", !l.ivaIsento)}
                              >
                                {l.ivaIsento ? "Isento" : `${ivaTaxa}%`}
                              </button>
                            </td>
                            <td className="px-3 py-2 text-right">
                              <input
                                type="number"
                                className="w-24 text-sm text-right border border-border rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                                value={l.precoUnitario}
                                min={0}
                                step={0.01}
                                onChange={(e) => handleUpdateLinha(i, "precoUnitario", Number(e.target.value))}
                              />
                            </td>
                            <td className="px-3 py-2">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  className="w-6 h-6 rounded-full border border-primary text-primary hover:bg-primary hover:text-white flex items-center justify-center text-sm font-bold transition-colors"
                                  onClick={() => handleUpdateLinha(i, "quantidade", Math.max(1, l.quantidade - 1))}
                                >−</button>
                                <input
                                  type="number"
                                  className="w-10 text-sm text-center border border-border rounded-lg px-1 py-1 focus:outline-none"
                                  value={l.quantidade}
                                  min={1}
                                  onChange={(e) => handleUpdateLinha(i, "quantidade", Math.max(1, Number(e.target.value)))}
                                />
                                <button
                                  className="w-6 h-6 rounded-full border border-primary text-primary hover:bg-primary hover:text-white flex items-center justify-center text-sm font-bold transition-colors"
                                  onClick={() => handleUpdateLinha(i, "quantidade", l.quantidade + 1)}
                                >+</button>
                              </div>
                            </td>
                            <td className="px-4 py-2 text-right font-semibold text-sm">{fmtCurrency(sub)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colSpan={6} className="px-4 py-2 border-t border-border bg-muted/20">
                          <div className="flex justify-between items-center">
                            <button
                              className="text-xs text-primary font-medium flex items-center gap-1 hover:underline"
                              onClick={() => searchRef.current?.focus()}
                            >
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                              Adicionar item
                            </button>
                            <div className="text-right space-y-0.5">
                              <div className="text-xs text-muted-foreground">Subtotal s/IVA: <span className="font-medium text-foreground">{fmtCurrency(totals.subtotal)}</span></div>
                              <div className="text-xs text-muted-foreground">IVA ({ivaTaxa}%): <span className="font-medium text-foreground">{fmtCurrency(totals.totalIva)}</span></div>
                              <div className="text-sm font-bold text-primary">Total: {fmtCurrency(totals.total)}</div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}

              {/* Product search bar */}
              <div className="px-4 py-3 border-t border-border bg-muted/10">
                <div className="relative">
                  <div className="flex items-center gap-2 px-3 py-2 border border-border rounded-lg bg-white focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/10 transition-all">
                    <div className="flex items-center gap-1 pr-2 border-r border-border">
                      <button
                        className="w-5 h-5 rounded-full border border-primary text-primary hover:bg-primary hover:text-white flex items-center justify-center text-xs font-bold transition-colors"
                        onClick={() => setProdutoQtd((q) => Math.max(1, q - 1))}
                      >−</button>
                      <input
                        type="number"
                        className="w-8 text-xs text-center border border-border rounded px-1 py-0.5 focus:outline-none"
                        value={produtoQtd}
                        min={1}
                        onChange={(e) => setProdutoQtd(Math.max(1, Number(e.target.value)))}
                      />
                      <button
                        className="w-5 h-5 rounded-full border border-primary text-primary hover:bg-primary hover:text-white flex items-center justify-center text-xs font-bold transition-colors"
                        onClick={() => setProdutoQtd((q) => q + 1)}
                      >+</button>
                    </div>
                    <svg className="text-muted-foreground flex-shrink-0" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    <input
                      ref={searchRef}
                      className="flex-1 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
                      value={produtoSearch}
                      onChange={(e) => setProdutoSearch(e.target.value)}
                      onKeyDown={handleSearchKeyDown}
                      onFocus={() => { if (produtosFiltrados.length) setShowDropdown(true); }}
                      placeholder="Pesquisar e adicionar produto ao documento…"
                    />
                    {produtoSearch && (
                      <button onClick={() => { setProdutoSearch(""); setShowDropdown(false); }} className="text-muted-foreground text-base leading-none hover:text-foreground">×</button>
                    )}
                  </div>

                  {/* Dropdown */}
                  {showDropdown && produtosFiltrados.length > 0 && (
                    <div
                      ref={dropdownRef}
                      className="absolute left-0 right-0 top-full mt-1 bg-white border border-border rounded-xl shadow-lg z-50 overflow-hidden"
                    >
                      <div className="px-3 py-1.5 bg-muted/30 border-b border-border text-xs text-muted-foreground">
                        {produtosFiltrados.length} produto{produtosFiltrados.length !== 1 ? "s" : ""} encontrado{produtosFiltrados.length !== 1 ? "s" : ""}
                      </div>
                      {produtosFiltrados.map((p, idx) => (
                        <div
                          key={p.id}
                          className={`flex items-center justify-between px-3 py-2 cursor-pointer border-b border-border/50 last:border-0 transition-colors ${
                            idx === dropdownIdx ? "bg-blue-50" : "hover:bg-muted/30"
                          }`}
                          onMouseDown={(e) => e.preventDefault()}
                          onClick={() => handleAddProduto(p)}
                        >
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700 flex-shrink-0">
                              {p.nome.charAt(0)}
                            </div>
                            <div>
                              <div className="text-sm font-medium text-foreground">{p.nome}</div>
                              <div className="text-xs text-muted-foreground">{p.codigo}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-semibold text-primary">{fmtCurrency(p.preco)}</div>
                            {p.ivaIsento && <div className="text-xs text-muted-foreground">IVA isento</div>}
                          </div>
                        </div>
                      ))}
                      <div
                        className="flex items-center gap-2 px-3 py-2 cursor-pointer bg-muted/20 hover:bg-muted/40 transition-colors"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => handleAddProduto()}
                      >
                        <div className="w-7 h-7 rounded-lg bg-green-100 flex items-center justify-center text-xs font-bold text-green-700">+</div>
                        <span className="text-xs text-muted-foreground">Criar item <strong>"{produtoSearch}"</strong> manualmente</span>
                      </div>
                    </div>
                  )}

                  {produtoSearch.trim() && !showDropdown && produtosFiltrados.length === 0 && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-border rounded-xl shadow-lg z-50 overflow-hidden">
                      <div className="flex items-center justify-between px-3 py-3">
                        <span className="text-xs text-muted-foreground">Nenhum produto para <strong>"{produtoSearch}"</strong></span>
                        <button
                          className="text-xs bg-primary text-primary-foreground px-3 py-1 rounded-lg font-medium hover:bg-primary/90 transition-colors"
                          onMouseDown={(e) => e.preventDefault()}
                          onClick={() => handleAddProduto()}
                        >+ Adicionar</button>
                      </div>
                    </div>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1.5">↑↓ navegar · Enter seleccionar · Esc fechar</p>
              </div>
            </div>

            {/* Observations */}
            <div className="bg-white border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-border bg-muted/30">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Observações</p>
              </div>
              <div className="p-4">
                <textarea
                  className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                  rows={3}
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Observações, notas ou comentários para o documento…"
                />
              </div>
            </div>
          </div>
        </div>

        {/* ── Right settings + products panel ── */}
        <div className="w-64 flex-shrink-0 border-l border-border bg-white flex flex-col overflow-hidden">
          {/* Document settings */}
          <div className="px-4 py-3 border-b border-border bg-muted/30 flex-shrink-0">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Definições</p>
          </div>
          <div className="flex-shrink-0 divide-y divide-border/60">
            <div className="px-4 py-2.5">
              <label className="block text-xs text-muted-foreground mb-1">Estado</label>
              <select
                className="w-full text-sm border border-border rounded-lg px-2 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                value={estado}
                onChange={(e) => setEstado(e.target.value as FaturaEstado)}
              >
                <option value="emitida">Emitida</option>
                <option value="paga">Paga</option>
                <option value="rascunho">Rascunho</option>
                <option value="anulada">Anulada</option>
              </select>
            </div>
            <div className="px-4 py-2.5">
              <label className="block text-xs text-muted-foreground mb-1">Data de Emissão</label>
              <input
                className="w-full text-sm border border-border rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                value={dataEmissao}
                onChange={(e) => setDataEmissao(e.target.value)}
                placeholder="DD/MM/AAAA"
              />
            </div>
            <div className="px-4 py-2.5">
              <label className="block text-xs text-muted-foreground mb-1">Vencimento</label>
              <input
                className="w-full text-sm border border-border rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                value={dataVenc}
                onChange={(e) => setDataVenc(e.target.value)}
                placeholder="DD/MM/AAAA"
              />
            </div>
            <div className="px-4 py-2.5 grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-muted-foreground mb-1">IVA (%)</label>
                <input
                  type="number"
                  className="w-full text-sm border border-border rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  value={ivaTaxa}
                  min={0}
                  max={100}
                  onChange={(e) => setIvaTaxa(Number(e.target.value))}
                />
              </div>
              <div>
                <label className="block text-xs text-muted-foreground mb-1">Desconto (%)</label>
                <input
                  type="number"
                  className="w-full text-sm border border-border rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  value={desconto}
                  min={0}
                  max={100}
                  onChange={(e) => setDesconto(Number(e.target.value))}
                />
              </div>
            </div>
          </div>

          {/* Totals */}
          {totals.total > 0 && (
            <div className="px-4 py-3 border-t border-border bg-muted/10 flex-shrink-0 space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Subtotal s/IVA</span><span className="font-medium text-foreground">{fmtCurrency(totals.subtotal)}</span>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>IVA ({ivaTaxa}%)</span><span className="font-medium text-foreground">{fmtCurrency(totals.totalIva)}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-primary pt-1 border-t border-border">
                <span>Total</span><span>{fmtCurrency(totals.total)}</span>
              </div>
            </div>
          )}

          {/* Save / Cancel */}
          <div className="px-4 py-3 border-t border-border space-y-2 flex-shrink-0">
            <button
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 transition-colors"
              onClick={handleSave}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              {editId !== null ? "Guardar Alterações" : "Criar Factura"}
            </button>
            <button
              className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-red-200 text-red-500 text-xs font-medium rounded-lg hover:bg-red-50 transition-colors"
              onClick={() => { resetForm(); setView("lista"); }}
            >
              {editId !== null ? "Cancelar Edição" : "Cancelar"}
            </button>
          </div>

          {/* Products quick-add list */}
          <div className="flex-1 flex flex-col overflow-hidden border-t border-border">
            <div className="px-3 py-2 bg-muted/30 border-b border-border flex-shrink-0">
              <div className="flex items-center gap-2 px-2 py-1.5 bg-white border border-border rounded-lg">
                <svg className="text-muted-foreground" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input
                  className="flex-1 text-xs bg-transparent outline-none placeholder:text-muted-foreground"
                  value={sidePanelSearch}
                  onChange={(e) => { setSidePanelSearch(e.target.value); setSidePanelPage(1); }}
                  placeholder="Filtrar produtos…"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {sidePageItems.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between px-3 py-2 border-b border-border/50 cursor-pointer hover:bg-blue-50/50 transition-colors"
                  onClick={() => handleSideAdd(p)}
                >
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-foreground truncate">{p.nome}</div>
                    <div className="text-xs text-muted-foreground">{p.codigo}</div>
                  </div>
                  <div className="text-xs font-semibold text-primary ml-2 flex-shrink-0">{fmtCurrency(p.preco)}</div>
                </div>
              ))}
              {sidePageItems.length === 0 && (
                <div className="py-6 text-center text-xs text-muted-foreground">Nenhum produto</div>
              )}
            </div>
            {sideTotalPages > 1 && (
              <div className="px-3 py-1.5 border-t border-border bg-muted/20 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-1">
                  <button disabled={sidePanelPage <= 1} onClick={() => setSidePanelPage((p) => p - 1)}
                    className="w-6 h-6 border border-border rounded bg-white flex items-center justify-center text-muted-foreground hover:bg-muted disabled:opacity-40 transition-colors">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
                  </button>
                  <button disabled={sidePanelPage >= sideTotalPages} onClick={() => setSidePanelPage((p) => p + 1)}
                    className="w-6 h-6 border border-border rounded bg-white flex items-center justify-center text-muted-foreground hover:bg-muted disabled:opacity-40 transition-colors">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
                  </button>
                  <span className="text-xs text-muted-foreground">{sidePanelPage}/{sideTotalPages}</span>
                </div>
                <span className="text-xs text-muted-foreground">{sideProdutos.length} produtos</span>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════════════════════
  // LIST VIEW
  // ════════════════════════════════════════════════════════════════════════════
  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Documentos</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Facturas e documentos de faturação</p>
        </div>
        <button
          onClick={handleNovo}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Nova Factura
        </button>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white border border-border rounded-xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total de Facturas</p>
          <p className="text-2xl font-bold text-foreground mt-1">{faturas.length}</p>
        </div>
        <div className="bg-white border border-border rounded-xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Total Recebido</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">{fmtCurrency(totalRecebido)}</p>
        </div>
        <div className="bg-white border border-border rounded-xl p-4 shadow-sm">
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Pendente</p>
          <p className="text-xl font-bold text-blue-600 mt-1">{fmtCurrency(totalPendente)}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-white border border-border rounded-lg focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/10 transition-all">
          <svg className="text-muted-foreground flex-shrink-0" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input
            className="flex-1 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Pesquisar por número ou cliente…"
          />
        </div>
        <div className="flex items-center gap-1 bg-white border border-border rounded-lg p-1">
          {[
            { v: "todos",    l: "Todos" },
            { v: "emitida",  l: "Emitidas" },
            { v: "paga",     l: "Pagas" },
            { v: "rascunho", l: "Rascunhos" },
            { v: "anulada",  l: "Anuladas" },
          ].map((o) => (
            <button
              key={o.v}
              onClick={() => setFiltroEstado(o.v)}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                filtroEstado === o.v
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {o.l}
            </button>
          ))}
        </div>
      </div>

      {/* Drafts collapsible */}
      {rascunhos.length > 0 && (
        <div className="border border-amber-200 rounded-xl overflow-hidden bg-amber-50">
          <button
            className="w-full flex items-center justify-between px-4 py-3 text-left"
            onClick={() => setShowRascunhos((s) => !s)}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-amber-400 flex items-center justify-center text-white text-sm">📄</div>
              <div>
                <p className="text-sm font-semibold text-amber-800">Rascunhos</p>
                <p className="text-xs text-amber-600">{rascunhos.length} documento{rascunhos.length > 1 ? "s" : ""} em rascunho</p>
              </div>
            </div>
            <span className="text-amber-700 font-bold text-sm">{showRascunhos ? "∧" : "∨"}</span>
          </button>
          {showRascunhos && rascunhos.map((f) => (
            <div
              key={f.id}
              className="flex items-center gap-3 px-4 py-2.5 border-t border-amber-200 cursor-pointer bg-white/40 hover:bg-white/70 transition-colors"
              onClick={() => handleEdit(f)}
            >
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xs flex-shrink-0">FT</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground">{f.numero}</p>
                <p className="text-xs text-muted-foreground truncate">{f.clienteNome}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-sm font-semibold">{fmtCurrency(f.total)}</p>
                <p className="text-xs text-muted-foreground">{f.data}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Documents table */}
      <div className="bg-white border border-border rounded-xl shadow-sm overflow-hidden">
        {outros.length === 0 ? (
          <div className="py-16 text-center text-muted-foreground">
            <div className="text-4xl mb-3 opacity-25">📄</div>
            <p className="text-sm font-medium">Nenhum documento encontrado.</p>
            <button
              className="mt-4 px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
              onClick={handleNovo}
            >
              + Criar primeiro documento
            </button>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/30 border-b border-border">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Documento</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Cliente</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Estado</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Total</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Data</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {outros.map((f) => {
                const vencida = isVencida(f.dataVencimento ?? "", f.estado);
                return (
                  <tr
                    key={f.id}
                    className="border-b border-border/50 last:border-0 cursor-pointer hover:bg-muted/20 transition-colors group"
                    onClick={() => handleEdit(f)}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xs flex-shrink-0">FT</div>
                        <span className="font-semibold text-foreground">{f.numero}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{f.clienteNome}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <StatusBadge estado={f.estado} />
                        {vencida && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-orange-50 text-orange-700">
                            ⚠️ Vencida
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right font-semibold whitespace-nowrap">{fmtCurrency(f.total)}</td>
                    <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{f.data}</td>
                    <td className="px-4 py-3">
                      <div className="hidden group-hover:flex items-center gap-1.5 justify-end" onClick={(e) => e.stopPropagation()}>
                        <button
                          className="px-2.5 py-1 text-xs border border-blue-200 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-medium"
                          onClick={(e) => { e.stopPropagation(); alert("PDF: " + f.numero); }}
                        >PDF</button>
                        {f.estado === "emitida" && (
                          <button
                            className="px-2.5 py-1 text-xs bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium"
                            onClick={(e) => handleMarcarPaga(f, e)}
                          >Pagar</button>
                        )}
                        {f.estado !== "paga" && f.estado !== "anulada" && (
                          <button
                            className="px-2.5 py-1 text-xs border border-amber-200 text-amber-600 rounded-lg hover:bg-amber-50 transition-colors font-medium"
                            onClick={(e) => handleAnular(f, e)}
                          >Anular</button>
                        )}
                        <button
                          className="px-2.5 py-1 text-xs border border-red-200 text-red-500 rounded-lg hover:bg-red-50 transition-colors"
                          onClick={(e) => handleDelete(f, e)}
                        >
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

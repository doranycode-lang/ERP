import { useState } from "react";
import { useApp } from "../store/AppContext";
import { Resultado } from "../store/AppContext";
import { ParametroResult } from "../store/storage";
import { generatePDFHTML, downloadPDF } from "../utils/pdfGenerator";

function todayStr() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}

export default function Historico() {
  const { data, removeResultado, updateResultado } = useApp();
  const [search, setSearch] = useState("");
  const [editando, setEditando] = useState<Resultado | null>(null);
  const [editParams, setEditParams] = useState<ParametroResult[]>([]);
  const [editData, setEditData] = useState("");
  const [editTecnico, setEditTecnico] = useState("");

  const filtered = [...data.resultados]
    .reverse()
    .filter((r) => !search || r.pacienteNome.toLowerCase().includes(search.toLowerCase()));

  function handlePDF(id: number) {
    const resultado = data.resultados.find((r) => r.id === id);
    if (!resultado) return;
    const paciente = data.pacientes.find((p) => p.id === resultado.pacienteId);
    const html = generatePDFHTML(resultado, paciente, data.config);
    const filename = `${resultado.pacienteNome.replace(/\s+/g, "_")}_${resultado.data.replace(/\//g, "-")}.pdf`;
    downloadPDF(html, filename);
  }

  function handleRemove(id: number) {
    if (window.confirm(`Remover registo ID ${id}?`)) removeResultado(id);
  }

  function handleEditar(r: Resultado) {
    setEditando(r);
    setEditParams(r.parametros.map((p) => ({ ...p })));
    setEditData(r.data);
    setEditTecnico(r.tecnicoNome || "");
  }

  function handleFecharEdit() { setEditando(null); }

  async function handleSaveEdit() {
    if (!editando) return;
    await updateResultado(editando.id, {
      ...editando,
      data: editData,
      tecnicoNome: editTecnico,
      parametros: editParams,
    });
    setEditando(null);
  }

  return (
    <div className="p-5 space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-xl font-bold text-primary">Histórico / PDF</h2>
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar paciente..."
          className="border border-border rounded-lg px-3 py-1.5 text-sm w-52 focus:outline-none focus:ring-2 focus:ring-primary/30" />
      </div>

      {editando && (
        <div className="bg-white border border-primary/30 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-primary text-sm">Editar Resultado — {editando.pacienteNome}</h3>
            <button onClick={handleFecharEdit} className="text-xs text-muted-foreground hover:text-destructive font-semibold">✕ Fechar</button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Data de Colheita</label>
              <input value={editData} onChange={(e) => setEditData(e.target.value)}
                className="w-full border border-border rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Técnico Responsável</label>
              <input value={editTecnico} onChange={(e) => setEditTecnico(e.target.value)}
                className="w-full border border-border rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
          </div>
          <div className="space-y-2">
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Parâmetros</div>
            <div className="grid grid-cols-5 gap-2 text-xs font-semibold text-muted-foreground px-1">
              <div>Exame</div><div>Parâmetro</div><div>Resultado</div><div>Unidade</div><div>Referência</div>
            </div>
            {editParams.map((p, i) => (
              <div key={i} className="grid grid-cols-5 gap-2">
                {(["exame", "parametro", "resultado", "unidade", "referencia"] as const).map((field) => (
                  <input key={field} value={p[field]} onChange={(e) => {
                    const ps = [...editParams]; ps[i] = { ...p, [field]: e.target.value }; setEditParams(ps);
                  }} className="border border-border rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-primary/30" />
                ))}
              </div>
            ))}
          </div>
          <div className="flex gap-3">
            <button onClick={handleSaveEdit} className="bg-primary text-primary-foreground px-5 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition">Guardar</button>
            <button onClick={handleFecharEdit} className="bg-muted text-muted-foreground px-5 py-2 rounded-lg text-sm font-semibold">Cancelar</button>
          </div>
        </div>
      )}

      <div className="bg-white border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-border text-xs text-muted-foreground">
          {filtered.length} resultado(s) encontrado(s)
        </div>
        {filtered.length === 0 ? (
          <div className="py-14 text-center text-muted-foreground text-sm">Nenhum resultado encontrado.</div>
        ) : (
          <div className="divide-y divide-border">
            {filtered.map((r) => (
              <div key={r.id} className="flex items-center gap-4 px-5 py-4 hover:bg-accent/10">
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{r.pacienteNome}</div>
                  <div className="text-xs text-muted-foreground">
                    {r.data} · {r.parametros.length} parâmetro(s)
                    {r.tecnicoNome && ` · Téc: ${r.tecnicoNome}`}
                  </div>
                </div>
                <div className="flex gap-2 text-xs flex-shrink-0">
                  <button onClick={() => handlePDF(r.id)}
                    className="bg-primary/10 text-primary px-3 py-1.5 rounded font-semibold hover:bg-primary/20 transition">📄 PDF</button>
                  <button onClick={() => handleEditar(r)}
                    className="text-primary hover:underline font-semibold">Editar</button>
                  <span className="text-border">|</span>
                  <button onClick={() => handleRemove(r.id)}
                    className="text-destructive hover:underline font-semibold">Eliminar</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import { useState, useMemo } from "react";
import { useApp } from "../store/AppContext";
import { EXAMES_BUILTIN } from "../data/exames";

interface ParamInput {
  param: string;
  unidade: string;
  referencia: string;
}

function emptyParam(): ParamInput {
  return { param: "", unidade: "", referencia: "" };
}

type ViewMode = "lista" | "editor";

export default function CadastrarExames() {
  const { data, addExameCustom, updateExameCustom, removeExameCustom } = useApp();

  const [view, setView] = useState<ViewMode>("lista");
  const [search, setSearch] = useState("");
  const [filterTipo, setFilterTipo] = useState<"todos" | "padrao" | "custom">("todos");
  const [filterCat, setFilterCat] = useState("");
  const [editCat, setEditCat] = useState("");
  const [editCatCustom, setEditCatCustom] = useState("");
  const [editNome, setEditNome] = useState("");
  const [editParams, setEditParams] = useState<ParamInput[]>([emptyParam(), emptyParam(), emptyParam()]);
  const [isEditingCustom, setIsEditingCustom] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);

  const allBuiltin = useMemo(() => {
    const items: { cat: string; nome: string; params: ParamInput[]; tipo: "Padrão"; id?: number }[] = [];
    for (const [cat, sub] of Object.entries(EXAMES_BUILTIN)) {
      for (const [nome, ps] of Object.entries(sub)) {
        items.push({ cat, nome, params: (ps as any[]).map((p: any) => ({ param: p[0], unidade: p[1], referencia: p[2] })), tipo: "Padrão" });
      }
    }
    return items;
  }, []);

  const allCustomRaw = useMemo(() => {
    const items: { cat: string; nome: string; params: ParamInput[]; tipo: "Personalizado"; id?: number }[] = [];
    for (const [cat, sub] of Object.entries(data.examesCustom)) {
      for (const [nome, ps] of Object.entries(sub)) {
        items.push({ cat, nome, params: (ps as any[]).map((p: any) => ({ param: p.param, unidade: p.unidade, referencia: p.referencia })), tipo: "Personalizado" });
      }
    }
    return items;
  }, [data.examesCustom]);

  const allItems = useMemo(() => {
    let items = [...allBuiltin, ...allCustomRaw];
    if (filterTipo === "padrao") items = items.filter(i => i.tipo === "Padrão");
    if (filterTipo === "custom") items = items.filter(i => i.tipo === "Personalizado");
    if (filterCat) items = items.filter(i => i.cat === filterCat);
    if (search) items = items.filter(i =>
      i.nome.toLowerCase().includes(search.toLowerCase()) ||
      i.cat.toLowerCase().includes(search.toLowerCase())
    );
    return items;
  }, [allBuiltin, allCustomRaw, filterTipo, filterCat, search]);

  const allCats = useMemo(() => {
    return [...new Set([...allBuiltin, ...allCustomRaw].map(i => i.cat))].sort();
  }, [allBuiltin, allCustomRaw]);

  function handleNovo() {
    setEditCat(""); setEditCatCustom(""); setEditNome("");
    setEditParams([emptyParam(), emptyParam(), emptyParam()]);
    setIsEditingCustom(false); setEditingId(null); setMsg(null); setView("editor");
  }

  function handleEditar(item: typeof allItems[0]) {
    const params = item.params.length > 0 ? [...item.params] : [emptyParam()];
    setEditCat(item.cat); setEditCatCustom(""); setEditNome(item.nome); setEditParams(params);
    setIsEditingCustom(item.tipo === "Personalizado"); setEditingId(null); setMsg(null); setView("editor");
  }

  async function handleSave() {
    const cat = editCatCustom.trim() || editCat.trim();
    const nome = editNome.trim();
    if (!cat || !nome) { setMsg({ text: "Preencha a categoria e o nome do exame.", ok: false }); return; }
    const params = editParams.filter(p => p.param.trim());
    if (params.length === 0) { setMsg({ text: "Adicione pelo menos um parâmetro.", ok: false }); return; }
    try {
      if (isEditingCustom && editingId !== null) {
        await updateExameCustom(editingId, cat, nome, params);
        setMsg({ text: "Exame actualizado com sucesso.", ok: true });
      } else {
        await addExameCustom(cat, nome, params);
        setMsg({ text: `Exame "${nome}" criado com sucesso.`, ok: true });
      }
      setTimeout(() => setView("lista"), 1200);
    } catch (err: any) {
      setMsg({ text: err.message || "Erro ao guardar exame.", ok: false });
    }
  }

  async function handleRemover(item: typeof allItems[0]) {
    if (item.tipo !== "Personalizado") { alert("Só é possível eliminar exames personalizados."); return; }
    if (!window.confirm(`Remover o exame "${item.nome}"?`)) return;
    try {
      await removeExameCustom(0);
      setView("lista");
    } catch (err: any) {
      alert(err.message || "Erro ao remover exame.");
    }
  }

  const CATS_BUILTIN = [...new Set(allBuiltin.map(i => i.cat))].sort();

  return (
    <div className="p-5 space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-primary">Cadastrar Exames</h2>
        {view === "lista" ? (
          <button onClick={handleNovo} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition">
            + Novo Exame
          </button>
        ) : (
          <button onClick={() => setView("lista")} className="text-sm text-primary hover:underline font-semibold">
            ← Voltar à lista
          </button>
        )}
      </div>

      {view === "lista" && (
        <>
          <div className="flex flex-wrap gap-2">
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar exame..."
              className="border border-border rounded-lg px-3 py-1.5 text-sm w-52 focus:outline-none focus:ring-2 focus:ring-primary/30" />
            <select value={filterTipo} onChange={(e) => setFilterTipo(e.target.value as any)}
              className="border border-border rounded-lg px-3 py-1.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-primary/30">
              <option value="todos">Todos os tipos</option>
              <option value="padrao">Padrão</option>
              <option value="custom">Personalizado</option>
            </select>
            <select value={filterCat} onChange={(e) => setFilterCat(e.target.value)}
              className="border border-border rounded-lg px-3 py-1.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-primary/30">
              <option value="">Todas as categorias</option>
              {allCats.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="bg-white border border-border rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-border text-xs text-muted-foreground">
              {allItems.length} exame(s) encontrado(s) · {allCustomRaw.length} personalizado(s)
            </div>
            {allItems.length === 0 ? (
              <div className="py-14 text-center text-muted-foreground text-sm">Nenhum exame encontrado.</div>
            ) : (
              <div className="divide-y divide-border">
                {allItems.map((item, i) => (
                  <div key={i} className="flex items-center gap-3 px-5 py-3 hover:bg-accent/10">
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm">{item.nome}</div>
                      <div className="text-xs text-muted-foreground">{item.cat} · {item.params.length} parâmetro(s)</div>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold flex-shrink-0 ${item.tipo === "Padrão" ? "bg-blue-100 text-blue-700" : "bg-amber-100 text-amber-700"}`}>
                      {item.tipo}
                    </span>
                    <div className="flex gap-2 text-xs flex-shrink-0">
                      <button onClick={() => handleEditar(item)} className="text-primary hover:underline font-semibold">
                        {item.tipo === "Personalizado" ? "Editar" : "Ver"}
                      </button>
                      {item.tipo === "Personalizado" && (
                        <>
                          <span className="text-border">|</span>
                          <button onClick={() => handleRemover(item)} className="text-destructive hover:underline font-semibold">Eliminar</button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {view === "editor" && (
        <div className="bg-white border border-border rounded-xl p-6 space-y-5 max-w-2xl">
          <h3 className="text-sm font-bold text-primary uppercase tracking-wide">
            {isEditingCustom ? "Editar Exame" : "Novo Exame Personalizado"}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Categoria *</label>
              <select value={editCat} onChange={(e) => { setEditCat(e.target.value); setEditCatCustom(""); }}
                className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-primary/30">
                <option value="">— Nova categoria —</option>
                {CATS_BUILTIN.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              {!editCat && (
                <input value={editCatCustom} onChange={(e) => setEditCatCustom(e.target.value)}
                  placeholder="Nome da nova categoria"
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm mt-1 focus:outline-none focus:ring-2 focus:ring-primary/30" />
              )}
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Nome do Exame *</label>
              <input value={editNome} onChange={(e) => setEditNome(e.target.value)}
                className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                placeholder="Ex: Glicemia em Jejum" />
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1">Parâmetros</div>
            <div className="grid grid-cols-3 gap-2 text-xs font-semibold text-muted-foreground px-1">
              <div>Parâmetro</div><div>Unidade</div><div>Referência</div>
            </div>
            {editParams.map((p, i) => (
              <div key={i} className="grid grid-cols-3 gap-2">
                <input value={p.param} onChange={(e) => { const ps = [...editParams]; ps[i] = { ...p, param: e.target.value }; setEditParams(ps); }}
                  className="border border-border rounded px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" placeholder="Ex: Glicose" />
                <input value={p.unidade} onChange={(e) => { const ps = [...editParams]; ps[i] = { ...p, unidade: e.target.value }; setEditParams(ps); }}
                  className="border border-border rounded px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" placeholder="mg/dL" />
                <input value={p.referencia} onChange={(e) => { const ps = [...editParams]; ps[i] = { ...p, referencia: e.target.value }; setEditParams(ps); }}
                  className="border border-border rounded px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" placeholder="70-110" />
              </div>
            ))}
            <button type="button" onClick={() => setEditParams([...editParams, emptyParam()])}
              className="text-xs text-primary hover:underline font-semibold mt-1">+ Adicionar parâmetro</button>
          </div>

          {msg && (
            <div className={`text-xs rounded-lg px-3 py-2 ${msg.ok ? "bg-green-50 border border-green-200 text-green-700" : "bg-red-50 border border-red-200 text-red-700"}`}>{msg.text}</div>
          )}

          <div className="flex gap-3">
            <button onClick={handleSave} className="bg-primary text-primary-foreground px-6 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition">
              {isEditingCustom ? "Guardar Alterações" : "Criar Exame"}
            </button>
            <button onClick={() => setView("lista")} className="bg-muted text-muted-foreground px-6 py-2 rounded-lg text-sm font-semibold hover:opacity-80 transition">
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
